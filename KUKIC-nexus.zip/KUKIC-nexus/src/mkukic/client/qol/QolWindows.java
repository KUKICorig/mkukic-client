package mkukic.client.qol;

import arc.*;
import arc.func.*;
import arc.input.*;
import arc.math.*;
import arc.scene.*;
import arc.scene.event.*;
import arc.scene.ui.*;
import arc.scene.ui.layout.*;
import arc.struct.*;
import arc.util.*;
import mindustry.core.*;
import mindustry.gen.*;
import mindustry.graphics.*;
import mindustry.ui.*;
import mkukic.*;
import mkukic.client.*;

import static mindustry.Vars.*;

/**
 * Система плавающих окон MKUKIC QoL (аналог Mindow из MI2-Utilities).
 * Каждое окно — независимая Table на сцене: перетаскивается за заголовок,
 * сворачивается в шапку, закрывается, запоминает позицию/состояние в настройках.
 * Окна регистрируются один раз, контент строится лениво при первом открытии.
 */
public class QolWindows{
    /** Одно плавающее окно. */
    public static class Win{
        public final String id;
        public final String title;
        public final Cons<Table> builder;
        public final float defXF, defYF; // доля экрана для позиции по умолчанию

        Table root, content;
        boolean built, collapsed, open;

        Win(String id, String title, float defXF, float defYF, Cons<Table> builder){
            this.id = id;
            this.title = title;
            this.defXF = defXF;
            this.defYF = defYF;
            this.builder = builder;
        }

        public boolean isOpen(){
            return open;
        }

        void build(){
            if(built) return;
            built = true;
            MKUKICSkin.init();

            root = new Table();
            root.background(MKUKICSkin.panel);

            // шапка: логотип + заголовок (ручка перетаскивания) + свернуть + закрыть
            Table head = root.table(h -> {
                h.left();
                h.image(MKUKICSkin.logoDrawable).size(16f).padLeft(8f).padRight(6f);
                h.add("[#ffb454]" + title + "[]").padRight(10f).left();
                h.add().growX();
                h.button("–", MKUKICSkin.iconBtn, () -> {
                    collapsed = !collapsed;
                    applyCollapsed();
                    savePos();
                }).size(26f).padRight(1f);
                h.button("✕", MKUKICSkin.iconBtn, () -> close()).size(26f).padRight(4f);
            }).growX().minWidth(180f).height(30f).get();
            head.setBackground(MKUKICSkin.head);
            makeDraggable(root, head, this::savePos);
            root.row();

            content = new Table();
            content.top().left();
            builder.get(content);
            root.add(content).top().left().pad(4f).maxWidth(Core.scene == null ? 560f : Core.scene.getWidth() * 0.8f);

            root.pack();

            // клик по окну — поверх остальных
            root.addListener(new InputListener(){
                @Override
                public boolean touchDown(InputEvent event, float x, float y, int pointer, KeyCode button){
                    root.toFront();
                    return false;
                }
            });

            Core.scene.add(root);
            loadPos();
            applyCollapsed();
        }

        void applyCollapsed(){
            if(root == null) return;
            content.visible = !collapsed;
            root.pack();
            clamp(root);
        }

        public void open(){
            if(Core.scene == null) return;
            if(!built) build();
            open = true;
            root.visible = true;
            root.toFront();
            loadPos();
            applyCollapsed();
        }

        public void close(){
            open = false;
            if(root != null) root.visible = false;
        }

        public void toggle(){
            if(open) close(); else open();
        }

        void savePos(){
            if(root == null) return;
            MKUKICSettings.s().winPos.put(id, (int)root.x + "|" + (int)root.y + "|" + (collapsed ? 1 : 0));
            MKUKICSettings.save();
        }

        void loadPos(){
            if(root == null || Core.scene == null) return;
            String v = MKUKICSettings.s().winPos.get(id);
            if(v != null){
                String[] p = v.split("\\|");
                if(p.length >= 2 && Strings.canParseFloat(p[0]) && Strings.canParseFloat(p[1])){
                    collapsed = p.length >= 3 && p[2].equals("1");
                    root.setPosition(Strings.parseFloat(p[0]), Strings.parseFloat(p[1]));
                    clamp(root);
                    return;
                }
            }
            // позиция по умолчанию — доля экрана
            root.setPosition(
                Mathf.clamp(Core.scene.getWidth() * defXF, 0f, Math.max(0f, Core.scene.getWidth() - root.getWidth())),
                Mathf.clamp(Core.scene.getHeight() * defYF, 0f, Math.max(0f, Core.scene.getHeight() - root.getHeight())));
        }

        public void resetPos(){
            MKUKICSettings.s().winPos.remove(id);
            loadPos();
        }
    }

    public static final Seq<Win> all = new Seq<>();
    private static final ObjectMap<String, Win> byId = new ObjectMap<>();

    public static Win register(String id, String title, float defXF, float defYF, Cons<Table> builder){
        Win w = new Win(id, title, defXF, defYF, builder);
        all.add(w);
        byId.put(id, w);
        return w;
    }

    /** Регистрация всех окон QoL + окна-хаба. */
    public static void init(){
        if(!byId.isEmpty()) return;

        register("hub",       "QoL-хаб",            0.04f, 0.55f, QolWindows::buildHub);
        register("rules",     "Правила карты",      0.22f, 0.30f, RuleViewer::build);
        register("waves",     "Монитор волн",       0.02f, 0.72f, WaveMonitor::build);
        register("core",      "Ядро: ресурсы",      0.38f, 0.04f, CoreStats::build);
        register("power",     "Энергосети",         0.68f, 0.04f, PowerMonitor::build);
        register("recipes",   "База рецептов",      0.18f, 0.12f, ContentBrowser::build);
        register("mapsearch", "Поиск по карте",     0.60f, 0.45f, MapSearch::build);
        register("quick",     "Быстрые действия",   0.04f, 0.12f, QuickActions::build);
        register("tripwire",  "Геозона (тревога)",  0.74f, 0.55f, Tripwire::build);
        register("upgrade",   "Апгрейд транспорта", 0.05f, 0.25f, SmartUpgrade::build);
        register("icons",     "Символы и иконки",   0.30f, 0.18f, IconKit::build);
        register("view",      "Камера / время / FPS", 0.62f, 0.30f, ViewControl::build);
        register("formations", "Формации (RTS)",    0.30f, 0.58f, Formations::build);
        register("paths",      "Пути волн",         0.56f, 0.60f, PathPreview::build);
        register("blocks",     "Каталог блоков (F2)", 0.26f, 0.22f, BuildWheel::buildGrid);
        register("logic",      "Бэкапы логики (mlog)", 0.36f, 0.34f, LogicBackup::build);
        register("music",      "Музыкальный плеер", 0.46f, 0.14f, MusicBox::build);
        register("drill",      "Планировщик буров", 0.66f, 0.18f, DrillPlanner::build);
        register("inspector",  "Инспектор",         0.76f, 0.34f, Inspector::build);
        register("markers",    "Маркеры карты",     0.44f, 0.72f, MapMarkers::build);
        register("cursors",    "Трекер курсоров",   0.82f, 0.68f, CursorTracker::build);
        register("prune",      "Умный снос",        0.48f, 0.42f, SmartPrune::build);

        // ---- v1.16: вторая волна портов из каталога модов ----
        register("attack",     "Атаки и счётчики",  0.86f, 0.42f, AttackAlert::build);
        register("chat",       "История чата",      0.08f, 0.16f, ChatLog::build);
        register("xray",       "Просвет зданий",    0.34f, 0.46f, XRay::build);
        register("flow",       "Поток ресурсов",    0.20f, 0.62f, CoreFlow::build);
        register("prodgraph",  "График производства", 0.40f, 0.26f, ProductionGraph::build);
        register("alerts",     "Тревоги производства", 0.66f, 0.50f, AlertList::build);
        register("spectate",   "Операторская камера", 0.52f, 0.52f, SpectateCam::build);
    }

    public static @Nullable Win get(String id){
        return byId.get(id);
    }

    public static void open(String id){
        Win w = byId.get(id);
        if(w != null) w.open();
    }

    public static void toggle(String id){
        Win w = byId.get(id);
        if(w != null) w.toggle();
    }

    public static boolean isOpen(String id){
        Win w = byId.get(id);
        return w != null && w.open;
    }

    public static void closeAll(){
        for(Win w : all) w.close();
    }

    public static void resetPositions(){
        for(Win w : all) w.resetPos();
        MKUKICSettings.save();
    }

    private static boolean menuHidden;

    /** Каждый кадр (ведём от Trigger.uiDrawBegin — срабатывает и в меню, и в игре). */
    public static void update(){
        if(Core.scene == null) return;
        if(state == null || state.isMenu()){
            // Главное меню: прячем окна ОДИН РАЗ при выходе из игры, дальше не мешаем —
            // хаб можно открыть и здесь (F4), а Trigger.update в меню не fires.
            if(!menuHidden){
                menuHidden = true;
                for(Win w : all) if(w.root != null) w.root.visible = false;
            }
            return;
        }
        menuHidden = false;
        MKUKICSettings s = MKUKICSettings.s();
        boolean vis = s.enabled && s.qolEnabled && !Core.scene.hasDialog();
        for(Win w : all){
            if(w.root == null) continue;
            boolean show = vis && w.open;
            if(show && !w.root.visible) w.root.toFront();
            w.root.visible = show;
            if(show) clamp(w.root);
        }
    }

    /** Окна живут на сцене; при выгрузке игры прячем их. */
    public static void dispose(){
        for(Win w : all){
            if(w.root != null){
                w.root.remove();
                w.root = null;
                w.built = false;
                w.open = false;
            }
        }
    }

    // ============================ ХАБ ============================

    private static void buildHub(Table t){
        t.add("[#8b94a5]Плавающие окна MKUKIC QoL. Открыто несколько окон одновременно — нормально:[]").left().wrap().width(330f).padBottom(6f).row();
        for(Win w : all){
            if(w.id.equals("hub")) continue;
            final Win fw = w;
            t.table(c -> {
                c.left();
                c.button(fw.title, MKUKICSkin.navBtn, fw::toggle)
                    .checked(b -> fw.open).minWidth(210f).height(34f).pad(1.5f).left();
            }).left().row();
        }
        t.image(MKUKICSkin.divSoft).height(2f).growX().pad(7f, 2f, 7f, 2f).row();
        t.table(c -> {
            c.left();
            c.button("Закрыть все", MKUKICSkin.actBtn, QolWindows::closeAll).minWidth(150f).height(32f).pad(2f);
            c.button("Сброс позиций", MKUKICSkin.actBtn, () -> {
                resetPositions();
                OverlayUI.resetPositions();
            }).minWidth(150f).height(32f).pad(2f);
        }).left().row();
        t.add("[#7e8798]Позиции окон сохраняются автоматически. F4 — открыть/закрыть этот хаб.\nПеретаскивай окна за заголовок, «–» — свернуть.").left().wrap().width(330f).padTop(8f).row();
    }

    // ============================ ОБЩЕЕ ============================

    static void clamp(Element e){
        if(Core.scene == null) return;
        e.setPosition(
            Mathf.clamp(e.x, 0f, Math.max(0f, Core.scene.getWidth() - e.getWidth())),
            Mathf.clamp(e.y, 0f, Math.max(0f, Core.scene.getHeight() - e.getHeight())));
    }

    static void makeDraggable(Element target, Element handle, Runnable onSave){
        handle.addListener(new InputListener(){
            float ox, oy;
            @Override
            public boolean touchDown(InputEvent event, float x, float y, int pointer, KeyCode button){
                ox = x;
                oy = y;
                target.toFront();
                return true;
            }
            @Override
            public void touchDragged(InputEvent event, float x, float y, int pointer){
                target.setPosition(target.x + (x - ox), target.y + (y - oy));
                clamp(target);
            }
            @Override
            public void touchUp(InputEvent event, float x, float y, int pointer, KeyCode button){
                onSave.run();
            }
        });
    }

    /** Прыжок камерой (или телепорт, если разрешено) к мировой точке. */
    public static void jumpTo(float wx, float wy){
        if(player == null) return;
        if(player.dead()){
            // наблюдатель — свободная камера
            Core.camera.position.set(wx, wy);
        }else if(player.admin || !net.client()){
            // хост/одиночная игра/админ — как в меню MKUKIC: телепорт юнита
            if(player.unit() != null){
                player.unit().set(wx, wy);
                Core.camera.position.set(wx, wy);
            }
        }else{
            MKUKICMod.toast("[lightgray]Точка: [accent]" + World.toTile(wx) + ", " + World.toTile(wy) + "[lightgray] (прыжок доступен наблюдателям/админам)");
            Core.camera.position.set(wx, wy);
        }
    }

    /** Общий заголовок секции внутри окна. */
    public static void section(Table t, String text){
        t.add("[accent]" + text).left().padTop(4f).row();
        t.image(Tex.whiteui, Pal.accent).height(1f).growX().pad(2f, 0f, 4f, 0f).row();
    }

    /** Общий текстовый world-draw (как в EspRenderer). */
    public static void worldText(String text, float x, float y, arc.graphics.Color color){
        if(text == null || text.isEmpty()) return;
        arc.graphics.g2d.Font font = Fonts.outline;
        arc.graphics.g2d.GlyphLayout layout = arc.util.pooling.Pools.obtain(arc.graphics.g2d.GlyphLayout.class, arc.graphics.g2d.GlyphLayout::new);
        boolean ints = font.usesIntegerPositions();
        font.setUseIntegerPositions(false);
        font.getData().setScale(0.25f / Scl.scl(1f));
        layout.setText(font, text);
        font.setColor(color);
        font.draw(text, x, y, 0, arc.util.Align.center, false);
        arc.graphics.g2d.Draw.reset();
        arc.util.pooling.Pools.free(layout);
        font.getData().setScale(1f);
        font.setColor(arc.graphics.Color.white);
        font.setUseIntegerPositions(ints);
    }

    /** Кадровый счётчик для редких обновлений. */
    static boolean every(float frames){
        return ((int)Time.time) % (int)frames == 0;
    }
}
