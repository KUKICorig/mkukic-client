package oneunit;

import arc.struct.*;

/**
 * Все настройки режима. Файл settings.json создаётся автоматически и полностью редактируется вручную.
 * Поля, которых нет в файле, берутся из значений по умолчанию.
 */
public class Settings{
    /** classic - одна жизнь, respawn - жизни + очки (War Thunder). Переключается /mode. */
    public String defaultMode = "respawn";

    /** Карты-арены. /start берёт следующую по кругу. Имена - как в /maps (без .msav). */
    public Seq<String> arenaMaps = Seq.with("Arena");
    /** Карта, на которую возвращаемся после матча ("" - остаёмся на арене). */
    public String lobbyMap = "";

    /** Команды, между которыми раскидываем игроков. 2+ команд, имена ванильных team. */
    public Seq<String> teams = Seq.with("sharded", "crux");
    /** Автоматически выравнивать состав команд при /join без указания команды. */
    public boolean autoBalance = true;
    /** Автоматически добавлять вошедших на сервер в лобби. */
    public boolean autoJoin = true;
    /** Минимум игроков для /start. */
    public int minPlayers = 2;
    /** Запускать драфт автоматически, когда все игроки нажали "Готов". */
    public boolean autoStartWhenReady = false;

    /** Секунд на драфт. По истечении невыбравшим выдаётся автопик. */
    public int draftSeconds = 45;
    /** Секунд показа финального состава перед боем. */
    public int countdownSeconds = 6;
    /** Лимит матча в минутах (0 - без лимита). По истечении побеждает команда с большим счётом. */
    public int matchMinutes = 15;
    /** Сколько секунд показывать итоговую таблицу перед возвратом в лобби. */
    public int endScreenSeconds = 12;
    public boolean autoReturnToLobby = true;

    /** Удалять ядра с арены при старте (ядра не нужны, победа по юнитам). */
    public boolean removeCores = true;
    /** Показывать пики врагов во время драфта (false - видно только свою команду). */
    public boolean showEnemyPicks = true;
    /** Разрешить смену юнита вживую через /pick без смерти (обычно false). */
    public boolean allowLiveSwitch = false;

    public Draft draft = new Draft();
    public Respawn respawn = new Respawn();
    public Hud hud = new Hud();
    public Tweaks tweaks = new Tweaks();

    /** Точки спавна и точки захвата по картам. Заполняется вручную или /arena addspawn. */
    public ObjectMap<String, MapConfig> maps = new ObjectMap<>();

    public static class Draft{
        /** Максимальный тир, доступный на первом (бесплатном) драфте. 7 - можно всё. */
        public int maxTier = 7;
        /** Списывать ли очки за первый пик (true - драфт с бюджетом startPoints). */
        public boolean chargePoints = false;
        /** Разрешить двум игрокам одной команды брать одинаковый юнит. */
        public boolean allowDuplicates = true;
        /** Тир, который открыт в меню по умолчанию. */
        public int defaultTier = 1;
        /** Автопик при истечении времени: true - сильнейший доступный, false - самый дешёвый. */
        public boolean autoPickStrongest = false;
    }

    public static class Respawn{
        /** Жизней на матч в режиме respawn. В classic всегда 1. */
        public int lives = 3;
        /** Стартовые очки. */
        public int startPoints = 300;
        /** Очки за убийство (плюс половина цены юнита жертвы). */
        public int killPoints = 120;
        /** Очки за помощь (ассист). */
        public int assistPoints = 45;
        /** Очки за каждые 1000 нанесённого урона. */
        public float damagePointsPer1000 = 10f;
        /** Пассивные очки в секунду за живого юнита (0 - выключено). */
        public float pointsPerSecond = 0f;
        /** Очки в секунду за удержание точки захвата. */
        public float capturePointsPerSecond = 12f;
        /** Задержка перед открытием меню респавна, сек. */
        public float respawnDelay = 3f;
        /** Через сколько секунд меню респавна выберет юнита автоматически. */
        public float respawnTimeout = 25f;
        /** Если игрок закрыл меню респавна - через сколько секунд открыть снова. */
        public float menuReopenDelay = 5f;
        /** Секунды неуязвимости после спавна. */
        public float spawnProtection = 3f;
        /** Доля стоимости юнита, возвращаемая очками при смерти (0..1). */
        public float refundOnDeath = 0f;
        /** Сколько процентов очков теряется при смерти (0..100). */
        public float pointsLossOnDeath = 0f;
        /** Доля урона по врагу, необходимая для ассиста. */
        public float assistThreshold = 0.15f;
        /** Окно учёта урона для киллера/ассиста, сек. */
        public float damageMemory = 12f;
        /** Ограничить потолок тира: тир первого пика + 1. */
        public boolean limitTierGrowth = false;
    }

    public static class Hud{
        public boolean enabled = true;
        /** Как часто обновлять HUD игрока, сек. */
        public float interval = 0.5f;
        /** Показывать строку с очками/жизнями в лобби. */
        public boolean lobbyHud = true;
        /** Уведомления об убийствах в чат. */
        public boolean killFeed = true;
    }

    /** Тонкая настройка правил карты. Всё применяется при старте матча. */
    public static class Tweaks{
        public boolean removeBuilding = true;
        public boolean removeMining = true;
        public boolean blockPossession = true;
        public boolean disableWorldProcessors = true;
        public boolean disableLogicControl = true;
        public boolean disableSchematics = true;
        /** Запретить таскать блоки/юнитов грузовыми юнитами. */
        public boolean blockPayloads = true;
        /** Запретить командовать чужими/ИИ юнитами. */
        public boolean blockUnitCommands = true;
        public int unitCap = 200;
        /** Скрывать маркеры спавна на карте. */
        public boolean hideSpawns = true;
        /** Огонь/взрывы реакторов на арене. */
        public boolean fire = false;
        public boolean reactorExplosions = false;
        /** Радиус разброса спавна вокруг точки, тайлов. */
        public float spawnSpread = 2f;
        /** Наводить камеру наблюдателя на центр арены после смерти. */
        public boolean spectatorCamera = true;
    }

    public static class MapConfig{
        /** Точки спавна по командам: "x,y" в тайлах. Несколько точек - спавн по кругу. */
        public ObjectMap<String, Seq<String>> spawns = new ObjectMap<>();
        /** Точки захвата (опционально). */
        public Seq<Zone> zones = new Seq<>();
    }

    public static class Zone{
        public String name = "Точка";
        public int x = 0;
        public int y = 0;
        /** Радиус в тайлах. */
        public float radius = 6f;
    }
}
