package mkukic.client;

import arc.*;
import arc.func.*;
import arc.graphics.*;
import arc.graphics.g2d.*;
import arc.math.*;
import arc.math.geom.*;
import arc.struct.*;
import arc.util.*;
import mindustry.ai.*;
import mindustry.content.*;
import mindustry.core.*;
import mindustry.gen.*;
import mindustry.graphics.*;
import mindustry.input.*;
import mindustry.type.*;
import mindustry.world.*;
import mkukic.*;

import static mindustry.Vars.*;

/**
 * Автопилот до монет (v1.14, дальность x5 в v1.18) с встроенным уклонением от снарядов.
 *
 * В отличие от магнита (телепорт вблизи) автопилот ДОЕЗЖАЕТ до монеты сам:
 *  - летающие юниты — прямое наведение;
 *  - наземные/морские — СВОЙ ограниченный A* ({@link #boundedAstar}) с предикатом unit.canPass,
 *    бюджетом узлов и частичным маршрутом: стены, вода и пропасти объезжаются честно
 *    на дистанциях до {@value #maxRadiusTiles} тайлов (v1.17 и раньше — до 256, а фактически
 *    маршрут строился только до ~220 тайлов, дальше юнит упирался в препятствия);
 *    длинные перегоны режутся на сегменты по {@value #maxSegmentTiles} тайлов, пересчёт
 *    не чаще раза в ~1.5с и при смене цели, цель «липкая» ({@value #selectInterval} кадров);
 *  - уклонение от вражеских снарядов ВСТРОЕНО в тот же вектор движения
 *    (один movePref за кадр: сначала прогресс к цели, при угрозе — доминирует уклон);
 *    для наземных направление уклона проверяется на проходимость (иначе — зеркальная
 *    сторона, иначе — отход назад);
 *  - недостижимая монета (застряли ~2с) помечается «посещённой» (общая память
 *    с магнитом) и автопилот берёт следующую;
 *  - игрок всегда главнее: любое нажатие клавиш движения, диалог/чат или пауза —
 *    автопилот не мешает; пока магнит держит юнита на монете — автопилот ждёт.
 *
 * Движение своего юнита на клиенте авторитетно (как у магнита и PlayerAI) —
 * работает и онлайн; это обычное перемещение со скоростью юнита, не телепорт.
 */
public class CoinPilot{
    private static final Vec2 tmp = new Vec2(), tmp2 = new Vec2(), coinPos = new Vec2(), landing = new Vec2();
    private static final Vec2 segOut = new Vec2();   // v1.18: выход segmentGoal (не путать с tmp2 из addEvade)

    // текущая цель
    private static boolean hasTarget;
    private static float coinX, coinY;     // позиция монеты (может двигаться)
    private static float destX, destY;     // точка приземления/подъезда

    // наземный маршрут (A*)
    private static Seq<Tile> path;
    private static int pathIdx;
    private static float lastRepath = -999f;
    private static float pathForX, pathForY;

    // анти-застревание
    private static float stuckX, stuckY, stuckT;
    private static int stuckN;

    private static final Astar.TileHeuristic tileH = t -> 1f;
    private static final float repathInterval = 90f; // кадров между пересчётами маршрута

    // ======================= v1.18: ДАЛЬНОСТЬ x5 =======================
    // Было: радиус автопилота 8..256 тайлов (по умолчанию 120), а наземный маршрут
    // считался ванильным Astar.pathfind только если манхэттен <= 220 тайлов —
    // дальше юнит шёл «напрямую» и упирался в стены. Стало: 8..1280 тайлов
    // (по умолчанию 600) + собственный ограниченный A* с сегментами и частичным маршрутом.

    /** Минимальный радиус поиска монет, тайлы. */
    public static final float minRadiusTiles = 8f;
    /** Максимальный радиус поиска монет, тайлы (v1.18: было 256 — увеличено в 5 раз). */
    public static final float maxRadiusTiles = 1280f;
    /** Радиус по умолчанию, тайлы (v1.18: было 120). */
    public static final float defaultRadiusTiles = 600f;
    /** Бюджет раскрытия узлов на один вызов A* — защита от фриза на гигантских картах. */
    public static final int astarBudget = 6000;
    /** Максимальная длина одного сегмента маршрута (тайлы по манхэттену). */
    public static final int maxSegmentTiles = 200;
    /** Кадров между полными перевыборами цели (липкость цели на дальних маршрутах). */
    public static final float selectInterval = 20f;
    /** Сколько финалистов пробуем, если точка подъезда не нашлась. */
    public static final int landingAttempts = 4;
    /** Базовый шаг бокового смещения при объезде препятствия, тайлы. */
    public static final int detourStep = 32;
    /** Потолок бокового смещения объезда, тайлы (меньше сегмента, чтобы A* успевал). */
    public static final int maxDetourTiles = 224;

    /** Сколько подряд сегментов не достроено до конца (растёт — смещение объезда увеличивается). */
    private static int detourStreak;

    private static float lastSelect = -999f;
    private static final IntSet landingFailed = new IntSet();
    private static final Seq<Tile> routeBuf = new Seq<>(false, 64);

    // ---------- пул узлов A* (переиспользуем, чтобы не мусорить в кадре) ----------
    static class Node{ float g, f; int x, y, key; }
    private static final Seq<Node> live = new Seq<>();
    private static final Seq<Node> pool = new Seq<>();
    private static final PQueue<Node> open = new PQueue<>(256, (a, b) -> Float.compare(a.f, b.f));
    private static final IntFloatMap gCost = new IntFloatMap();
    private static final IntIntMap parent = new IntIntMap();
    private static final IntSet closed = new IntSet();
    private static final IntSeq keysBuf = new IntSeq();   // цепочка родителей (стоп -> цель)
    private static Unit passUnit;                          // юнит для предиката проходимости
    /** Переиспользуемый предикат (иначе на каждый пересчёт маршрута — новая лямбда). */
    private static final Passable unitPass = (x, y) -> passUnit != null && passUnit.canPass(x, y);
    private static final GridPath gridResult = new GridPath();

    // ======================= ЧИСТЫЕ ФУНКЦИИ (тестируются) =======================

    /**
     * Насколько снаряд летит точно в нас: cos угла между вектором «снаряд->мы»
     * и скоростью снаряда. 1 = летит прямо в нас, <=0 = мимо/от нас.
     */
    public static float aimFactor(float ax, float ay, float bvx, float bvy){
        float len = Mathf.len(ax, ay), vl = Mathf.len(bvx, bvy);
        if(len < 0.001f || vl < 0.001f) return 0f;
        return (ax * bvx + ay * bvy) / (len * vl);
    }

    /** Знак стороны уклонения: перпендикуляр должен уводить ОТ линии огня. */
    public static float sideSign(float px, float py, float ax, float ay){
        return (px * ax + py * ay) < 0f ? -1f : 1f;
    }

    /** Вес угрозы: 1 вплотную, 0 на границе радиуса. */
    public static float evadeWeight(float dist, float radius){
        if(radius <= 0f) return 0f;
        return 1f - Mathf.clamp(dist / radius);
    }

    /**
     * Радиус поиска в мировых единицах (чистая функция — тестируется).
     * Защита от битого settings.json: NaN Mathf.clamp НЕ ловит (любое сравнение с NaN
     * даёт false, и радиус остался бы NaN — то есть «фильтр дальности выключен»),
     * поэтому подменяем его дефолтом. ±Infinity клампятся штатно.
     */
    public static float radiusWorld(float tiles){
        if(Float.isNaN(tiles)) tiles = defaultRadiusTiles;
        return tilesize * Mathf.clamp(tiles, minRadiusTiles, maxRadiusTiles);
    }

    /** Манхэттен-расстояние в тайлах (чистая функция — тестируется). */
    public static int manhattan(int x1, int y1, int x2, int y2){
        return Math.abs(x1 - x2) + Math.abs(y1 - y2);
    }

    /**
     * Промежуточная точка сегмента: если до цели дальше {@link #maxSegmentTiles},
     * берём точку на линии к цели, чтобы A* искал в узком коридоре и укладывался в бюджет.
     * Возвращает координаты в out (тайлы); чистая функция — тестируется.
     */
    public static void segmentGoal(int fx, int fy, int tx, int ty, int w, int h, arc.math.geom.Vec2 out){
        int md = manhattan(fx, fy, tx, ty);
        if(md <= maxSegmentTiles || w <= 0 || h <= 0){
            out.set(tx, ty);
            return;
        }
        float dx = tx - fx, dy = ty - fy;
        float len = Mathf.len(dx, dy);
        if(len < 0.001f){
            out.set(tx, ty);
            return;
        }
        // 0.7 — чтобы диагональный сегмент оставался в пределах maxSegmentTiles по манхэттену
        float k = maxSegmentTiles * 0.7f / len;
        out.set(Mathf.clamp(fx + Mathf.round(dx * k), 0, w - 1),
                Mathf.clamp(fy + Mathf.round(dy * k), 0, h - 1));
    }

    /**
     * Знаковое смещение объезда в тайлах по числу неудачных сегментов подряд:
     * 0, +32, -32, +64, -64, +96, -96 ... с потолком {@value #maxDetourTiles}.
     * Чередование сторон нужно, чтобы юнит не «тёрся» об одну и ту же стену,
     * когда проход с другой стороны. Чистая функция — тестируется.
     */
    public static int nextDetour(int streak){
        if(streak <= 0) return 0;
        int n = (streak + 1) / 2;                            // 1,1,2,2,3,3,...
        int mag = Math.min(n * detourStep, maxDetourTiles);
        return (streak % 2 == 1) ? mag : -mag;
    }

    /**
     * Цель сегмента, сдвинутая перпендикулярно направлению на цель ({@code offTiles} — со знаком).
     * Так объезжаются длинные стены: A* ведёт точку маршрута сбоку от линии «мы -> монета».
     * Координаты зажимаются в пределы карты. Чистая функция — тестируется.
     */
    public static void detourGoal(int fx, int fy, int tx, int ty, int w, int h, int offTiles, arc.math.geom.Vec2 out){
        out.set(tx, ty);
        if(offTiles == 0 || w <= 0 || h <= 0) return;
        float dx = tx - fx, dy = ty - fy;
        float len = Mathf.len(dx, dy);
        if(len < 0.001f) return;
        float nx = -dy / len, ny = dx / len;                 // нормаль к направлению
        out.set(Mathf.clamp(Mathf.round(tx + nx * offTiles), 0, w - 1),
                Mathf.clamp(Mathf.round(ty + ny * offTiles), 0, h - 1));
    }

    /**
     * Порог анти-застревания (в тактах по 30 кадров): пока идёт объезд — ждём дольше,
     * иначе юнит бросал бы монету, не успев объехать стену. Чистая функция — тестируется.
     */
    public static int stuckLimit(int detourStreak){
        return detourStreak > 0 ? 10 : 4;                    // ~5с в объезде, ~2с обычно
    }

    /** Проходимость тайла — интерфейс, чтобы A* можно было гонять на чистой сетке в тестах. */
    public interface Passable{ boolean canPass(int x, int y); }

    /** Результат ограниченного A* (один переиспользуемый экземпляр). */
    public static class GridPath{
        /** Пары (x, y) от старта к цели; включает стартовый тайл. */
        public final IntSeq xy = new IntSeq();
        /** Дошли ли ровно до цели (false = маршрут частичный, ведёт максимально близко). */
        public boolean reached;
        /** Сколько узлов раскрыто (для контроля бюджета). */
        public int expanded;
        /** Конечная тайловая точка маршрута. */
        public int endX, endY;

        void reset(){
            xy.clear();
            reached = false;
            expanded = 0;
            endX = endY = 0;
        }
    }

    /**
     * Ограниченный A* по сетке тайлов (v1.18).
     *
     * Зачем свой, а не ванильный {@code Astar.pathfind}:
     *  - у ванили НЕТ бюджета узлов: на недостижимой цели он вычерпает всю карту,
     *    а каждый вызов ещё и заполняет нулями массив стоимости размером с карту;
     *  - здесь есть бюджет ({@code budget}) и «частичный маршрут»: если цель не достигнута,
     *    возвращаем путь к самой близкой к цели достижимой точке — юнит честно едет
     *    до препятствия и перепланирует маршрут с нового места (сегментная навигация);
     *  - узлы берутся из пула, память — в Int-картах, без аллокаций на карту целиком.
     *
     * @return переиспользуемый {@link GridPath}; {@code xy} пуст, если путь не построен.
     */
    public static GridPath boundedAstar(int sx, int sy, int ex, int ey, int w, int h, int budget, Passable pass){
        GridPath res = gridResult;
        res.reset();
        pool.addAll(live);
        live.clear();
        gCost.clear();
        parent.clear();
        closed.clear();
        open.clear();

        if(pass == null || budget <= 0 || w <= 0 || h <= 0) return res;
        if(sx < 0 || sy < 0 || ex < 0 || ey < 0 || sx >= w || sy >= h || ex >= w || ey >= h) return res;

        int startKey = Point2.pack(sx, sy);
        int goalKey = Point2.pack(ex, ey);

        Node start = node(startKey, sx, sy);
        start.g = 0f;
        start.f = manhattan(sx, sy, ex, ey);
        gCost.put(startKey, 0f);
        open.add(start);

        int bestKey = startKey, bestX = sx, bestY = sy;
        float bestH = start.f;
        boolean found = false;

        while(!open.empty() && res.expanded < budget){
            Node cur = open.poll();
            if(cur == null) break;
            if(closed.contains(cur.key)) continue;      // устаревшая запись очереди (ленивое удаление)
            closed.add(cur.key);
            res.expanded++;

            if(cur.key == goalKey){
                found = true;
                bestKey = goalKey; bestX = ex; bestY = ey;
                break;
            }
            for(int d = 0; d < 4; d++){
                int nx = cur.x + Geometry.d4x[d], ny = cur.y + Geometry.d4y[d];
                if(nx < 0 || ny < 0 || nx >= w || ny >= h) continue;
                int nk = Point2.pack(nx, ny);
                if(closed.contains(nk)) continue;
                if(!pass.canPass(nx, ny)) continue;
                float ng = cur.g + 1f;
                if(ng < gCost.get(nk, Float.POSITIVE_INFINITY)){
                    gCost.put(nk, ng);
                    parent.put(nk, cur.key);
                    float hh = manhattan(nx, ny, ex, ey);
                    Node nn = node(nk, nx, ny);
                    nn.g = ng;
                    nn.f = ng + hh;
                    if(hh < bestH){
                        bestH = hh; bestKey = nk; bestX = nx; bestY = ny;
                    }
                    open.add(nn);
                }
            }
        }

        res.reached = found;
        res.endX = bestX;
        res.endY = bestY;
        // ВАЖНО: IntSeq.reverse() переворачивает ПЛОСКИЙ массив по элементам и меняет
        // пары (x, y) местами, поэтому идём по цепочке родителей в буфер и пишем пары
        // сразу в порядке «старт -> цель».
        keysBuf.clear();
        int key = bestKey;
        int guard = 0;
        while(key != startKey && guard++ <= budget + 4){
            keysBuf.add(key);
            key = parent.get(key, startKey);
        }
        res.xy.add(sx, sy);
        for(int i = keysBuf.size - 1; i >= 0; i--){
            int k = keysBuf.get(i);
            res.xy.add(Point2.x(k), Point2.y(k));       // без аллокации Point2
        }
        return res;
    }

    private static Node node(int key, int x, int y){
        Node n = pool.isEmpty() ? new Node() : pool.pop();
        n.key = key; n.x = x; n.y = y; n.g = 0f; n.f = 0f;
        live.add(n);
        return n;
    }

    // ======================= СОСТОЯНИЕ =======================

    public static boolean isActive(){
        try{
            return MKUKICSettings.s().coinPilot && state != null && state.isGame();
        }catch(Throwable t){
            return false;
        }
    }

    public static void reset(){
        hasTarget = false;
        path = null;
        pathIdx = 0;
        stuckN = 0;
        lastSelect = -999f;          // v1.18: следующий кадр — полный перевыбор цели
        landingFailed.clear();
        detourStreak = 0;            // v1.18: сброс счётчика объезда
    }

    public static void toggle(){
        MKUKICSettings s = MKUKICSettings.s();
        s.coinPilot = !s.coinPilot;
        MKUKICSettings.save();
        if(s.coinPilot) reset();
        MKUKICMod.toast(s.coinPilot
            ? "[gold]" + (char)Iconc.play + " [white]Автопилот до монет ВКЛ (уклонение: " + (s.coinPilotDodge ? "вкл" : "выкл") + ")"
            : "[lightgray]Автопилот до монет ВЫКЛ");
    }

    /** Свой юнит, которым можно управлять (как eligible у магнита). */
    static Unit pilotUnit(){
        try{
            if(player == null || player.dead()) return null;
            Unit u = player.unit();
            if(u == null || u.dead() || u instanceof BlockUnitc) return null;
            if(!u.isLocal() || u.controller() != player) return null;
            if(u.type == null || !u.type.playerControllable) return null;
            return (Float.isFinite(u.x) && Float.isFinite(u.y)) ? u : null;
        }catch(Throwable t){
            return null;
        }
    }

    static boolean inputBlocked(){
        try{
            return (Core.scene != null && (Core.scene.hasField() || Core.scene.hasKeyboard() || Core.scene.hasDialog()))
                || (control != null && control.input != null && control.input.locked());
        }catch(Throwable t){
            return false;
        }
    }

    /** Игрок сам жмёт клавиши движения — не мешаем. */
    static boolean playerMoving(){
        try{
            if(control == null || control.input == null) return false;
            if(control.input instanceof DesktopInput d) return !d.movement.isZero(0.01f);
            if(control.input instanceof MobileInput m) return !m.movement.isZero(0.01f);
        }catch(Throwable ignored){}
        return false;
    }

    // ======================= ГЛАВНЫЙ ЦИКЛ =======================

    /** Каждый кадр после обновления сущностей (Trigger.afterGameUpdate). */
    public static void lateUpdate(){
        try{
            MKUKICSettings s = MKUKICSettings.s();
            if(!s.coinPilot){
                if(hasTarget) reset();
                return;
            }
            if(state == null || !state.isGame() || state.isPaused()) return;
            Unit u = pilotUnit();
            if(u == null){
                hasTarget = false;
                return;
            }
            if(inputBlocked() || playerMoving()) return;      // игрок главнее
            if(CoinMagnet.isHolding()) return;                  // магнит уже держит монету

            selectTarget(u, s);
            if(!hasTarget){
                return; // стоим; целей нет (или все недоступны)
            }

            Vec2 move = tmp.setZero();
            if(u.isFlying()){
                steer(move, u, destX, destY, 4f);
            }else{
                steerGround(move, u);
            }
            if(s.coinPilotDodge) addEvade(move, u, s);

            if(!move.isZero(0.01f)) u.movePref(move);
            checkStuck(u);
        }catch(Throwable t){
            Log.err("[MKUKIC] CoinPilot: lateUpdate", t);
        }
    }

    // ======================= ВЫБОР ЦЕЛИ =======================

    /**
     * Выбор цели (v1.18 — под радиус до {@value #maxRadiusTiles} тайлов).
     *
     * Два изменения против старой версии:
     *  1) ЛИПКОСТЬ ЦЕЛИ: полный перевыбор — не чаще раза в {@value #selectInterval} кадров.
     *     На дальних маршрутах прежний перевыбор каждый кадр заставлял юнита дёргаться
     *     между двумя примерно равноудалёнными монетами и сбрасывать маршрут.
     *  2) ДЕШЁВЫЙ ОТБОР: сначала выбираем лучшего кандидата только по дистанции/ценности,
     *     а {@code landingFor} (подбор проходимой точки подъезда, до 25 проверок тайлов)
     *     зовём лишь для финалистов — не более {@value #landingAttempts} раз.
     *     При радиусе 1280 тайлов в выбор попадают сотни целей, и прежняя схема
     *     вызывала landingFor для каждой из них КАЖДЫЙ кадр.
     */
    static void selectTarget(Unit u, MKUKICSettings s){
        float radiusW = radiusWorld(s.coinPilotRadius);
        float radiusSq = radiusW * radiusW;

        // 1) текущая цель ещё жива и в радиусе — держимся за неё
        if(hasTarget && Time.time - lastSelect < selectInterval
            && !CoinMagnet.recentlyVisited(coinX, coinY)
            && Mathf.dst2(u.x, u.y, coinX, coinY) <= radiusSq){
            return;
        }
        lastSelect = Time.time;
        landingFailed.clear();

        // 2) полный перевыбор (не более landingAttempts попыток подобрать точку подъезда)
        for(int attempt = 0; attempt < landingAttempts; attempt++){
            int best = -1;
            float nearest = Float.POSITIVE_INFINITY;
            boolean preferredValue = false;
            float bx = 0f, by = 0f;
            for(int i = 0; i < CoinMagnet.targetCount(); i++){
                if(landingFailed.contains(i)) continue;
                if(!CoinMagnet.targetPos(i, coinPos)) continue;
                if(CoinMagnet.recentlyVisited(coinPos.x, coinPos.y)) continue;
                float d = Mathf.dst2(u.x, u.y, coinPos.x, coinPos.y);
                if(d > radiusSq) continue;
                boolean valuable = s.coinPreferHighValue && CoinMagnet.targetValuable(i);
                if(best < 0 || (valuable && !preferredValue) || (valuable == preferredValue && d < nearest)){
                    best = i;
                    nearest = d;
                    preferredValue = valuable;
                    bx = coinPos.x;
                    by = coinPos.y;
                }
            }
            if(best < 0) break;                       // целей в радиусе больше нет
            if(CoinMagnet.landingFor(u, bx, by, landing)){
                coinX = bx;
                coinY = by;
                destX = landing.x;
                destY = landing.y;
                hasTarget = true;
                // цель сменилась/уехала — сбросить маршрут
                if(path != null && (Mathf.dst2(coinX, coinY, pathForX, pathForY) > 64f || pathIdx >= path.size)){
                    path = null;
                }
                return;
            }
            landingFailed.add(best);                  // к этой монете не подъехать — берём следующую
        }
        hasTarget = false;
        path = null;
    }

    // ======================= ДВИЖЕНИЕ =======================

    /** Прямое наведение: вектор к точке, ограниченный скоростью. */
    static void steer(Vec2 move, Unit u, float x, float y, float circle){
        move.set(x - u.x, y - u.y);
        float len = move.len();
        if(len < circle){
            move.setZero();
        }else{
            move.setLength(Math.min(u.speed(), len - circle * 0.5f));
        }
    }

    /**
     * Наземное наведение (v1.18): сегментный ограниченный A* по проходимым тайлам,
     * фолбэк — напрямую к цели.
     *
     * Длинные перегоны (> {@value #maxSegmentTiles} тайлов) режутся на сегменты:
     * цель сегмента — точка на линии к монете, поэтому поиск всегда идёт в узком коридоре
     * и укладывается в бюджет {@value #astarBudget} узлов. Если сегмент не достроен до конца
     * (упёрлись в препятствие), возвращается ЧАСТИЧНЫЙ маршрут — юнит доезжает до конца
     * доступного куска и перепланирует с нового места, а не упирается в стену, как раньше.
     */
    static void steerGround(Vec2 move, Unit u){
        Tile from = world.tileWorld(u.x, u.y);
        Tile to = world.tileWorld(destX, destY);
        if(from == null || to == null){
            steer(move, u, destX, destY, 4f);
            return;
        }
        // маршрут кончился — перепланировать сразу; маршрута нет и прошлая попытка
        // не удалась — ждём repathInterval, чтобы не дёргать A* каждый кадр
        boolean need = path != null ? pathIdx >= path.size : Time.time - lastRepath > repathInterval;
        if(need){
            lastRepath = Time.time;
            path = null;
            pathIdx = 0;
            Seq<Tile> p = planRoute(u, from, to);
            if(p != null && p.size > 0){
                path = p;
                pathForX = coinX;
                pathForY = coinY;
            }
        }
        if(path != null){
            while(pathIdx < path.size){
                Tile wp = path.get(pathIdx);
                if(wp == null){
                    pathIdx++;
                    continue;
                }
                if(u.within(wp.worldx(), wp.worldy(), tilesize * 1.1f)) pathIdx++;
                else break;
            }
            if(pathIdx < path.size){
                Tile wp = path.get(pathIdx);
                if(wp != null){
                    steer(move, u, wp.worldx(), wp.worldy(), 2f);
                    return;
                }
            }
            // маршрут пройден — подъезжаем напрямую (монета могла уехать)
            path = null;
        }
        steer(move, u, destX, destY, 4f);
    }

    /**
     * Построить маршрут наземного юнита к точке (destX, destY) одним сегментом A*.
     * Возвращает переиспользуемый буфер тайлов (без стартового тайла) или null.
     */
    static Seq<Tile> planRoute(Unit u, Tile from, Tile to){
        int w = world.width(), h = world.height();
        if(w <= 0 || h <= 0) return null;
        if(manhattan(from.x, from.y, to.x, to.y) <= 0) return null;

        segmentGoal(from.x, from.y, to.x, to.y, w, h, segOut);   // свой Vec2: tmp2 занят в addEvade
        // объезд применяем только к ПРОМЕЖУТОЧНЫМ сегментам: на финальном подходе
        // цель — сама точка подъезда, иначе юнит не доедет до монеты
        boolean finalApproach = manhattan(from.x, from.y, to.x, to.y) <= maxSegmentTiles;
        if(!finalApproach){
            int off = nextDetour(detourStreak);
            if(off != 0) detourGoal(from.x, from.y, Mathf.round(segOut.x), Mathf.round(segOut.y), w, h, off, segOut);
        }
        int gx = Mathf.clamp((int)segOut.x, 0, w - 1), gy = Mathf.clamp((int)segOut.y, 0, h - 1);

        GridPath gp;
        try{
            passUnit = u;
            gp = boundedAstar(from.x, from.y, gx, gy, w, h, astarBudget, unitPass);
        }catch(Throwable t){
            detourStreak++;
            return null;
        }
        if(gp == null || gp.xy.size < 4){                    // меньше одного шага — стоим, пробуем объезд
            detourStreak++;
            return null;
        }
        if(gp.reached) detourStreak = 0; else detourStreak++; // частичный маршрут — увеличиваем смещение
        routeBuf.clear();
        for(int i = 2; i < gp.xy.size; i += 2){            // i=0 — стартовый тайл, пропускаем
            Tile t = world.tile(gp.xy.get(i), gp.xy.get(i + 1));
            if(t != null) routeBuf.add(t);
        }
        return routeBuf.isEmpty() ? null : routeBuf;
    }

    // ======================= УКЛОНЕНИЕ =======================

    /**
     * Комбинирует уклонение с вектором прогресса (ОДИН movePref за кадр).
     * Срочная угроза (близко) — чистое уклонение; дальняя — смесь 40/60.
     * Наземные: направление уклона проверяется на проходимость.
     */
    static void addEvade(Vec2 move, Unit u, MKUKICSettings s){
        Vec2 evade = tmp2.setZero();
        int hits = 0;
        boolean urgent = false;
        float R = Math.max(40f, s.coinPilotDodgeR);
        for(Bullet b : Groups.bullet){
            if(b == null || b.team() == u.team() || !b.within(u, R)) continue;
            Vec2 bv = b.vel();
            if(bv.isZero(0.01f)) continue;
            float ax = u.x - b.x, ay = u.y - b.y;
            float len = Mathf.len(ax, ay);
            if(len < 1f) continue;
            if(aimFactor(ax, ay, bv.x, bv.y) < 0.5f) continue; // летит мимо

            // перпендикуляр к полёту снаряда, в сторону от линии огня
            float px = -bv.y, py = bv.x;
            float sign = sideSign(px, py, ax, ay);
            px *= sign;
            py *= sign;

            if(!u.isFlying()){
                // наземная адаптация: уклон только в проходимую сторону
                if(!evadePassable(u, px, py)){
                    px = -px;
                    py = -py;
                    if(!evadePassable(u, px, py)){
                        // обе стороны заняты — отход назад от снаряда
                        px = -ax;
                        py = -ay;
                        if(!evadePassable(u, px, py)){
                            px = 0f;
                            py = 0f;
                        }
                    }
                }
            }
            float nl = Mathf.len(px, py);
            if(nl < 0.001f) continue;
            float w = evadeWeight(len, R);
            evade.add(px / nl * w, py / nl * w);
            if(len < 60f) urgent = true;
            if(++hits >= 5) break;
        }
        if(hits == 0 || evade.isZero(0.001f)) return;

        evade.setLength(u.speed());
        if(urgent || move.isZero(0.01f)){
            move.set(evade);
        }else{
            move.setLength(u.speed() * 0.4f);
            move.add(evade).limit(u.speed() * 1.15f);
        }
    }

    /** Проходима ли точка в ~1.5 тайла по направлению уклонения. */
    static boolean evadePassable(Unit u, float dx, float dy){
        try{
            float nl = Mathf.len(dx, dy);
            if(nl < 0.001f) return false;
            float ex = u.x + dx / nl * tilesize * 1.5f, ey = u.y + dy / nl * tilesize * 1.5f;
            Tile t = world.tileWorld(ex, ey);
            return t != null && u.canPass(t.x, t.y);
        }catch(Throwable e){
            return false;
        }
    }

    // ======================= АНТИ-ЗАСТРЯВАНИЕ =======================

    static void checkStuck(Unit u){
        if(Time.time - stuckT < 30f) return;
        float moved = Mathf.dst(u.x, u.y, stuckX, stuckY);
        if(hasTarget && moved < 3f){
            stuckN++;
            if(stuckN >= stuckLimit(detourStreak)){ // ~2с обычно, ~5с пока идёт объезд
                CoinMagnet.markVisited(coinX, coinY);
                hasTarget = false;
                path = null;
                stuckN = 0;
                detourStreak = 0;
            }
        }else{
            stuckN = 0;
        }
        stuckX = u.x;
        stuckY = u.y;
        stuckT = Time.time;
    }

    // ======================= ОТРИСОВКА =======================

    /** Тонкая линия к цели + квадратик точки подъезда + точки маршрута. */
    public static void draw(){
        try{
            if(!MKUKICSettings.s().coinPilot || !hasTarget) return;
            Unit u = pilotUnit();
            if(u == null || state == null || state.isMenu()) return;

            float z = Draw.z();
            float stroke = Lines.getStroke();
            Draw.z(Layer.overlayUI);
            try{
                // маршрут наземного
                if(path != null){
                    Draw.color(Pal.accent, 0.5f);
                    for(int i = pathIdx; i < path.size; i++){
                        Tile wp = path.get(i);
                        if(wp == null) continue;
                        Fill.square(wp.worldx(), wp.worldy(), 1.6f);
                    }
                }
                Draw.color(Color.valueOf("ffd36b"), 0.75f);
                Lines.stroke(1.1f);
                Lines.line(u.x, u.y, destX, destY);
                Lines.square(destX, destY, 4.5f, 45f);
                Lines.circle(coinX, coinY, 6f);
            }finally{
                Draw.color();
                Lines.stroke(stroke);
                Draw.z(z);
            }
        }catch(Throwable ignored){}
    }
}
