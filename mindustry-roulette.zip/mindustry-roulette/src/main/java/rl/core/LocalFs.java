package rl.core;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

/** Реализация {@link Fs} поверх java.nio — работает и в сервере Mindustry (там обычная JVM). */
public final class LocalFs implements Fs {

    private final Path root;

    public LocalFs(String root) {
        this.root = Paths.get(root).toAbsolutePath().normalize();
    }

    public LocalFs(Path root) {
        this.root = root.toAbsolutePath().normalize();
    }

    private Path p(String path) {
        Path r = root.resolve(path).normalize();
        if (!r.startsWith(root)) throw new IllegalArgumentException("path outside of root: " + path);
        return r;
    }

    @Override
    public String read(String path) throws IOException {
        return new String(Files.readAllBytes(p(path)), StandardCharsets.UTF_8);
    }

    @Override
    public void write(String path, String content) throws IOException {
        Path f = p(path);
        if (f.getParent() != null) Files.createDirectories(f.getParent());
        // атомарная запись: сначала в .tmp, потом rename — чтобы не побить конфиг/балансы при краше
        Path tmp = f.resolveSibling(f.getFileName() + ".tmp");
        Files.write(tmp, content.getBytes(StandardCharsets.UTF_8),
                StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING, StandardOpenOption.WRITE);
        try {
            Files.move(tmp, f, java.nio.file.StandardCopyOption.REPLACE_EXISTING);
        } catch (IOException e) {
            Files.write(f, content.getBytes(StandardCharsets.UTF_8),
                    StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING);
            Files.deleteIfExists(tmp);
        }
    }

    @Override
    public void append(String path, String content) throws IOException {
        Path f = p(path);
        if (f.getParent() != null) Files.createDirectories(f.getParent());
        Files.write(f, content.getBytes(StandardCharsets.UTF_8),
                StandardOpenOption.CREATE, StandardOpenOption.APPEND);
    }

    @Override
    public boolean exists(String path) {
        return Files.exists(p(path));
    }

    @Override
    public boolean delete(String path) {
        try {
            return Files.deleteIfExists(p(path));
        } catch (IOException e) {
            return false;
        }
    }

    @Override
    public List<String> list(String dir) {
        List<String> out = new ArrayList<>();
        Path d = p(dir);
        if (!Files.isDirectory(d)) return out;
        try (Stream<Path> s = Files.list(d)) {
            s.forEach(x -> out.add(x.getFileName().toString()));
        } catch (IOException ignored) {
        }
        out.sort(String::compareTo);
        return out;
    }

    @Override
    public boolean isDirectory(String path) {
        return Files.isDirectory(p(path));
    }

    @Override
    public void mkdirs(String path) {
        try {
            Files.createDirectories(p(path));
        } catch (IOException ignored) {
        }
    }

    public Path root() {
        return root;
    }
}
