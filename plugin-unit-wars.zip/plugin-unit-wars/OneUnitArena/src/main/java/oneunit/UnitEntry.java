package oneunit;

import arc.struct.*;
import mindustry.type.*;

/** Одна строка units.json: юнит + тир + цена + множители баланса. */
public class UnitEntry{
    /** Тир 1..7. Тиры 6-7 - усиленные ванильные боссы (см. units.json). */
    public int tier = 1;
    /** Внутреннее имя UnitType (dagger, reign, conquer...). */
    public String unit = "dagger";
    /** Отображаемое имя. Пусто - берётся localizedName юнита. */
    public String name = "";
    /** Цена в очках. 0 - бесплатно (доступен всегда). */
    public int cost = 0;
    /** Множитель максимального здоровья. */
    public float hpMult = 1f;
    /** Множитель исходящего урона (применяется к урону пуль при создании). */
    public float damageMult = 1f;
    /** Множитель скорости передвижения. */
    public float speedMult = 1f;
    /** Дополнительный щит, выдаётся при спавне. */
    public float shield = 0f;
    public boolean enabled = true;
    /** Категория для группировки в меню: mech/tank/air/leg/naval/support. */
    public String category = "mech";
    /** Ванильные статус-эффекты, которые постоянно освежаются на юните (overclock, shielded...). */
    public Seq<String> effects = new Seq<>();

    // runtime, в json не попадает
    public transient UnitType type;
    public transient Seq<StatusEffect> parsedEffects = new Seq<>();

    public String id(){
        return tier + ":" + unit;
    }

    public String display(){
        if(name != null && !name.isEmpty()) return name;
        if(type != null && type.localizedName != null && !type.localizedName.isEmpty()) return type.localizedName;
        return unit;
    }

    public float maxHp(){
        return type == null ? 0f : type.health * hpMult;
    }

    public boolean valid(){
        return type != null && enabled;
    }

    /** Короткая строка характеристик для кнопки в меню. */
    public String stats(){
        StringBuilder sb = new StringBuilder();
        sb.append("[gray]HP[] ").append(Txt.n(maxHp()));
        if(damageMult != 1f) sb.append("  [gray]DMG[] ").append(Math.round(damageMult * 100f)).append("%");
        if(speedMult != 1f) sb.append("  [gray]SPD[] ").append(Math.round(speedMult * 100f)).append("%");
        if(shield > 0) sb.append("  [gray]SH[] ").append(Txt.n(shield));
        return sb.toString();
    }
}
