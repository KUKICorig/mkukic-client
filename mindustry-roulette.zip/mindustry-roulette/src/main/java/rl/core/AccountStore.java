package rl.core;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Хранилище аккаунтов. Ключ — ID игрока (uuid в Mindustry), НИКАКИХ ников:
 * ники пишутся только в лог (см. {@link GameLog}).
 *
 * Файл: accounts.json в папке мода.
 */
public class AccountStore {

    /** Данные одного аккаунта (только ID и цифры). */
    public static class Account {
        public String id;
        public long balance;
        public long spins;
        public long wins;
        public long wagered;
        public long won;      // суммарно выплачено игроку
        public long lost;     // суммарно ушло в дом
        public long bestWin;
        public String clientSeed = "";
        public String day = "";      // текущие сутки (yyyy-MM-dd) для лимитов
        public long dayWagered;
        public long dayLost;
        public long dayWon;
        public long createdAt;
        public long updatedAt;
        public long lastSpinAt;
        public long lastIncomeAt;

        public Map<String, Object> toMap() {
            Map<String, Object> m = Json.obj();
            m.put("id", id);
            m.put("balance", balance);
            m.put("spins", spins);
            m.put("wins", wins);
            m.put("wagered", wagered);
            m.put("won", won);
            m.put("lost", lost);
            m.put("bestWin", bestWin);
            m.put("clientSeed", clientSeed);
            m.put("day", day);
            m.put("dayWagered", dayWagered);
            m.put("dayLost", dayLost);
            m.put("dayWon", dayWon);
            m.put("createdAt", createdAt);
            m.put("updatedAt", updatedAt);
            m.put("lastSpinAt", lastSpinAt);
            m.put("lastIncomeAt", lastIncomeAt);
            return m;
        }

        @SuppressWarnings("unchecked")
        public static Account fromMap(Map<String, Object> m) {
            Account a = new Account();
            Json.Node n = Json.Node.of(m);
            a.id = n.str("id", "");
            a.balance = n.lng("balance", 0);
            a.spins = n.lng("spins", 0);
            a.wins = n.lng("wins", 0);
            a.wagered = n.lng("wagered", 0);
            a.won = n.lng("won", 0);
            a.lost = n.lng("lost", 0);
            a.bestWin = n.lng("bestWin", 0);
            a.clientSeed = n.str("clientSeed", "");
            a.day = n.str("day", "");
            a.dayWagered = n.lng("dayWagered", 0);
            a.dayLost = n.lng("dayLost", 0);
            a.dayWon = n.lng("dayWon", 0);
            a.createdAt = n.lng("createdAt", 0);
            a.updatedAt = n.lng("updatedAt", 0);
            a.lastSpinAt = n.lng("lastSpinAt", 0);
            a.lastIncomeAt = n.lng("lastIncomeAt", 0);
            return a;
        }
    }

    private final Fs fs;
    private final String file;
    private final Object lock = new Object();
    private final Map<String, Account> accounts = new LinkedHashMap<>();
    private long nonce = 0;
    private boolean dirty = false;
    private long lastSave = 0;

    public AccountStore(Fs fs, String file) {
        this.fs = fs;
        this.file = file;
    }

    public void load() {
        synchronized (lock) {
            accounts.clear();
            String raw = fs.readOr(file, "");
            if (raw.trim().isEmpty()) return;
            Json.Node root = Json.Node.of(Json.parse(raw));
            nonce = root.lng("nonce", 0);
            Json.Node accs = root.child("accounts");
            for (Map.Entry<String, Object> e : accs.map().entrySet()) {
                if (!(e.getValue() instanceof Map)) continue;
                @SuppressWarnings("unchecked")
                Account a = Account.fromMap((Map<String, Object>) e.getValue());
                if (a.id == null || a.id.isEmpty()) a.id = e.getKey();
                accounts.put(a.id, a);
            }
        }
    }

    public String save() {
        synchronized (lock) {
            Map<String, Object> root = Json.obj();
            root.put("nonce", nonce);
            root.put("savedAt", System.currentTimeMillis());
            Map<String, Object> accs = Json.obj();
            for (Map.Entry<String, Account> e : accounts.entrySet()) accs.put(e.getKey(), e.getValue().toMap());
            root.put("accounts", accs);
            String json = Json.write(root);
            boolean ok = fs.writeQuiet(file, json);
            dirty = false;
            lastSave = System.currentTimeMillis();
            return ok ? null : "не удалось записать " + file;
        }
    }

    /** Сохранить, если накопилось (не чаще раза в minIntervalMs). */
    public void saveThrottled(long minIntervalMs) {
        synchronized (lock) {
            if (!dirty) return;
            if (System.currentTimeMillis() - lastSave < minIntervalMs) return;
        }
        save();
    }

    public void markDirty() {
        synchronized (lock) { dirty = true; }
    }

    public Account get(String id) {
        synchronized (lock) { return accounts.get(id); }
    }

    public Account getOrCreate(String id, long startingBalance, String defaultClientSeed) {
        synchronized (lock) {
            Account a = accounts.get(id);
            if (a == null) {
                a = new Account();
                a.id = id;
                a.balance = startingBalance;
                a.clientSeed = defaultClientSeed == null ? "" : defaultClientSeed;
                a.createdAt = System.currentTimeMillis();
                a.updatedAt = a.createdAt;
                accounts.put(id, a);
                dirty = true;
            }
            return a;
        }
    }

    public long balance(String id) {
        synchronized (lock) {
            Account a = accounts.get(id);
            return a == null ? 0 : a.balance;
        }
    }

    public long nextNonce() {
        synchronized (lock) {
            nonce++;
            dirty = true;
            return nonce;
        }
    }

    public long nonce() {
        synchronized (lock) { return nonce; }
    }

    /**
     * Атомарное списание: если баланса не хватает — возвращает false и ничего не меняет.
     */
    public boolean withdraw(String id, long amount) {
        if (amount < 0) return false;
        synchronized (lock) {
            Account a = accounts.get(id);
            if (a == null || a.balance < amount) return false;
            a.balance -= amount;
            a.updatedAt = System.currentTimeMillis();
            dirty = true;
            return true;
        }
    }

    public void deposit(String id, long amount) {
        if (amount == 0) return;
        synchronized (lock) {
            Account a = accounts.get(id);
            if (a == null) {
                a = new Account();
                a.id = id;
                a.createdAt = System.currentTimeMillis();
                accounts.put(id, a);
            }
            a.balance += amount;
            a.updatedAt = System.currentTimeMillis();
            dirty = true;
        }
    }

    /** Перевод между ID. Возвращает false если у отправителя не хватает. */
    public boolean transfer(String from, String to, long amount) {
        if (amount <= 0) return false;
        synchronized (lock) {
            Account a = accounts.get(from);
            if (a == null || a.balance < amount) return false;
            a.balance -= amount;
            a.updatedAt = System.currentTimeMillis();
            Account b = accounts.get(to);
            if (b == null) {
                b = new Account();
                b.id = to;
                b.createdAt = System.currentTimeMillis();
                accounts.put(to, b);
            }
            b.balance += amount;
            b.updatedAt = System.currentTimeMillis();
            dirty = true;
            return true;
        }
    }

    public void setBalance(String id, long amount) {
        synchronized (lock) {
            Account a = getOrCreateInternal(id);
            a.balance = amount;
            a.updatedAt = System.currentTimeMillis();
            dirty = true;
        }
    }

    private Account getOrCreateInternal(String id) {
        Account a = accounts.get(id);
        if (a == null) {
            a = new Account();
            a.id = id;
            a.createdAt = System.currentTimeMillis();
            accounts.put(id, a);
        }
        return a;
    }

    /** Сброс суточных лимитов, если сменился день. */
    public void rollDayIfNeeded(Account a, String today) {
        synchronized (lock) {
            if (a.day == null || !a.day.equals(today)) {
                a.day = today;
                a.dayWagered = 0;
                a.dayLost = 0;
                a.dayWon = 0;
                dirty = true;
            }
        }
    }

    public List<Account> all() {
        synchronized (lock) { return new ArrayList<>(accounts.values()); }
    }

    public int size() {
        synchronized (lock) { return accounts.size(); }
    }

    /** Топ по выигрышу (или по обороту), для /rl top и админки. */
    public List<Account> top(String sortBy, int limit) {
        List<Account> list = all();
        Comparator<Account> cmp;
        switch (sortBy == null ? "won" : sortBy) {
            case "balance": cmp = Comparator.comparingLong((Account a) -> a.balance).reversed(); break;
            case "wagered": cmp = Comparator.comparingLong((Account a) -> a.wagered).reversed(); break;
            case "best": cmp = Comparator.comparingLong((Account a) -> a.bestWin).reversed(); break;
            case "spins": cmp = Comparator.comparingLong((Account a) -> a.spins).reversed(); break;
            default: cmp = Comparator.comparingLong((Account a) -> a.won).reversed();
        }
        list.sort(cmp);
        return list.subList(0, Math.min(limit, list.size()));
    }

    public Map<String, Object> totals() {
        synchronized (lock) {
            long bal = 0, wagered = 0, won = 0, lost = 0, spins = 0, wins = 0, best = 0;
            for (Account a : accounts.values()) {
                bal += a.balance;
                wagered += a.wagered;
                won += a.won;
                lost += a.lost;
                spins += a.spins;
                wins += a.wins;
                best = Math.max(best, a.bestWin);
            }
            Map<String, Object> m = Json.obj();
            m.put("accounts", accounts.size());
            m.put("totalBalance", bal);
            m.put("totalWagered", wagered);
            m.put("totalPaidOut", won);
            m.put("totalLostToHouse", lost);
            m.put("spins", spins);
            m.put("wins", wins);
            m.put("bestWin", best);
            m.put("houseEdge", wagered > 0 ? Config.round2((double) (wagered - won) / wagered * 100.0) : 0.0);
            m.put("actualRtp", wagered > 0 ? Config.round2((double) won / wagered * 100.0) : 0.0);
            m.put("nonce", nonce);
            m.put("lastSave", lastSave);
            return m;
        }
    }
}
