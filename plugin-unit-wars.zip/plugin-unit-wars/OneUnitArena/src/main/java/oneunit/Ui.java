package oneunit;

import arc.struct.*;
import mindustry.game.*;
import mindustry.gen.*;
import mindustry.ui.*;
import mindustry.ui.builder.*;
import mindustry.ui.builder.UiBuilder.*;

import static mindustry.ui.builder.UiBuilder.*;

/**
 * Весь интерфейс строится на сервере через UiBuilder/MenuBuilder (Mindustry v160+).
 * Клиентский мод не нужен: игрок видит нормальные диалоги Mindustry с иконками юнитов.
 *
 * Важно: свойства ячейки (growX/pad/width/...) ставятся на САМОМ узле до add(),
 * потому что add() возвращает родительскую таблицу, а не ячейку.
 */
public class Ui{
    public static Ui inst;

    /** ID меню выдаёт Menus.registerMenuBuilder - произвольные числа использовать нельзя. */
    public static int LOBBY, DRAFT, ROSTER, SCORE, HELP, RESULTS, RESPAWN;

    /** Какое меню сейчас открыто у игрока (uuid -> id). */
    private final ObjectMap<String, Integer> open = new ObjectMap<>();

    public Ui(){
        inst = this;
        LOBBY = Menus.registerMenuBuilder((p, res) -> handle(p, LOBBY, res));
        DRAFT = Menus.registerMenuBuilder((p, res) -> handle(p, DRAFT, res));
        ROSTER = Menus.registerMenuBuilder((p, res) -> handle(p, ROSTER, res));
        SCORE = Menus.registerMenuBuilder((p, res) -> handle(p, SCORE, res));
        HELP = Menus.registerMenuBuilder((p, res) -> handle(p, HELP, res));
        RESULTS = Menus.registerMenuBuilder((p, res) -> handle(p, RESULTS, res));
        RESPAWN = Menus.registerMenuBuilder((p, res) -> handle(p, RESPAWN, res));
    }

    private int[] ids(){
        return new int[]{LOBBY, DRAFT, ROSTER, SCORE, HELP, RESULTS, RESPAWN};
    }

    // ------------------------------------------------------------------ каркас

    private void show(Player p, int id, String title, TableBuilder body, boolean fill){
        if(p == null || p.con == null || !p.isAdded()) return;
        Integer prev = open.get(p.uuid());
        if(prev != null && prev != id) Call.hideMenuBuilder(p.con, prev);
        open.put(p.uuid(), id);

        TableBuilder root = table();
        root.add(body.id("body").growX().growY().align("top"));
        MenuBuilder.of(root).id(id).title(title).hideOnClick(false).hideExisting(true).fillScreen(fill).show(p);
    }

    private void update(Player p, int id, TableBuilder body){
        if(p == null || p.con == null || !p.isAdded()) return;
        Integer cur = open.get(p.uuid());
        if(cur == null || cur != id) return;
        MenuBuilder.of(body).id(id).update(p, "body");
    }

    public void close(Player p, int id){
        if(p == null || p.con == null) return;
        Call.hideMenuBuilder(p.con, id);
        Integer cur = open.get(p.uuid());
        if(cur != null && cur == id) open.remove(p.uuid());
    }

    public void closeAll(Player p){
        if(p == null) return;
        for(int id : ids()) close(p, id);
        open.remove(p.uuid());
    }

    public void closeAllMenus(){
        Groups.player.each(this::closeAll);
    }

    public void forget(Player p){
        if(p != null) open.remove(p.uuid());
    }

    private String m(String key, Object... args){
        return OneUnit.msg.f(key, args);
    }

    private LabelBuilder head(String text){
        return label(text).style("techLabel").growX().pad(4f).align("left");
    }

    private LabelBuilder hint(String text){
        return label(text).wrap().color("gray").growX().padBottom(6f).align("left");
    }

    private ButtonBuilder btn(String text, String result){
        return button(text).style("cleart").clicked(result).height(46f).pad(2f);
    }

    // ------------------------------------------------------------------ лобби

    public void lobby(Player p){
        show(p, LOBBY, m("ui.lobbyTitle"), lobbyBody(p), true);
    }

    public void refreshLobbyAll(){
        Groups.player.each(p -> {
            Integer cur = open.get(p.uuid());
            if(cur != null && cur == LOBBY) update(p, LOBBY, lobbyBody(p));
        });
    }

    private TableBuilder lobbyBody(Player p){
        Match match = Match.inst;
        ArenaPlayer ap = match.get(p);
        TableBuilder body = table();

        body.add(head(m("ui.lobbyInfo",
            Txt.f(match.respawnMode ? "modeRespawn" : "modeClassic"),
            match.roster.size,
            match.mapName.isEmpty() ? (OneUnit.settings.arenaMaps.isEmpty() ? "-" : OneUnit.settings.arenaMaps.first()) : match.mapName
        ))).row();

        body.add(hint(m("ui.lobbyHint"))).row();
        body.add(teamColumns(p, true).growX()).row();

        TableBuilder buttons = table();
        if(ap == null){
            buttons.add(button(m("ui.join")).style("fullTogglet").clicked("join").width(200f).height(50f).pad(2f));
        }else{
            buttons.add(button(ap.ready ? m("ui.unreadyBtn") : m("ui.readyBtn"))
                .style(ap.ready ? "clearTogglet" : "fullTogglet").checked(ap.ready)
                .clicked("ready").width(210f).height(50f).pad(2f));
            buttons.add(btn(m("ui.leave"), "leave").width(130f));
        }
        buttons.row();
        buttons.add(btn(m("ui.rosterTitle"), "roster").width(210f));
        buttons.add(btn(m("ui.helpTitle"), "help").width(210f));
        buttons.row();
        if(p != null && p.admin){
            buttons.add(button(m("ui.start")).style("fullTogglet").clicked("start")
                .disabled(match.phase != Match.Phase.lobby).width(210f).height(50f).pad(2f));
            buttons.add(btn(m("ui.mode", Txt.f(match.respawnMode ? "modeRespawn" : "modeClassic")), "mode").width(280f));
            if(match.phase != Match.Phase.lobby){
                buttons.row();
                buttons.add(button(m("ui.stop")).style("cleart").clicked("stop").width(210f).height(46f).pad(2f));
            }
        }
        buttons.row();
        buttons.add(btn(m("ui.close"), "close").width(150f));
        body.add(buttons.padTop(8f)).row();

        // выбор команды
        TableBuilder teamRow = table();
        teamRow.add(label(m("ui.teamLabel")).color("gray").padRight(6f));
        for(Team t : match.teams){
            boolean mine = ap != null && ap.team == t;
            teamRow.add(button(Txt.team(t)).style(mine ? "fullTogglet" : "cleart").checked(mine)
                .clicked("team:" + t.name).width(120f).height(42f).pad(2f));
        }
        body.add(teamRow.padTop(6f)).row();
        return body;
    }

    /** Два (или N) столбика: ник + выбранный юнит. viewer нужен, чтобы скрывать пики врагов. */
    private TableBuilder teamColumns(Player viewer, boolean lobbyStyle){
        Match match = Match.inst;
        ArenaPlayer me = match.get(viewer);
        TableBuilder cols = table();
        for(Team team : match.teams){
            TableBuilder col = table();
            col.add(head(Txt.col(team) + team.name.toUpperCase()).padBottom(4f)).row();

            Seq<ArenaPlayer> list = match.of(team);
            if(list.isEmpty()){
                col.add(label("[gray]" + m("ui.emptyTeam") + "[]").growX().align("left").padBottom(2f)).row();
            }
            for(ArenaPlayer ap : list){
                String unit;
                boolean hidden = !OneUnit.settings.showEnemyPicks && me != null && me.team != team && match.phase == Match.Phase.draft;
                if(hidden) unit = "[gray]" + m("ui.enemyHidden") + "[]";
                else if(ap.pick == null) unit = "[gray]" + m("ui.noUnit") + "[]";
                else unit = "[accent]" + ap.pick.display() + "[] [gray]T" + ap.pick.tier + "[]";

                String status;
                if(match.phase == Match.Phase.lobby){
                    status = ap.ready ? "[green]" + m("ui.ready") + "[]" : "[gray]" + m("ui.notReady") + "[]";
                }else{
                    status = ap.alive() ? "[green]" + m("ui.alive") + "[]"
                        : (ap.out || ap.lives <= 0 ? "[scarlet]" + m("ui.dead") + "[]" : "[gold]" + m("ui.waiting") + "[]");
                }

                String text = "[white]" + ap.name() + "[]  " + unit + (lobbyStyle ? "  " + status : "");
                col.add(label(text).wrap().growX().align("left").padBottom(3f)).row();
            }
            cols.add(col.growX().align("top").pad(6f));
        }
        return cols;
    }

    // ------------------------------------------------------------------ драфт / респавн

    public void draft(Player p){
        ArenaPlayer ap = Match.inst.get(p);
        if(ap == null) return;
        show(p, DRAFT, m("ui.draftTitle"), pickBody(ap, false), true);
    }

    public void respawn(Player p){
        ArenaPlayer ap = Match.inst.get(p);
        if(ap == null) return;
        show(p, RESPAWN, m("ui.respawnTitle"), pickBody(ap, true), true);
    }

    public void refreshDraftAll(){
        Groups.player.each(p -> {
            ArenaPlayer ap = Match.inst.get(p);
            if(ap == null) return;
            Integer cur = open.get(p.uuid());
            if(cur == null) return;
            if(cur == DRAFT) update(p, DRAFT, pickBody(ap, false));
            else if(cur == RESPAWN) update(p, RESPAWN, pickBody(ap, true));
        });
    }

    private TableBuilder pickBody(ArenaPlayer ap, boolean isRespawn){
        Match match = Match.inst;
        TableBuilder body = table();

        String info = isRespawn
            ? m("ui.draftInfo", Txt.n(ap.points), ap.lives, Txt.n(Math.max(0f, ap.respawnMenuTimer)))
            : m("ui.draftInfo", Txt.n(ap.points), ap.lives, Txt.n(Math.max(0f, match.timer)));
        body.add(head(info)).row();
        body.add(label(m("ui.selected", ap.pick == null
            ? "[gray]" + m("ui.noUnit") + "[]"
            : "[accent]" + ap.pick.display() + "[] T" + ap.pick.tier)).growX().align("left").padBottom(2f)).row();
        body.add(hint(m(isRespawn ? "ui.respawnHint" : "ui.draftHint"))).row();

        // вкладки тиров
        Catalog cat = OneUnit.catalog;
        int maxTier = isRespawn ? ap.maxTierAllowed() : OneUnit.settings.draft.maxTier;
        if(!cat.tier(ap.viewTier).contains(UnitEntry::valid)){
            Seq<Integer> active = cat.activeTiers();
            if(!active.isEmpty()) ap.viewTier = active.first();
        }
        TableBuilder tabs = table();
        for(int tier : cat.activeTiers().toArray()){
            int count = cat.tier(tier).count(UnitEntry::valid);
            boolean selected = ap.viewTier == tier;
            tabs.add(button(m("ui.tierTab", tier, count))
                .style(selected ? "fullTogglet" : "cleart").checked(selected)
                .disabled(tier > maxTier)
                .clicked("tier:" + tier).width(92f).height(42f).pad(2f));
        }
        body.add(tabs.growX().padBottom(4f)).row();

        TableBuilder grid = table();
        grid.add(unitGrid(ap, isRespawn, 3).condition("landscape").growX()).row();
        grid.add(unitGrid(ap, isRespawn, 2).condition("portrait").growX()).row();
        body.add(pane().add(grid.growX()).style("defaultPane").height(330f).growX()).row();

        // кто на ком играет - видно прямо в меню выбора
        if(!isRespawn){
            body.add(label("[accent]" + m("ui.picksTitle") + "[]").growX().align("left").padTop(6f)).row();
            body.add(teamColumns(ap.player, false).growX()).row();
        }

        TableBuilder buttons = table();
        buttons.add(btn(m("ui.rosterTitle"), "roster").width(180f));
        buttons.add(btn(m("ui.refresh"), "refresh").width(140f));
        buttons.add(btn(m("ui.close"), "close").width(140f));
        body.add(buttons.padTop(8f)).row();
        return body;
    }

    private TableBuilder unitGrid(ArenaPlayer ap, boolean isRespawn, int columns){
        Catalog cat = OneUnit.catalog;
        int maxTier = isRespawn ? ap.maxTierAllowed() : OneUnit.settings.draft.maxTier;
        TableBuilder grid = table();

        grid.add(head(cat.label(ap.viewTier)).padTop(4f).padBottom(4f).colspan(columns)).row();

        Seq<UnitEntry> list = cat.tier(ap.viewTier).select(UnitEntry::valid);
        if(list.isEmpty()){
            grid.add(label("[gray]" + m("ui.noUnits") + "[]").growX().colspan(columns)).row();
            return grid;
        }

        int col = 0;
        for(UnitEntry e : list){
            boolean affordable = !isRespawn || e.cost <= ap.points;
            boolean tierOk = e.tier <= maxTier;
            boolean selected = ap.pick == e;

            String price = e.cost <= 0 ? "[green]" + m("ui.free") + "[]" : "[gold]" + e.cost + "[]";
            String text = e.display() + "\n" + price + "  " + e.stats();
            if(!tierOk) text = e.display() + "\n[scarlet]" + m("ui.tierClosed") + "[]";
            else if(!affordable) text = e.display() + "\n[scarlet]" + m("ui.locked") + ": " + e.cost + "[]";

            grid.add(button(text).icon(e.unit)
                .style(selected ? "fullTogglet" : "cleart")
                .checked(selected)
                .disabled(!affordable || !tierOk)
                .clicked("pick:" + e.id())
                .width(columns == 3 ? 235f : 205f).height(62f).pad(2f));
            col++;
            if(col >= columns){
                grid.row();
                col = 0;
            }
        }
        return grid;
    }

    // ------------------------------------------------------------------ состав / счёт / итоги

    public void roster(Player p){
        show(p, ROSTER, m("ui.rosterTitle"), rosterBody(p), true);
    }

    private TableBuilder rosterBody(Player p){
        Match match = Match.inst;
        TableBuilder body = table();
        body.add(head(m("ui.lobbyInfo",
            Txt.f(match.respawnMode ? "modeRespawn" : "modeClassic"),
            match.roster.size,
            match.mapName.isEmpty() ? "-" : match.mapName))).row();
        body.add(teamColumns(p, match.phase == Match.Phase.lobby).growX()).row();

        TableBuilder buttons = table();
        buttons.add(btn(m("ui.scoreTitle"), "score").width(190f));
        buttons.add(btn(m("ui.refresh"), "refresh").width(140f));
        if(match.phase == Match.Phase.draft || (match.phase == Match.Phase.live && Match.inst.get(p) != null && !Match.inst.get(p).alive())){
            buttons.add(btn(m("ui.pick"), "pickmenu").width(150f));
        }
        buttons.add(btn(m("ui.close"), "close").width(140f));
        body.add(buttons.padTop(8f)).row();
        return body;
    }

    public void refreshRosterAll(){
        Groups.player.each(p -> {
            Integer cur = open.get(p.uuid());
            if(cur != null && cur == ROSTER) update(p, ROSTER, rosterBody(p));
        });
    }

    public void score(Player p){
        show(p, SCORE, m("ui.scoreTitle"), scoreDialog(), true);
    }

    private TableBuilder scoreDialog(){
        TableBuilder body = table();
        body.add(pane().add(scoreBody().growX()).style("defaultPane").growX().height(420f)).row();
        TableBuilder buttons = table();
        buttons.add(btn(m("ui.rosterTitle"), "roster").width(190f));
        buttons.add(btn(m("ui.refresh"), "refresh").width(140f));
        buttons.add(btn(m("ui.close"), "close").width(140f));
        body.add(buttons.padTop(8f)).row();
        return body;
    }

    public void results(Player p){
        TableBuilder body = table();
        body.add(head(m("ui.winner", Match.inst.winner == null ? "[gold]ничья[]" : Txt.team(Match.inst.winner)))).row();
        body.add(pane().add(scoreBody().growX()).style("defaultPane").growX().height(400f)).row();
        TableBuilder buttons = table();
        buttons.add(btn(m("ui.close"), "close").width(150f));
        body.add(buttons.padTop(8f)).row();
        show(p, RESULTS, m("ui.resultsTitle"), body, true);
    }

    private TableBuilder scoreBody(){
        TableBuilder body = table();
        for(Team team : Match.inst.teams){
            Seq<ArenaPlayer> list = Match.inst.of(team);
            if(list.isEmpty()) continue;
            list.sort(a -> -a.score());

            body.add(head(Txt.col(team) + team.name.toUpperCase()).padTop(8f)).row();

            TableBuilder head = table();
            head.add(label("[gray]" + m("ui.colPlayer") + "[]").width(160f).align("left"));
            head.add(label("[gray]" + m("ui.colUnit") + "[]").width(170f).align("left"));
            head.add(label("[gray]" + m("ui.colKills") + "[]").width(70f));
            head.add(label("[gray]" + m("ui.colAssists") + "[]").width(70f));
            head.add(label("[gray]" + m("ui.colDeaths") + "[]").width(70f));
            head.add(label("[gray]" + m("ui.colLives") + "[]").width(60f));
            head.add(label("[gray]" + m("ui.colScore") + "[]").width(80f));
            body.add(head.growX()).row();

            for(ArenaPlayer ap : list){
                TableBuilder row = table();
                row.add(label("[white]" + ap.name() + "[]").width(160f).align("left"));
                row.add(label(ap.unitName()).width(170f).align("left"));
                row.add(label("[green]" + ap.kills + "[]").width(70f));
                row.add(label("[accent]" + ap.assists + "[]").width(70f));
                row.add(label("[scarlet]" + ap.deaths + "[]").width(70f));
                row.add(label("[gold]" + ap.lives + "[]").width(60f));
                row.add(label("[accent]" + Txt.n(ap.points) + "[]").width(80f));
                body.add(row.growX()).row();
            }
        }
        return body;
    }

    // ------------------------------------------------------------------ помощь

    public void help(Player p){
        TableBuilder body = table();
        String text = """
            [accent]One Unit Arena[] - один юнит, одна жизнь.

            [green]/lobby[] - меню лобби: команды, готовность, старт
            [green]/join [команда][] - войти в лобби
            [green]/leave[] - выйти из лобби
            [green]/pick[] - меню выбора юнита (драфт и респавн)
            [green]/ready[] - готовность
            [green]/roster[] - состав команд (кто на ком играет)
            [green]/score[] - таблица очков
            [green]/mode classic|respawn[] - режим (админ)
            [green]/start[] - запустить матч (админ)
            [green]/stop[] - остановить матч (админ)
            [green]/arena help[] - админ-команды (точки спавна, очки, конфиги)

            [accent]Режимы[]
            [gold]Классика[]: одна жизнь. Умер - наблюдаешь. Команда проигрывает, когда выбыли все.
            [gold]War Thunder[]: 3 жизни и очки. За убийства, ассисты, урон и точки дают очки; после смерти покупаешь нового юнита - чем сильнее тир, тем дороже.

            [accent]Управление[]
            Строительство, добыча и вселение в другие юниты отключены. Камера следует за твоим юнитом.
            """;
        body.add(label(text).wrap().growX().pad(6f).align("left")).row();
        TableBuilder buttons = table();
        buttons.add(btn(m("ui.back"), "lobby").width(150f));
        buttons.add(btn(m("ui.close"), "close").width(150f));
        body.add(buttons.padTop(8f)).row();
        show(p, HELP, m("ui.helpTitle"), body, true);
    }

    // ------------------------------------------------------------------ HUD

    public void hudAll(){
        if(!OneUnit.settings.hud.enabled) return;
        Groups.player.each(this::hud);
    }

    public void hud(Player p){
        if(!OneUnit.settings.hud.enabled || p == null || p.con == null) return;
        Match match = Match.inst;
        ArenaPlayer ap = match.get(p);
        String text;

        if(ap == null){
            text = "[accent]One Unit Arena[] | /lobby - войти в лобби";
        }else{
            switch(match.phase){
                case draft -> text = "[accent]ДРАФТ[] " + Txt.time(match.timer) + " | " + m("ui.points") + ": [gold]" + Txt.n(ap.points) + "[] | " +
                    (ap.pick == null ? "[scarlet]/pick[]" : "[green]" + ap.pick.display() + "[]");
                case countdown -> text = "[accent]СТАРТ ЧЕРЕЗ " + Txt.n(match.timer) + "[] | " + ap.unitName();
                case live -> {
                    if(ap.alive()){
                        text = "[accent]" + (ap.pick == null ? "?" : ap.pick.display() + " T" + ap.pick.tier) + "[]" +
                            " | HP [green]" + Txt.n(ap.unit.health) + "[]" +
                            " | " + m("ui.points") + ": [gold]" + Txt.n(ap.points) + "[]" +
                            " | " + m("ui.lives") + ": [gold]" + ap.lives + "[]" +
                            (ap.captureZone.isEmpty() ? "" : " | [accent]" + ap.captureZone + "[]") +
                            " | " + Txt.time(match.timeLeft());
                    }else if(ap.out || ap.lives <= 0){
                        text = "[scarlet]" + m("ui.dead") + "[] | " + m("ui.points") + ": [gold]" + Txt.n(ap.points) + "[] | /roster /score | " + Txt.time(match.timeLeft());
                    }else{
                        text = "[scarlet]Юнит уничтожен[] | " + (ap.respawnTimer > 0 ? "респавн через " + Txt.n(ap.respawnTimer) + "с" : "[accent]/pick[]") +
                            " | " + m("ui.points") + ": [gold]" + Txt.n(ap.points) + "[] | " + m("ui.lives") + ": [gold]" + ap.lives + "[]";
                    }
                }
                case ending -> text = m("ui.winner", match.winner == null ? "[gold]ничья[]" : Txt.team(match.winner)) + " | /score";
                default -> {
                    if(!OneUnit.settings.hud.lobbyHud){
                        Call.hideHudText(p.con);
                        return;
                    }
                    text = "[accent]ЛОББИ[] " + match.roster.size + " игр. | " + Txt.f(match.respawnMode ? "modeRespawn" : "modeClassic") +
                        " | " + (ap.ready ? "[green]готов[]" : "[gray]не готов[]") + " | /lobby";
                }
            }
        }
        Call.setHudText(p.con, text);
    }

    // ------------------------------------------------------------------ обработка кликов

    public void handle(Player p, int menuId, MenuResult res){
        Match match = Match.inst;
        String result = res == null ? null : res.result;
        ArenaPlayer ap = match.get(p);
        Integer cur = open.get(p.uuid());

        if(result == null || result.isEmpty()){
            // диалог закрыли крестиком (или мы сами его закрыли)
            if(cur != null && cur == menuId){
                open.remove(p.uuid());
                if(ap != null && menuId == RESPAWN && ap.menuOpen){
                    ap.menuOpen = false;
                    ap.respawnMenuTimer = -1f;
                    if(match.phase == Match.Phase.live && !ap.alive() && ap.lives > 0 && !ap.out){
                        ap.respawnTimer = OneUnit.settings.respawn.menuReopenDelay;
                        Txt.send(p, "respawnReopen", Txt.n(ap.respawnTimer));
                    }
                }
            }
            return;
        }

        if(result.equals("close")){
            close(p, menuId);
            if(ap != null && menuId == RESPAWN){
                ap.menuOpen = false;
                ap.respawnMenuTimer = -1f;
                if(match.phase == Match.Phase.live && !ap.alive() && ap.lives > 0 && !ap.out){
                    ap.respawnTimer = OneUnit.settings.respawn.menuReopenDelay;
                }
            }
            return;
        }

        switch(result){
            case "join" -> {
                match.join(p, null);
                update(p, LOBBY, lobbyBody(p));
            }
            case "leave" -> {
                match.leave(p);
                close(p, LOBBY);
            }
            case "ready" -> {
                match.toggleReady(p);
                update(p, LOBBY, lobbyBody(p));
            }
            case "start" -> {
                if(!p.admin){
                    Txt.send(p, "notAdmin");
                    return;
                }
                close(p, LOBBY);
                match.startDraft(p);
            }
            case "stop" -> {
                if(!p.admin){
                    Txt.send(p, "notAdmin");
                    return;
                }
                close(p, LOBBY);
                match.stop(p);
            }
            case "mode" -> {
                if(!p.admin){
                    Txt.send(p, "notAdmin");
                    return;
                }
                match.setMode(!match.respawnMode);
                update(p, LOBBY, lobbyBody(p));
            }
            case "roster" -> roster(p);
            case "score" -> score(p);
            case "help" -> help(p);
            case "lobby" -> lobby(p);
            case "pickmenu" -> openPick(p);
            case "refresh" -> {
                switch(menuId){
                    case LOBBY -> update(p, LOBBY, lobbyBody(p));
                    case DRAFT -> {
                        if(ap != null) update(p, DRAFT, pickBody(ap, false));
                    }
                    case RESPAWN -> {
                        if(ap != null) update(p, RESPAWN, pickBody(ap, true));
                    }
                    case ROSTER -> update(p, ROSTER, rosterBody(p));
                    case SCORE -> update(p, SCORE, scoreDialog());
                    default -> { }
                }
            }
            default -> {
                if(result.startsWith("team:")){
                    match.setTeam(p, result.substring(5));
                    update(p, LOBBY, lobbyBody(p));
                }else if(result.startsWith("tier:")){
                    if(ap == null) return;
                    try{
                        ap.viewTier = Integer.parseInt(result.substring(5));
                    }catch(NumberFormatException ignored){
                        return;
                    }
                    if(menuId == RESPAWN) update(p, RESPAWN, pickBody(ap, true));
                    else update(p, DRAFT, pickBody(ap, false));
                }else if(result.startsWith("pick:")){
                    String id = result.substring(5);
                    boolean wasRespawn = menuId == RESPAWN;
                    match.pick(p, id);
                    ArenaPlayer after = match.get(p);
                    if(after == null) return;
                    if(!wasRespawn && match.phase == Match.Phase.draft){
                        update(p, DRAFT, pickBody(after, false));
                    }
                }
            }
        }
    }

    /** Открывает нужное меню выбора: драфт или респавн. */
    public void openPick(Player p){
        Match match = Match.inst;
        ArenaPlayer ap = match.get(p);
        if(ap == null){
            Txt.send(p, "notJoined");
            return;
        }
        if(match.phase == Match.Phase.draft){
            draft(p);
        }else if(match.phase == Match.Phase.live && !ap.alive() && !ap.out && ap.lives > 0 && match.respawnMode){
            match.openRespawn(ap);
        }else if(match.phase == Match.Phase.live && ap.alive() && OneUnit.settings.allowLiveSwitch){
            respawn(p);
        }else{
            Txt.send(p, "pickLocked");
        }
    }
}
