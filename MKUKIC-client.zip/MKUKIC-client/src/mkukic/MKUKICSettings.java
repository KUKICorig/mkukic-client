package mkukic;

import arc.files.*;
import arc.struct.*;
import arc.util.*;
import arc.util.serialization.*;

/**
 * Все настройки мода. Хранятся в configs/mkukic-client/settings.json.
 * Доступ — всегда через {@link #s()}, чтобы замена объекта не ломала ссылки.
 */
public class MKUKICSettings{
    // ================= БОЕВЫЕ =================
    public boolean aimbot = false;
    public float aimRange = 420f;           // 0 = автоматически по дальности оружия
    public int aimPriority = 0;             // 0 ближний | 1 опасный | 2 воздух | 3 наземка | 4 только на экране
    public boolean aimShoot = true;         // стрелять автоматически
    public boolean aimPredict = true;       // упреждение по скорости цели
    public boolean aimBuildings = true;     // целиться в здания
    public boolean aimOnlyOnFire = false;   // работать только при зажатой кнопке огня
    public boolean aimSilent = false;       // не доворачивать корпус юнита (только стволы)

    public boolean speed = false;
    public float speedMult = 1.8f;          // множитель скорости юнита
    public boolean rage = false;
    public float damageMult = 2f;
    public float reloadMult = 2f;           // >1 = быстрее перезарядка
    public boolean instantReload = false;   // мгновенная перезарядка всех орудий
    public boolean fortress = false;
    public float healthMult = 3f;
    public float armorAdd = 30f;
    public boolean godmode = false;
    public boolean fly = false;             // полёт для любого юнита
    public boolean infiniteRange = false;   // дальность стрельбы x2
    public float buildRangeAdd = 0f;        // +к радиусу стройки (0 = выкл)
    public float mineSpeedMult = 1f;        // множитель скорости копки (1 = выкл)
    public boolean autoHeal = false;        // медленно регенерировать HP

    // ================= ИИ ЮНИТОВ =================
    public boolean aiEnabled = true;
    public boolean aiAutoMine = false;      // сами копают нужную руду и сдают в ядро
    public boolean aiAutoBuild = false;     // достраивать чужие планы и разрушенные блоки
    public boolean aiAutoRepair = false;    // чинить повреждённые блоки
    public boolean aiFollow = false;        // следовать за игроком
    public float followDistance = 90f;
    public boolean aiEscort = false;        // прикрывать игрока, атакуя врагов рядом
    public float escortRange = 340f;
    public boolean aiRetreat = true;        // отступать к ядру при низком HP
    public float retreatHealth = 0.3f;
    public boolean aiAutoTarget = true;     // сами выбирают цель
    public boolean aiOnlyCommandable = true;// трогать только юниты под vanilla-командованием
    public float aiRadius = 1400f;          // радиус групповых фич
    public boolean aiAutoRebuild = false;   // восстанавливать разрушенные блоки (сканирует тайлы)

    // ============ ИИ: цели, группы, безопасность ============
    public boolean aiSafeZone = false;      // уход от врагов: при врагах рядом юниты идут к ядру
    public float fleeRadius = 450f;         // радиус обнаружения врагов для отхода

    // ============ ИИ: ремонт транспорта и отряды ============
    public boolean aiRepairTransports = false; // строители чинят конвейеры/мосты/турели/заводы
    public boolean aiSquads = false;           // отряды сторожат пути от точек высадки
    public int squadCount = 3;                 // число отрядов (0 = по числу точек высадки)

    // ============ МОНЕТЫ (порт CoinMagnet) ============
    public boolean coinMagnet = false;       // магнит: телепорт своего юнита к монете и удержание
    public boolean coinLines = true;         // линии-подсветка до монет и ценники
    public float coinRadius = 10f;           // радиус магнита в тайлах
    public boolean coinServerLimit = true;   // в сети ограничивать радиус 10 тайлами
    public boolean coinPreferHighValue = true; // сначала дорогие монеты (>= 5000)
    public boolean coinPilot = false;        // v1.14: автопилот до монет (летит/идёт сам, не телепорт)
    public float coinPilotRadius = 600f;     // радиус поиска монет автопилотом, тайлы (v1.18: x5, было 120)
    public boolean coinPilotDodge = true;    // уклонение от снарядов во время автопилота
    public float coinPilotDodgeR = 170f;     // радиус реагирования на снаряды, мир. единицы

    // ============ ШТАБ: слои карты ============
    public boolean hqOre = true;               // жилы руды
    public boolean hqRanges = true;            // радиусы турелей
    public boolean hqSectors = true;           // сектора обороны вокруг ядра
    public boolean hqSweep = true;             // радар-развёртка
    public boolean hqWaveAlert = true;         // алерт за 10с до волны

    // ============ ИИ ИГРОКА (автопилот) ============
    public boolean paEnabled = false;       // юнитом игрока управляет ИИ
    public boolean paMine = true;           // копать как poly
    public boolean paBuild = true;          // строить/чинить как mega
    public boolean paRepair = true;
    public Seq<String> paHelpPlayers = new Seq<>(); // список игроков, которым помогает ваш юнит
    public boolean paDodge = false;         // маневрировать от снарядов
    public float paDodgeRadius = 170f;

    // ================= ВИЗУАЛ / УТИЛИТЫ =================
    public boolean esp = false;
    public boolean espNames = true;
    public boolean espHealth = true;
    public boolean espDistance = true;
    public boolean espLines = false;
    public boolean espRangeCircles = false;
    public boolean espRadar = true;         // стрелки по краю экрана
    public boolean espFog = true;           // уважать туман войны
    public boolean espBuildings = false;    // подсвечивать вражеские постройки
    public boolean espPlayers = false;      // подсвечивать игроков
    public int espPlayerTeam = -1;          // -1 = все команды, иначе id команды
    public String espWhitelist = "";        // ники через запятую: показывать только их
    public boolean espTrails = false;       // маршруты движения вражеских юнитов
    public int espTrailLen = 50;            // длина следа (точек)
    public float espRadarRadius = 2600f;
    public boolean infoHud = true;          // строка статуса в углу
    public boolean showTargetLine = true;   // линия до текущей цели автоприцела
    public boolean menuButton = true;       // плавающая кнопка меню
    public boolean toolbarVisible = true;   // панель вкладок на экране
    public boolean toolbarCollapsed = false;  // свёрнута в кнопку «N»
    public float toolbarX = -1, toolbarY = -1;
    public boolean cmdBarVisible = false;   // плавающее окно своих команд
    public boolean cmdBarVertical = true;
    public float cmdBarX = -1, cmdBarY = -1;
    public float cmdBarOpacity = 0.9f;
    public Seq<String> cmdEntries = Seq.with("Статы|/stats", "Магазин|/shop", "История|/history");
    public boolean toasts = true;           // всплывающие уведомления

    // ================= АДМИН =================
    public boolean adminPanel = true;
    public boolean anticheatAlerts = true;  // алерты серверного античита

    // ============ QoL: окна, оверлеи, инструменты (порт каталога модов) ============
    public boolean qolEnabled = true;          // мастер-выключатель QoL-слоя
    // Helium-оверлеи
    public boolean qolHpBars = false;          // HP/щит-бары над юнитами
    public boolean qolHpBarsAll = false;       // над всеми юнитами (не только врагами)
    public boolean qolShieldStacks = true;     // счётчик «стеков» многослойных щитов
    public boolean qolRanges = true;           // дальности атак (курсор/выделение/свой юнит)
    public boolean qolServiceZones = false;    // зоны ремонтников/овердрайвов/щитов
    // ViewControl
    public float zoomMult = 1f;                // >1 = расширенный зум (1 = ваниль)
    public float timeScale = 1f;               // скорость симуляции (хост/одиночная)
    public boolean perfMaster = false;         // режим производительности
    public boolean perfWeather = false;
    public boolean perfEffects = false;
    public boolean perfLight = false;
    public boolean perfShields = false;
    public boolean perfWater = false;
    public boolean perfPings = false;
    public boolean perfOtherPlans = false;
    public boolean perfDisplays = false;
    // Tripwire (геозона)
    public boolean tripwire = false;
    public boolean tripwireAtCore = true;      // false = вокруг игрока
    public boolean tripwireSound = true;
    public float tripwireRadius = 900f;
    // Smart Upgrade
    public int smartUpgradeMax = 300;
    // Scheme-Size: лимит размера схем (64 = ваниль, до 512)
    public int schematicSize = 64;
    // CoreStats: линии графика (имена предметов, до 4)
    public Seq<String> qolTrackedItems = Seq.with("copper", "lead", "silicon");
    // позиции плавающих окон: id -> "x|y|collapsed"
    public arc.struct.ObjectMap<String, String> winPos = new arc.struct.ObjectMap<>();

    // ============ QoL v1.10: формации, маршруты, колесо, бэкапы, музыка, буры ============
    // RTS-формации (Neon): line/column/wedge/square/circle
    public String formType = "line";
    public float formSpacing = 24f;              // мир. единицы между юнитами (3 тайла)
    // Визуализатор маршрутов врага (MindustryTool Pathfinding Visualizer)
    public boolean qolPathOverlay = false;
    public boolean qolPathChokes = true;         // подсвечивать узкие места
    // Буровой планер (MindustryTool Smart Drill)
    public boolean qolDrillOverlay = false;
    public String drillName = "mechanical-drill";
    // Радиальное строительное меню (Neon Radial Build)
    public Seq<String> wheelFav = new Seq<>();   // избранные блоки (имена)
    public Seq<String> wheelRecent = new Seq<>();// недавно использованные
    // Музыкальный плеер (MindustryTool Music Player)
    public float musicVolume = 0.8f;
    public boolean musicLoop = false;
    // Сглаживание лаг-скачков (MI2 Time Scaler)
    public boolean qolSmoothDelta = false;

    // ---------------- v1.11: инспектор и маркеры ----------------
    public boolean inspFollow = true;            // инспектор: следить за курсором (иначе закреплённая точка)
    public boolean inspWorld = false;            // инспектор: компактная сводка в мире у курсора
    public boolean markerOverlay = true;         // маркеры: рисовать в мире
    public boolean markerText = true;            // маркеры: подписи текстом
    public float markerRadius = 8f;              // радиус круга по умолчанию (тайлы)
    public int markerColor = 0;                  // индекс цвета в палитре маркеров

    // ---------------- v1.13: умный снос ----------------
    public int pruneMax = 300;                   // лимит блоков в цепочке сноса

    // ---------------- v1.16: порт фич из других модов ----------------
    // Атака-алерт (m3rcur1e/attack-alert + MinerTools EnemyIndicator + Caster-UI core-lost)
    public boolean attackAlert = true;           // следить за уроном своим зданиям
    public boolean attackAlertWalls = false;     // тревожить на стенах/дверях
    public boolean attackAlertOffscreen = true;  // учитывать события вне поля зрения
    public boolean attackAlertSound = true;
    public boolean attackAlertToast = true;
    public boolean attackAlertArrow = true;      // стрелки у края экрана
    public boolean attackAlertText = true;       // подписи у меток в мире
    public float attackAlertLife = 12f;          // сколько секунд живёт метка
    public int attackAlertMaxArrows = 6;         // максимум стрелок одновременно

    // Просвет зданий (MI2 Building X-ray + MinerTools BlockStatus)
    public boolean xray = false;                 // подписи содержимого зданий
    public boolean xrayDucts = false;            // цвет жидкости в трубах (Color-the-ducts)
    public float xrayDuctScale = 0.55f;          // размер квадрата в трубе (доля тайла)
    public boolean xrayAllTeams = false;         // показывать и чужие команды
    public boolean xrayPower = true;             // подписывать нехватку питания
    public boolean xrayZoomedOut = false;        // подписи при дальнем зуме

    // Поток ресурсов ядра (marcusbandit/resource-flow + MindustryTool Team Resource HUD)
    public boolean coreFlow = false;             // плашка «сколько + приход/сек»
    public boolean coreFlowRates = true;         // показывать скорость
    public boolean coreFlowOnlyMoving = false;   // только предметы с движением
    public int coreFlowColumns = 4;              // предметов в строке
    public float coreFlowX = 8f;                 // позиция плашки (слева)
    public float coreFlowY = 132f;               // позиция плашки (сверху)

    // График производства (vadymchan/mindustry-production-graph, Factorio-стиль)
    public boolean prodGraph = true;             // собирать статистику потока
    public int prodGraphWindow = 1;              // 0=60с, 1=5м, 2=10м
    public Seq<String> prodGraphItems = Seq.with("copper", "lead", "silicon");

    // Тревоги производства (MinerTools TurretAlert + Power-Grid-Minimap)
    public boolean alerts = false;               // сканировать проблемы производства
    public boolean alertsWorld = true;           // метки в мире
    public boolean alertsWholeMap = false;       // сканировать всю карту, а не только кадр
    public boolean alertsPower = true;           // класс «нет питания»
    public float alertsFullRatio = 0.95f;        // порог «склад забит»

    // Операторская камера (Caster-UI + MinerTools PlayerList + MI2 Multi-Team)
    public boolean spectateFollow = true;        // камера следует за выбранной целью
    public boolean coreLostAlert = true;         // уведомление о потере ядра
    public boolean coreLostFlash = true;         // вспышка экрана
    public boolean coreLostSound = true;
    public boolean coreLostSnap = false;         // прыжок камерой к потерянному ядру

    // История чата (MinerTools ChatTable + Extra Logging)
    public boolean chatLog = true;               // вести журнал чата

    // Панорамирование краем экрана (MI2-Utilities Edge Panning)
    public boolean edgePan = false;
    public float edgePanMargin = 14f;            // px от края
    public float edgePanSpeed = 1f;              // множитель скорости

    // ================= ПРОЧЕЕ =================
    public boolean enabled = true;          // глобальный выключатель клиент-фич

    // ---------------- сохранение ----------------
    private static final Json json = new Json();
    private static Fi file;
    private static Fi folder;
    private static final MKUKICSettings instance = new MKUKICSettings();

    public static MKUKICSettings s(){
        return instance;
    }

    /** Папка конфигов мода (для бэкапов и т.п.). Может быть null до init. */
    public static Fi dir(){
        return folder;
    }

    public static void init(Fi configFolder){
        json.setIgnoreUnknownFields(true);
        json.setOutputType(JsonWriter.OutputType.json);
        folder = configFolder;
        file = configFolder.child("settings.json");
    }

    public static void load(){
        if(file == null || !file.exists()) return;
        try{
            MKUKICSettings o = json.fromJson(MKUKICSettings.class, file.readString());
            if(o != null) json.copyFields(o, instance);
        }catch(Throwable t){
            Log.err("[MKUKIC] settings.json повреждён, использую значения по умолчанию", t);
        }
    }

    public static void save(){
        if(file == null) return;
        try{
            file.writeString(json.prettyPrint(json.toJson(instance, MKUKICSettings.class)), false);
        }catch(Throwable t){
            Log.err("[MKUKIC] не удалось сохранить settings.json", t);
        }
    }

    public static void reset(){
        try{
            json.copyFields(new MKUKICSettings(), instance);
            save();
        }catch(Throwable ignored){}
    }
}
