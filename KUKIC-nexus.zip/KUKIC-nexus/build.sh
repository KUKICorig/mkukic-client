#!/usr/bin/env bash
# Сборка MKUKIC Client одной командой.
#   ./build.sh            — проверки + тесты + dist/MKUKICClient.jar
#   ./build.sh fast       — то же без тестов
#   ./build.sh install    — собрать и положить в папку модов игры
#   ./build.sh test       — только тесты
#   ./build.sh info       — что найдено: JDK, Android SDK, папка модов
#   ./build.sh clean      — очистить build/ и dist/
# Любые дополнительные аргументы уходят в Gradle (например -PmindustryVersion=latest).
set -e
cd "$(dirname "$0")"

if ! command -v java >/dev/null 2>&1; then
  echo "Не найдена Java. Нужен JDK 17 или новее (https://adoptium.net)." >&2
  exit 1
fi
JV=$(java -version 2>&1 | head -n1 | sed -E 's/.*"([0-9]+)[."].*/\1/')
if [ -n "$JV" ] && [ "$JV" -lt 17 ] 2>/dev/null; then
  echo "Java $JV слишком старая, нужен JDK 17 или новее." >&2
  exit 1
fi

# В zip-архиве у gradlew часто теряется право на запуск — запускаем через sh.
GW="sh ./gradlew"

cmd="${1:-dist}"
case "$cmd" in
  dist|build)  shift || true; exec $GW dist "$@" ;;
  fast)        shift; exec $GW dist -PskipTests "$@" ;;
  install)     shift; exec $GW installMod "$@" ;;
  test|tests)  shift; exec $GW runTests "$@" ;;
  info)        shift; exec $GW buildInfo -q "$@" ;;
  clean)       shift; exec $GW clean "$@" ;;
  -*)          exec $GW dist "$@" ;;
  *)           exec $GW "$@" ;;
esac
