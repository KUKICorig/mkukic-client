package rl.core;

/** Версия плагина (подставляется сборкой в один файл, чтобы не дублировать в plugin.json). */
public final class Version {
    public static final String VALUE = "1.0.0";

    private Version() {}
}
