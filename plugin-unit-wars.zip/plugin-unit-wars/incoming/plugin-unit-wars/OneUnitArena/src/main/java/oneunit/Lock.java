package oneunit;

import mindustry.*;
import mindustry.game.*;
import mindustry.gen.*;

/**
 * Перехват управления: правила карты + покадровая проверка юнита.
 * Игрок не строит, не добывает, не вселяется в другие юниты/блоки и не спавнится от ядра.
 */
public class Lock{
    /** Применяет правила режима к правилам карты (вызывается до logic.play()). */
    public static void apply(Rules r){
        Settings.Tweaks t = OneUnit.settings.tweaks;

        // победа считается плагином, а не ванилой
        r.canGameOver = false;
        r.cleanupDeadTeams = false;
        r.coreCapture = false;

        // pvp нужен для команд, но авто-пауза ломает арены без ядер
        r.pvp = true;
        r.pvpAutoPause = false;
        r.pauseDisabled = true;

        // никаких волн
        r.waves = false;
        r.waveSending = false;
        r.attackMode = false;
        r.spawns.clear();

        // запрет строительства/добычи/вселения
        r.possessionAllowed = !t.blockPossession;
        r.schematicsAllowed = !t.disableSchematics;
        r.buildSpeedMultiplier = t.removeBuilding ? 0f : 1f;
        r.unitBuildSpeedMultiplier = t.removeBuilding ? 0f : 1f;
        r.unitMineSpeedMultiplier = t.removeMining ? 0f : 1f;
        r.instantBuild = false;
        r.infiniteResources = false;
        r.loadout.clear();

        r.bannedBlocks.clear();
        if(t.removeBuilding){
            r.bannedBlocks.addAll(Vars.content.blocks());
        }

        // логика не должна отбирать юнитов
        r.logicUnitControl = !t.disableLogicControl;
        r.logicUnitBuild = false;
        r.logicUnitDeconstruct = false;
        r.disableWorldProcessors = t.disableWorldProcessors;

        // лимиты юнитов не должны убивать наших бойцов
        r.unitCap = t.unitCap;
        r.disableUnitCap = true;

        r.hideSpawns = t.hideSpawns;
        r.fire = t.fire;
        r.reactorExplosions = t.reactorExplosions;
        r.fog = false;
        r.staticFog = false;
    }

    /** Покадровая защита: контроль, планы стройки, добыча, команда. */
    public static void tick(ArenaPlayer ap){
        Unit u = ap.unit;
        if(u == null || !u.isAdded() || ap.player == null) return;

        if(u.plans != null && u.plans.size > 0) u.plans.clear();
        if(u.buildPlan() != null) u.updateBuilding(false);
        if(u.mineTile != null) u.mineTile(null);
        if(u.team() != ap.team) u.team(ap.team);

        // игрока могло "выкинуть" из юнита (смерть, вселение, пакет) - возвращаем
        if(ap.player.unit() != u){
            u.controller(ap.player);
        }
    }
}
