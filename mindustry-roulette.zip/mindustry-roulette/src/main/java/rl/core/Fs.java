package rl.core;

import java.io.IOException;
import java.util.List;

/**
 * Минимальная абстракция файловой системы, чтобы ядро плагина (логика рулетки,
 * хранилище, админка) не зависело от arc.files.Fi и его можно было тестировать
 * обычным java-кодом.
 *
 * В бою используется {@link rl.core.LocalFs}, для Mindustry-обвязки можно подсунуть
 * реализацию поверх arc.files.Fi (см. src/mindustry).
 */
public interface Fs {

    String read(String path) throws IOException;

    void write(String path, String content) throws IOException;

    void append(String path, String content) throws IOException;

    boolean exists(String path);

    boolean delete(String path);

    /** @return имена файлов/папок внутри dir (без пути), пустой список если папки нет. */
    List<String> list(String dir);

    boolean isDirectory(String path);

    void mkdirs(String path);

    /** Полный путь: dir + "/" + name (нормализованный). */
    default String child(String dir, String name) {
        if (dir == null || dir.isEmpty()) return name;
        if (dir.endsWith("/")) return dir + name;
        return dir + "/" + name;
    }

    /** Читает файл, возвращая def если файла нет или прочитать не удалось. */
    default String readOr(String path, String def) {
        try {
            return exists(path) ? read(path) : def;
        } catch (Exception e) {
            return def;
        }
    }

    /** Пишет файл, возвращает true при успехе. */
    default boolean writeQuiet(String path, String content) {
        try {
            write(path, content);
            return true;
        } catch (Exception e) {
            return false;
        }
    }
}
