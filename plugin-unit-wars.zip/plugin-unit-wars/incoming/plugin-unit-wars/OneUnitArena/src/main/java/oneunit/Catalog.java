package oneunit;

import arc.struct.*;
import arc.util.*;
import mindustry.*;
import mindustry.content.*;
import mindustry.ctype.*;
import mindustry.type.*;

/**
 * Каталог юнитов режима. Строится из units.json; если файла нет - генерируется автоматически
 * из ванильного контента (T1-T5) плюс синтетические T6/T7 на базе боссов.
 */
public class Catalog{
    public Seq<UnitEntry> entries = new Seq<>();
    public ObjectMap<String, String> tierLabels = new ObjectMap<>();

    public transient ObjectMap<String, UnitEntry> byId = new ObjectMap<>();
    public transient IntMap<Seq<UnitEntry>> byTier = new IntMap<>();
    public transient int maxTier = 7;

    /** Ванильные тиры. Всё, чего тут нет, попадает в каталог как T1 с enabled=false (модовые юниты). */
    private static final String[][] TIERS = {
        // T1
        {"dagger", "nova", "crawler", "flare", "mono", "risso", "alpha", "stell", "merui", "elude", "retusa", "evoke"},
        // T2
        {"mace", "pulsar", "atrax", "horizon", "poly", "minke", "beta", "locus", "cleroi", "avert", "oxynoe", "incite"},
        // T3
        {"fortress", "quasar", "spiroct", "zenith", "mega", "bryde", "gamma", "precept", "anthicus", "obviate", "cyerce", "emanate"},
        // T4
        {"scepter", "vela", "arkyid", "antumbra", "quad", "sei", "vanquish", "tecta", "quell", "aegires"},
        // T5
        {"reign", "corvus", "toxopid", "eclipse", "oct", "omura", "conquer", "collaris", "disrupt", "navanax"}
    };

    /** Синтетические тиры: берём боссов T5 и усиливаем множителями. */
    private static final String[] T6 = {"reign", "eclipse", "toxopid", "omura", "navanax", "conquer", "collaris", "disrupt"};
    private static final String[] T7 = {"conquer", "navanax", "eclipse", "corvus"};

    private static final ObjectMap<String, String> CATEGORY = new ObjectMap<>();
    static{
        for(String s : new String[]{"dagger", "mace", "fortress", "scepter", "reign", "nova", "pulsar", "quasar", "vela", "corvus", "alpha", "beta", "gamma", "evoke", "incite", "emanate", "mono", "poly", "mega", "quad", "oct"}) CATEGORY.put(s, "mech");
        for(String s : new String[]{"stell", "locus", "precept", "vanquish", "conquer"}) CATEGORY.put(s, "tank");
        for(String s : new String[]{"flare", "horizon", "zenith", "antumbra", "eclipse", "elude", "avert", "obviate", "quell", "disrupt"}) CATEGORY.put(s, "air");
        for(String s : new String[]{"crawler", "atrax", "spiroct", "arkyid", "toxopid", "merui", "cleroi", "anthicus", "tecta", "collaris"}) CATEGORY.put(s, "leg");
        for(String s : new String[]{"risso", "minke", "bryde", "sei", "omura", "retusa", "oxynoe", "cyerce", "aegires", "navanax"}) CATEGORY.put(s, "naval");
    }

    /** Базовая цена тира (для автогенерации). */
    private static final int[] TIER_COST = {0, 0, 90, 200, 420, 750, 1200, 1900};

    public static Catalog generate(){
        Catalog c = new Catalog();
        for(int t = 1; t <= 7; t++){
            c.tierLabels.put(String.valueOf(t), defaultTierLabel(t));
        }

        for(int t = 1; t <= 5; t++){
            for(String name : TIERS[t - 1]){
                UnitType type = unit(name);
                if(type == null) continue;
                c.entries.add(entry(t, type, TIER_COST[t], 1f, 1f, true));
            }
        }
        // T6/T7 - усиленные боссы
        for(String name : T6){
            UnitType type = unit(name);
            if(type == null) continue;
            UnitEntry e = entry(6, type, TIER_COST[6], 1.6f, 1.35f, true);
            e.name = type.localizedName + " VI";
            c.entries.add(e);
        }
        for(String name : T7){
            UnitType type = unit(name);
            if(type == null) continue;
            UnitEntry e = entry(7, type, TIER_COST[7], 2.5f, 1.8f, true);
            e.name = type.localizedName + " VII";
            e.effects.add("overclock");
            c.entries.add(e);
        }

        // модовые/прочие юниты - добавляем выключенными, чтобы админ сам решил
        Seq<String> known = new Seq<>();
        for(UnitEntry e : c.entries) known.add(e.unit);
        for(UnitType type : Vars.content.units()){
            if(type.hidden || type.internal || type.constructor == null) continue;
            if(known.contains(type.name)) continue;
            UnitEntry e = entry(guessTier(type), type, TIER_COST[Math.min(7, guessTier(type))], 1f, 1f, false);
            c.entries.add(e);
        }

        c.index();
        return c;
    }

    private static String defaultTierLabel(int t){
        return switch(t){
            case 1 -> "T1 - Разведка";
            case 2 -> "T2 - Штурм";
            case 3 -> "T3 - Тяжёлые";
            case 4 -> "T4 - Элита";
            case 5 -> "T5 - Боссы";
            case 6 -> "T6 - Легенды";
            case 7 -> "T7 - Титаны";
            default -> "T" + t;
        };
    }

    private static int guessTier(UnitType type){
        float hp = type.health;
        if(hp < 400) return 1;
        if(hp < 1200) return 2;
        if(hp < 3000) return 3;
        if(hp < 9000) return 4;
        return 5;
    }

    private static UnitEntry entry(int tier, UnitType type, int cost, float hp, float dmg, boolean enabled){
        UnitEntry e = new UnitEntry();
        e.tier = tier;
        e.unit = type.name;
        e.cost = cost;
        e.hpMult = hp;
        e.damageMult = dmg;
        e.enabled = enabled;
        e.category = CATEGORY.get(type.name, type.flying ? "air" : "mech");
        e.type = type;
        return e;
    }

    private static UnitType unit(String name){
        return Vars.content.getByName(ContentType.unit, name);
    }

    /** Привязывает UnitType по именам и строит индексы. Вызывается после загрузки json. */
    public void index(){
        byId.clear();
        byTier.clear();
        maxTier = 1;
        Seq<UnitEntry> broken = new Seq<>();
        for(UnitEntry e : entries){
            if(e.unit == null){
                broken.add(e);
                continue;
            }
            e.type = unit(e.unit);
            if(e.type == null){
                Log.warn("[OneUnitArena] Юнит '@' не найден - строка units.json пропущена.", e.unit);
                broken.add(e);
                continue;
            }
            e.parsedEffects.clear();
            if(e.effects != null){
                for(String eff : e.effects){
                    StatusEffect se = Vars.content.getByName(ContentType.status, eff);
                    if(se == null){
                        Log.warn("[OneUnitArena] Эффект '@' не найден (юнит @).", eff, e.unit);
                        continue;
                    }
                    e.parsedEffects.add(se);
                }
            }
            e.tier = Mathf.clamp(e.tier, 1, 12);
            byId.put(e.id(), e);
            byTier.get(e.tier, Seq::new).add(e);
            maxTier = Math.max(maxTier, e.tier);
        }
        entries.removeAll(broken);
        for(Seq<UnitEntry> list : byTier.values()){
            list.sort(u -> u.cost);
        }
        if(tierLabels == null) tierLabels = new ObjectMap<>();
    }

    public UnitEntry byId(String id){
        return byId.get(id);
    }

    public Seq<UnitEntry> tier(int t){
        return byTier.get(t, Seq::new);
    }

    public String label(int t){
        return tierLabels.get(String.valueOf(t), "T" + t);
    }

    /** Самый дешёвый включённый юнит (для автопика). */
    public UnitEntry cheapest(){
        UnitEntry best = null;
        for(UnitEntry e : entries){
            if(!e.valid()) continue;
            if(best == null || e.cost < best.cost || (e.cost == best.cost && e.tier < best.tier)) best = e;
        }
        return best;
    }

    /** Самый сильный доступный за очки юнит (для автопика при респавне). */
    public UnitEntry bestAffordable(int points, int maxTierAllowed){
        UnitEntry best = null;
        for(UnitEntry e : entries){
            if(!e.valid() || e.cost > points || e.tier > maxTierAllowed) continue;
            if(best == null || e.tier > best.tier || (e.tier == best.tier && e.cost > best.cost)) best = e;
        }
        return best == null ? cheapest() : best;
    }
}
