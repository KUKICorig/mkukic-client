package oneunit;

import arc.math.*;
import arc.math.geom.*;
import arc.struct.*;
import arc.util.*;
import mindustry.*;
import mindustry.content.*;
import mindustry.game.*;
import mindustry.game.EventType.*;
import mindustry.gen.*;
import mindustry.maps.*;
import mindustry.net.*;
import mindustry.type.*;

/** Ядро режима: лобби -> драфт -> отсчёт -> бой -> итоги. Всё считается на сервере. */
public class Match{
    public static Match inst;

    public enum Phase{lobby, draft, countdown, live, ending}

    public Phase phase = Phase.lobby;
    /** true - режим War Thunder (жизни + очки), false - классика на выбывание. */
    public boolean respawnMode = true;

    public Seq<ArenaPlayer> roster = new Seq<>();
    public ObjectMap<String, ArenaPlayer> byUuid = new ObjectMap<>();
    public transient IntMap<ArenaPlayer> byUnit = new IntMap<>();
    public Seq<Team> teams = new Seq<>();

    public String mapName = "";
    public int mapIndex = 0;
    public int round = 0;
    public float timer = 0f;
    public float matchTime = 0f;
    public float now = 0f;
    public Team winner;
    public boolean reloading;

    private float hudTimer, winTimer;

    public Match(){
        inst = this;
        respawnMode = OneUnit.settings.defaultMode.equals("respawn");
        loadTeams();
    }

    public void loadTeams(){
        teams.clear();
        for(String name : OneUnit.settings.teams){
            Team found = null;
            for(Team t : Team.all){
                if(t.name.equalsIgnoreCase(name)){
                    found = t;
                    break;
                }
            }
            if(found == null){
                Log.warn("[OneUnitArena] Команда '@' не найдена, пропускаю.", name);
                continue;
            }
            if(!teams.contains(found)) teams.add(found);
        }
        if(teams.size < 2){
            teams.clear();
            teams.add(Team.sharded, Team.crux);
        }
    }

    /** Идёт матч (или его финальные фазы) - действует блокировка управления. */
    public boolean inMatch(){
        return phase == Phase.countdown || phase == Phase.live || phase == Phase.ending;
    }

    // ---------------------------------------------------------------- участники

    public ArenaPlayer get(Player p){
        return p == null ? null : byUuid.get(p.uuid());
    }

    public boolean joined(Player p){
        return get(p) != null;
    }

    public Seq<ArenaPlayer> of(Team team){
        return roster.select(p -> p.team == team);
    }

    public int aliveCount(Team team){
        return of(team).count(ArenaPlayer::alive);
    }

    public int fightingCount(Team team){
        return of(team).count(ArenaPlayer::fighting);
    }

    public void join(Player p, @Nullable String teamName){
        if(p == null) return;
        if(joined(p)){
            Txt.send(p, "alreadyJoined");
            Ui.inst.lobby(p);
            return;
        }
        Team team;
        if(teamName == null || teamName.isEmpty()){
            team = OneUnit.settings.autoBalance ? balancedTeam() : teams.first();
        }else{
            team = teams.find(t -> t.name.equalsIgnoreCase(teamName));
            if(team == null){
                Txt.send(p, "badTeam", teams.toString(", ", t -> t.name));
                return;
            }
        }

        ArenaPlayer ap = new ArenaPlayer(p, team);
        ap.resetMatchStats(respawnMode);
        if(phase != Phase.lobby){
            // подключился во время матча - наблюдатель до следующего раунда
            ap.out = true;
            ap.lives = 0;
        }
        roster.add(ap);
        byUuid.put(ap.uuid, ap);
        p.team(team);

        if(teamName == null || teamName.isEmpty()) Txt.all("joined", p.name, roster.size);
        else Txt.all("joinedTeam", p.name, Txt.team(team), roster.size);

        if(phase != Phase.lobby) Txt.send(p, "spectating");
        Ui.inst.lobby(p);
        Ui.inst.refreshLobbyAll();
    }

    public void leave(Player p){
        ArenaPlayer ap = get(p);
        if(ap == null){
            Txt.send(p, "notJoined");
            return;
        }
        String name = ap.name();
        remove(ap);
        Txt.all("left", name);
        afterRosterChange();
    }

    public void remove(ArenaPlayer ap){
        despawn(ap);
        Ui.inst.closeAll(ap.player);
        roster.remove(ap);
        byUuid.remove(ap.uuid);
        // чистим ссылки на ушедшего в истории урона
        for(ArenaPlayer other : roster){
            other.incoming.remove(ap);
            other.incomingTime.remove(ap);
        }
    }

    private void afterRosterChange(){
        if(phase == Phase.live) checkWin();
        else if(phase == Phase.draft && !roster.isEmpty() && allPicked()) beginCountdown();
        Ui.inst.refreshLobbyAll();
    }

    public void setTeam(Player p, String teamName){
        ArenaPlayer ap = get(p);
        if(ap == null){
            join(p, teamName);
            return;
        }
        if(phase == Phase.live || phase == Phase.countdown){
            Txt.send(p, "pickLocked");
            return;
        }
        Team team = teams.find(t -> t.name.equalsIgnoreCase(teamName));
        if(team == null){
            Txt.send(p, "badTeam", teams.toString(", ", t -> t.name));
            return;
        }
        if(ap.team == team) return;
        ap.team = team;
        ap.player.team(team);
        Txt.send(p, "teamSwitched", Txt.team(team));
        Ui.inst.refreshLobbyAll();
    }

    public Team balancedTeam(){
        Team best = teams.first();
        int min = Integer.MAX_VALUE;
        for(Team t : teams){
            int size = of(t).size;
            if(size < min){
                min = size;
                best = t;
            }
        }
        return best;
    }

    public void toggleReady(Player p){
        ArenaPlayer ap = get(p);
        if(ap == null){
            Txt.send(p, "notJoined");
            return;
        }
        ap.ready = !ap.ready;
        Txt.send(p, ap.ready ? "readyOn" : "readyOff");
        Ui.inst.refreshLobbyAll();

        if(OneUnit.settings.autoStartWhenReady && phase == Phase.lobby && !roster.isEmpty()
        && roster.allMatch(a -> a.ready) && roster.size >= OneUnit.settings.minPlayers
        && teams.count(t -> of(t).size > 0) >= 2){
            Txt.all("allReady");
            startDraft(null);
        }
    }

    public boolean allPicked(){
        return roster.allMatch(a -> a.pick != null);
    }

    // ---------------------------------------------------------------- фазы

    public void startDraft(Player by){
        if(phase != Phase.lobby){
            Txt.send(by, "matchRunning");
            return;
        }
        if(roster.size < OneUnit.settings.minPlayers){
            Txt.send(by, "needPlayers", OneUnit.settings.minPlayers, roster.size);
            return;
        }
        if(teams.count(t -> of(t).size > 0) < 2){
            Txt.send(by, "needTwoTeams");
            return;
        }
        if(OneUnit.catalog.cheapest() == null){
            Txt.send(by, "noCatalog");
            return;
        }

        for(ArenaPlayer ap : roster){
            ap.resetMatchStats(respawnMode);
            ap.player.team(ap.team);
        }
        phase = Phase.draft;
        timer = OneUnit.settings.draftSeconds;
        winner = null;
        Txt.all("draftStarted", OneUnit.settings.draftSeconds);
        for(ArenaPlayer ap : roster){
            Ui.inst.closeAll(ap.player);
            Ui.inst.draft(ap.player);
        }
        Ui.inst.hudAll();
    }

    /** Выбор юнита: и на драфте, и при респавне. */
    public void pick(Player p, String entryId){
        ArenaPlayer ap = get(p);
        if(ap == null){
            Txt.send(p, "notJoined");
            return;
        }
        UnitEntry entry = OneUnit.catalog.byId(entryId);
        if(entry == null || !entry.valid()){
            Txt.send(p, "pickInvalid");
            return;
        }

        boolean draftPick = phase == Phase.draft;
        boolean respawnPick = phase == Phase.live && !ap.alive();

        if(!draftPick && !respawnPick){
            if(!(phase == Phase.live && OneUnit.settings.allowLiveSwitch && ap.alive())){
                Txt.send(p, "pickLocked");
                return;
            }
        }

        if(draftPick){
            if(entry.tier > OneUnit.settings.draft.maxTier){
                Txt.send(p, "tierLocked", OneUnit.settings.draft.maxTier);
                return;
            }
            if(!OneUnit.settings.draft.allowDuplicates && of(ap.team).contains(o -> o != ap && o.pick == entry)){
                Txt.send(p, "duplicateUnit");
                return;
            }
            if(OneUnit.settings.draft.chargePoints && entry.cost > ap.points){
                Txt.send(p, "notEnough", entry.cost, Txt.n(ap.points));
                return;
            }
            if(OneUnit.settings.draft.chargePoints) ap.points -= entry.cost;
            ap.pick = entry;
            ap.viewTier = entry.tier;
            if(ap.firstPick == null) ap.firstPick = entry;
            Txt.send(p, "youPicked", entry.display(), entry.tier, entry.cost);
            Ui.inst.refreshDraftAll();
            if(allPicked()) beginCountdown();
            return;
        }

        // респавн / живая смена
        if(ap.out || ap.lives <= 0){
            Txt.send(p, "outOfLives");
            return;
        }
        if(entry.tier > ap.maxTierAllowed()){
            Txt.send(p, "tierLocked", ap.maxTierAllowed());
            return;
        }
        if(entry.cost > ap.points){
            Txt.send(p, "notEnough", entry.cost, Txt.n(ap.points));
            return;
        }
        ap.points -= entry.cost;
        ap.pick = entry;
        ap.viewTier = entry.tier;
        if(ap.firstPick == null) ap.firstPick = entry;
        ap.respawnTimer = ap.respawnMenuTimer = -1f;
        ap.menuOpen = false;
        Ui.inst.close(p, Ui.RESPAWN);
        if(ap.alive()) despawn(ap);
        spawn(ap);
        Ui.inst.refreshRosterAll();
    }

    public void beginCountdown(){
        if(phase != Phase.draft) return;
        phase = Phase.countdown;
        timer = OneUnit.settings.countdownSeconds;
        Txt.all("countdown", OneUnit.settings.countdownSeconds);
        for(ArenaPlayer ap : roster){
            Ui.inst.closeAll(ap.player);
            Ui.inst.roster(ap.player);
        }
        Ui.inst.hudAll();
    }

    public void startMatch(){
        Settings s = OneUnit.settings;
        Map map = nextMap();
        if(map == null){
            Txt.all("mapMissing", s.arenaMaps.isEmpty() ? "?" : s.arenaMaps.peek());
            phase = Phase.lobby;
            return;
        }
        mapName = map.plainName();
        round++;

        // 1. Перезагрузка мира с сохранением подключений
        reloading = true;
        try{
            WorldReloader reloader = new WorldReloader();
            reloader.begin();

            Vars.world.loadMap(map);
            Rules rules = Vars.state.rules;
            Lock.apply(rules);
            Events.fire(new RulesLoadEvent(rules));

            // точки спавна снимаем до удаления ядер и до старта логики
            Spawns.captureCores();
            Vars.logic.play();
            if(s.removeCores) Spawns.removeCores();

            reloader.end();

            // 2. Команды и юниты
            byUnit.clear();
            matchTime = 0f;
            winner = null;
            for(ArenaPlayer ap : roster){
                ap.player.team(ap.team);
                ap.unit = null;
                ap.spawnIndex = 0;
                ap.clearIncoming();
                ap.out = false;
                ap.respawnTimer = ap.respawnMenuTimer = -1f;
                ap.menuOpen = false;
                if(ap.lives <= 0) ap.lives = respawnMode ? s.respawn.lives : 1;
                if(ap.pick == null) ap.pick = OneUnit.catalog.cheapest();
                if(ap.firstPick == null) ap.firstPick = ap.pick;
            }
            Call.setRules(Vars.state.rules);

            phase = Phase.live;
            for(ArenaPlayer ap : roster){
                if(!ap.connected()) continue;
                spawn(ap);
            }
        }catch(Throwable t){
            Log.err("[OneUnitArena] Не удалось запустить матч", t);
            Txt.all("mapMissing", mapName);
            phase = Phase.lobby;
            return;
        }finally{
            reloading = false;
        }

        Txt.all("matchStarted", Txt.f(respawnMode ? "modeRespawn" : "modeClassic"));
        Ui.inst.closeAllMenus();
        Ui.inst.hudAll();
    }

    public Map nextMap(){
        Settings s = OneUnit.settings;
        if(s.arenaMaps.isEmpty()) return null;
        for(int i = 0; i < s.arenaMaps.size; i++){
            String name = s.arenaMaps.get((mapIndex + i) % s.arenaMaps.size);
            Map found = findMap(name);
            if(found != null){
                mapIndex = (mapIndex + i + 1) % s.arenaMaps.size;
                return found;
            }
        }
        return null;
    }

    public static Map findMap(String name){
        if(name == null || name.isEmpty()) return null;
        String target = name.toLowerCase().replace('_', ' ').replace(".msav", "").trim();
        for(Map m : Vars.maps.all()){
            String plain = m.plainName().toLowerCase().replace('_', ' ').trim();
            if(plain.equals(target) || m.name().toLowerCase().equals(name.toLowerCase())) return m;
        }
        return Vars.maps.byName(name);
    }

    // ---------------------------------------------------------------- юниты

    public void spawn(ArenaPlayer ap){
        if(ap.pick == null || ap.player == null || !ap.connected()) return;
        UnitEntry entry = ap.pick;
        Vec2 pos = Spawns.find(ap);

        Unit unit = entry.type.spawn(ap.team, pos.x, pos.y, 90f);
        unit.maxHealth(entry.maxHp());
        unit.health(unit.maxHealth());
        unit.shield(entry.shield);
        unit.speedMultiplier(entry.speedMult);
        unit.spawnedByCore(false);
        ap.player.team(ap.team);
        Lock.setUnit(ap, unit);

        ap.unit = unit;
        byUnit.put(unit.id(), ap);
        ap.clearIncoming();

        applyEffects(ap, true);
        float protection = OneUnit.settings.respawn.spawnProtection;
        if(protection > 0) unit.apply(StatusEffects.invincible, protection * 60f);

        Call.spawnEffect(pos.x, pos.y, 90f, entry.type);
        Txt.send(ap.player, "spawned", entry.display(), entry.tier);
        Ui.inst.hud(ap.player);
    }

    public void despawn(ArenaPlayer ap){
        if(ap.unit != null){
            byUnit.remove(ap.unit.id());
            if(ap.unit.isAdded()) ap.unit.remove();
            ap.unit = null;
        }
        if(ap.player != null && ap.player.isAdded()) Lock.setUnit(ap, null);
    }

    public void applyEffects(ArenaPlayer ap, boolean force){
        if(ap.unit == null || ap.pick == null || ap.pick.parsedEffects.isEmpty()) return;
        if(!force){
            ap.effectTimer -= Time.delta / Time.toSeconds;
            if(ap.effectTimer > 0) return;
        }
        ap.effectTimer = 1f;
        for(StatusEffect effect : ap.pick.parsedEffects){
            ap.unit.apply(effect, 130f);
        }
    }

    // ---------------------------------------------------------------- урон и смерть

    /** Множитель урона из units.json применяется к каждой пуле бойца. */
    public void onBullet(Bullet bullet){
        if(bullet == null || !(bullet.owner instanceof Unit owner)) return;
        ArenaPlayer ap = byUnit.get(owner.id());
        if(ap == null || ap.pick == null) return;
        float mult = ap.pick.damageMult;
        if(mult != 1f){
            bullet.damage(bullet.damage() * mult);
        }
    }

    public void onDamage(Unit victim, Bullet bullet){
        if(victim == null) return;
        ArenaPlayer target = byUnit.get(victim.id());
        if(target == null || bullet == null) return;
        if(!(bullet.owner instanceof Unit owner)) return;
        ArenaPlayer from = byUnit.get(owner.id());
        if(from == null || from == target || from.team == target.team) return;

        float amount = Math.max(0f, bullet.damage());
        target.hit(from, amount, now);
        from.damage += amount;

        float rate = OneUnit.settings.respawn.damagePointsPer1000;
        if(respawnMode && rate > 0){
            from.points += amount / 1000f * rate;
        }
    }

    public void onDeath(Unit unit){
        if(unit == null) return;
        ArenaPlayer ap = byUnit.get(unit.id());
        if(ap == null) return;
        byUnit.remove(unit.id());
        ap.unit = null;
        handleDeath(ap);
    }

    public void handleDeath(ArenaPlayer ap){
        Settings.Respawn cfg = OneUnit.settings.respawn;
        ap.deaths++;
        ap.menuOpen = false;
        ap.respawnMenuTimer = -1f;
        ap.captureZone = "";
        ap.captureTimer = 0f;

        // киллер - последний нанёсший урон, ассисты - остальные с достаточным вкладом
        ArenaPlayer killer = null;
        float lastTime = -1f;
        float total = 0f;
        for(ObjectMap.Entry<ArenaPlayer, Float> e : ap.incoming){
            if(now - ap.incomingTime.get(e.key, -999f) > cfg.damageMemory) continue;
            total += e.value;
            float t = ap.incomingTime.get(e.key, 0f);
            if(t > lastTime){
                lastTime = t;
                killer = e.key;
            }
        }
        final ArenaPlayer finalKiller = killer;
        for(ObjectMap.Entry<ArenaPlayer, Float> e : ap.incoming){
            ArenaPlayer other = e.key;
            if(other == finalKiller || !other.connected()) continue;
            if(now - ap.incomingTime.get(other, -999f) > cfg.damageMemory) continue;
            if(total > 0 && e.value / total >= cfg.assistThreshold){
                other.assists++;
                if(respawnMode){
                    other.points += cfg.assistPoints;
                    Txt.send(other.player, "youAssisted", cfg.assistPoints, ap.name());
                }
            }
        }
        String victimUnit = ap.pick == null ? "?" : ap.pick.display();
        if(killer != null && killer.connected()){
            killer.kills++;
            int bounty = cfg.killPoints + (ap.pick == null ? 0 : ap.pick.cost / 2);
            if(respawnMode){
                killer.points += bounty;
                Txt.send(killer.player, "youKilled", bounty, ap.name());
            }
            if(OneUnit.settings.hud.killFeed){
                Txt.all("killFeed", killer.name(), killer.pick == null ? "?" : killer.pick.display(), ap.name(), victimUnit);
            }
        }else if(OneUnit.settings.hud.killFeed){
            Txt.all("killFeed", "-", "-", ap.name(), victimUnit);
        }
        ap.clearIncoming();

        // штраф/возврат очков
        if(ap.pick != null && cfg.refundOnDeath > 0 && respawnMode){
            ap.points += ap.pick.cost * cfg.refundOnDeath;
        }
        if(cfg.pointsLossOnDeath > 0 && respawnMode){
            ap.points *= 1f - Mathf.clamp(cfg.pointsLossOnDeath / 100f, 0f, 1f);
        }

        Txt.send(ap.player, "youDied", killer == null ? "-" : killer.name());

        // уводим игрока из мёртвого юнита
        if(ap.player != null && ap.player.isAdded()){
            Lock.setUnit(ap, null);
            if(OneUnit.settings.tweaks.spectatorCamera){
                Vec2 focus = killer != null && killer.alive() ? new Vec2(killer.unit.x, killer.unit.y) : Spawns.center();
                Call.setCameraPosition(ap.player.con, focus.x, focus.y);
            }
        }

        ap.lives--;
        if(!respawnMode || ap.lives <= 0){
            ap.out = true;
            ap.lives = Math.max(0, ap.lives);
            Txt.send(ap.player, respawnMode ? "outOfLives" : "diedClassic");
        }else{
            ap.respawnTimer = cfg.respawnDelay;
            Txt.send(ap.player, "diedRespawn", ap.lives, Txt.n(ap.points));
            Txt.send(ap.player, "respawnWait", Txt.n(cfg.respawnDelay));
        }
        Ui.inst.hud(ap.player);
        Ui.inst.refreshRosterAll();
        checkWin();
    }

    // ---------------------------------------------------------------- победа

    public void checkWin(){
        if(phase != Phase.live || reloading) return;
        Seq<Team> playing = teams.select(t -> of(t).size > 0);
        if(playing.isEmpty()){
            endMatch(null);
            return;
        }
        Seq<Team> alive = playing.select(t -> fightingCount(t) > 0);
        if(alive.size <= 1){
            endMatch(alive.isEmpty() ? null : alive.first());
        }
    }

    public void endMatch(Team win){
        if(phase != Phase.live) return;
        winner = win;
        phase = Phase.ending;
        timer = OneUnit.settings.endScreenSeconds;

        for(Team t : teams){
            if(fightingCount(t) == 0 && of(t).size > 0){
                Txt.all("teamEliminated", Txt.team(t));
            }
        }
        if(win == null) Txt.all("draw");
        else Txt.all("win", Txt.team(win));

        for(ArenaPlayer ap : roster){
            despawn(ap);
            Ui.inst.closeAll(ap.player);
            Ui.inst.results(ap.player);
        }
        Ui.inst.hudAll();
    }

    public void timeUp(){
        Team best = null;
        float bestScore = -1f;
        boolean tie = false;
        for(Team t : teams){
            if(of(t).isEmpty()) continue;
            float score = 0f;
            for(ArenaPlayer ap : of(t)) score += ap.score();
            if(score > bestScore){
                bestScore = score;
                best = t;
                tie = false;
            }else if(score == bestScore){
                tie = true;
            }
        }
        Txt.all("timeUp", best == null || tie ? "-" : Txt.team(best));
        endMatch(tie ? null : best);
    }

    public void stop(Player by){
        if(phase == Phase.lobby){
            Txt.send(by, "noMatch");
            return;
        }
        Txt.all("matchStop");
        for(ArenaPlayer ap : roster){
            despawn(ap);
            Ui.inst.closeAll(ap.player);
            ap.ready = false;
            ap.out = false;
            ap.menuOpen = false;
            ap.respawnTimer = ap.respawnMenuTimer = -1f;
        }
        byUnit.clear();
        phase = Phase.lobby;
        winner = null;
        matchTime = 0f;
        Ui.inst.hudAll();
    }

    public void resetToLobby(){
        for(ArenaPlayer ap : roster){
            despawn(ap);
            ap.ready = false;
            ap.out = false;
            ap.pick = null;
            ap.respawnTimer = ap.respawnMenuTimer = -1f;
            ap.menuOpen = false;
            ap.captureZone = "";
            Ui.inst.closeAll(ap.player);
        }
        byUnit.clear();
        phase = Phase.lobby;
        winner = null;
        matchTime = 0f;

        String lobbyMap = OneUnit.settings.lobbyMap;
        if(lobbyMap != null && !lobbyMap.isEmpty()){
            Map map = findMap(lobbyMap);
            if(map != null){
                reloading = true;
                try{
                    WorldReloader reloader = new WorldReloader();
                    reloader.begin();
                    Vars.world.loadMap(map);
                    Rules rules = Vars.state.rules;
                    Lock.apply(rules);
                    Events.fire(new RulesLoadEvent(rules));
                    Vars.logic.play();
                    reloader.end();
                    for(ArenaPlayer ap : roster){
                        if(ap.connected()) ap.player.team(ap.team);
                    }
                    Call.setRules(Vars.state.rules);
                }catch(Throwable t){
                    Log.err("[OneUnitArena] Не удалось загрузить лобби-карту", t);
                }finally{
                    reloading = false;
                }
            }else{
                Log.warn("[OneUnitArena] Лобби-карта '@' не найдена.", lobbyMap);
            }
        }
        Txt.all("backToLobby");
        Ui.inst.hudAll();
    }

    /** Внешняя смена карты (host/changemap из консоли) - сбрасываем матч. */
    public void onWorldReset(){
        if(reloading) return;
        Spawns.cores.clear();
        byUnit.clear();
        if(phase == Phase.lobby) return;
        phase = Phase.lobby;
        for(ArenaPlayer ap : roster){
            ap.unit = null;
            ap.ready = false;
            ap.out = false;
            ap.pick = null;
            ap.menuOpen = false;
            ap.respawnTimer = ap.respawnMenuTimer = -1f;
            Ui.inst.closeAll(ap.player);
        }
        Log.info("[OneUnitArena] Мир сброшен извне - матч остановлен.");
    }

    public void setMode(boolean respawn){
        if(respawnMode == respawn) return;
        respawnMode = respawn;
        Txt.all("modeChanged", Txt.f(respawn ? "modeRespawn" : "modeClassic"));
        if(phase == Phase.lobby){
            for(ArenaPlayer ap : roster) ap.resetMatchStats(respawnMode);
        }
        Ui.inst.refreshLobbyAll();
        Ui.inst.hudAll();
    }

    public void addPoints(Player target, float amount){
        ArenaPlayer ap = get(target);
        if(ap == null) return;
        ap.points += amount;
        Txt.send(target, "pointsAdded", target.name, Txt.n(amount));
        Ui.inst.hud(target);
    }

    // ---------------------------------------------------------------- тик

    public void update(){
        float dt = Time.delta / Time.toSeconds;
        now += dt;

        switch(phase){
            case draft -> {
                timer -= dt;
                if(timer <= 0f){
                    autoPickAll();
                    beginCountdown();
                }
            }
            case countdown -> {
                timer -= dt;
                if(timer <= 0f) startMatch();
            }
            case live -> tickLive(dt);
            case ending -> {
                timer -= dt;
                if(timer <= 0f){
                    if(OneUnit.settings.autoReturnToLobby) resetToLobby();
                    else phase = Phase.lobby;
                }
            }
            default -> { }
        }

        hudTimer -= dt;
        if(hudTimer <= 0f){
            hudTimer = OneUnit.settings.hud.interval;
            Ui.inst.hudAll();
        }
    }

    private void autoPickAll(){
        for(ArenaPlayer ap : roster){
            if(ap.pick != null) continue;
            UnitEntry auto;
            if(OneUnit.settings.draft.autoPickStrongest){
                int budget = OneUnit.settings.draft.chargePoints ? (int)ap.points : Integer.MAX_VALUE;
                auto = OneUnit.catalog.bestAffordable(budget, OneUnit.settings.draft.maxTier);
            }else{
                auto = OneUnit.catalog.cheapest();
            }
            if(auto == null) continue;
            if(OneUnit.settings.draft.chargePoints) ap.points -= Math.min(ap.points, auto.cost);
            ap.pick = auto;
            if(ap.firstPick == null) ap.firstPick = auto;
            Txt.all("draftAuto", ap.name(), auto.display());
        }
    }

    private void tickLive(float dt){
        matchTime += dt;
        Settings.Respawn cfg = OneUnit.settings.respawn;

        for(ArenaPlayer ap : roster){
            if(!ap.connected()) continue;

            if(ap.alive()){
                Lock.tick(ap);
                applyEffects(ap, false);
                if(respawnMode && cfg.pointsPerSecond > 0) ap.points += cfg.pointsPerSecond * dt;
                if(respawnMode && cfg.capturePointsPerSecond > 0) capture(ap, dt);
            }else{
                // страховка: юнит исчез без события смерти
                if(ap.unit != null && !ap.unit.isAdded()){
                    byUnit.remove(ap.unit.id());
                    ap.unit = null;
                    handleDeath(ap);
                    continue;
                }
                if(ap.out || ap.lives <= 0 || !respawnMode) continue;

                if(ap.respawnTimer > 0f){
                    ap.respawnTimer -= dt;
                    if(ap.respawnTimer <= 0f) openRespawn(ap);
                }else if(ap.menuOpen){
                    ap.respawnMenuTimer -= dt;
                    if(ap.respawnMenuTimer <= 0f){
                        UnitEntry auto = OneUnit.catalog.bestAffordable((int)ap.points, ap.maxTierAllowed());
                        ap.menuOpen = false;
                        ap.respawnMenuTimer = -1f;
                        if(auto != null){
                            Txt.send(ap.player, "respawnAuto", auto.display());
                            pick(ap.player, auto.id());
                        }
                    }
                }else{
                    // меню закрыли крестиком - открываем снова, чтобы игрок не завис
                    ap.respawnTimer = cfg.menuReopenDelay;
                }
            }
        }

        winTimer -= dt;
        if(winTimer <= 0f){
            winTimer = 0.5f;
            checkWin();
        }

        int limit = OneUnit.settings.matchMinutes;
        if(limit > 0 && matchTime >= limit * 60f){
            timeUp();
        }
    }

    public void openRespawn(ArenaPlayer ap){
        Settings.Respawn cfg = OneUnit.settings.respawn;
        ap.respawnTimer = -1f;
        ap.menuOpen = true;
        ap.respawnMenuTimer = cfg.respawnTimeout;
        ap.viewTier = Mathf.clamp(ap.viewTier, 1, OneUnit.catalog.maxTier);
        Txt.send(ap.player, "respawnReady", Txt.n(ap.points));
        Ui.inst.respawn(ap.player);
    }

    private void capture(ArenaPlayer ap, float dt){
        Settings.MapConfig cfg = Spawns.configFor(mapName);
        if(cfg == null || cfg.zones.isEmpty()){
            ap.captureZone = "";
            return;
        }
        String inside = "";
        for(Settings.Zone z : cfg.zones){
            float zx = z.x * Vars.tilesize, zy = z.y * Vars.tilesize;
            if(Mathf.dst(ap.unit.x, ap.unit.y, zx, zy) <= z.radius * Vars.tilesize){
                inside = z.name;
                break;
            }
        }
        if(inside.isEmpty()){
            ap.captureZone = "";
            ap.captureTimer = 0f;
            return;
        }
        ap.captureZone = inside;
        ap.points += OneUnit.settings.respawn.capturePointsPerSecond * dt;
        ap.captureTimer += dt;
        if(ap.captureTimer >= 10f){
            ap.captureTimer = 0f;
            ap.captures++;
            Txt.all("capture", ap.name(), inside);
        }
    }

    // ---------------------------------------------------------------- разное

    public void onJoin(Player p){
        Txt.send(p, "welcome");
        if(OneUnit.settings.autoJoin && !joined(p)){
            join(p, null);
        }else if(phase != Phase.lobby){
            Txt.send(p, "spectating");
            Time.runTask(90f, () -> {
                if(p.isAdded()) Ui.inst.roster(p);
            });
        }else{
            Time.runTask(90f, () -> {
                if(p.isAdded()) Ui.inst.lobby(p);
            });
        }
    }

    public void onLeave(Player p){
        ArenaPlayer ap = get(p);
        if(ap == null) return;
        String name = ap.name();
        remove(ap);
        Txt.all("left", name);
        afterRosterChange();
    }

    public String phaseName(){
        return switch(phase){
            case lobby -> "лобби";
            case draft -> "драфт";
            case countdown -> "старт";
            case live -> "бой";
            case ending -> "итоги";
        };
    }

    public float timeLeft(){
        int limit = OneUnit.settings.matchMinutes;
        if(phase == Phase.live && limit > 0) return Math.max(0f, limit * 60f - matchTime);
        return Math.max(0f, timer);
    }
}
