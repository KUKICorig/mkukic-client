package rl.core;

import java.time.Instant;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.List;
import java.util.Map;

/**
 * Лог. Формат — JSON Lines: по одной JSON-записи на строку, файл на каждый день
 * (logs/2026-11-04.log).
 *
 * ВАЖНО: ник игрока пишется ТОЛЬКО сюда. В аккаунтах, статистике и ответах игрокам
 * фигурирует исключительно ID.
 */
public class GameLog {

    public static final String EV_SPIN = "spin";
    public static final String EV_BET = "bet";
    public static final String EV_PAYOUT = "payout";
    public static final String EV_DEPOSIT = "deposit";
    public static final String EV_WITHDRAW = "withdraw";
    public static final String EV_TRANSFER = "transfer";
    public static final String EV_ADMIN = "admin";
    public static final String EV_CONFIG = "config";
    public static final String EV_SEED = "seed";
    public static final String EV_INCOME = "income";
    public static final String EV_HOUSE = "house";
    public static final String EV_DENY = "deny";
    public static final String EV_ERROR = "error";
    public static final String EV_WEB = "web";

    private static final DateTimeFormatter ISO = DateTimeFormatter.ISO_OFFSET_DATE_TIME;

    private final Fs fs;
    private final String dir;
    private final Object lock = new Object();
    private final Deque<Map<String, Object>> recent = new ArrayDeque<>();
    private final int recentCap;
    private ZoneId zone = ZoneId.of("UTC");

    public GameLog(Fs fs, String dir, int recentCap) {
        this.fs = fs;
        this.dir = dir;
        this.recentCap = Math.max(16, recentCap);
        fs.mkdirs(dir);
    }

    public void setZone(ZoneId zone) {
        this.zone = zone == null ? ZoneId.of("UTC") : zone;
    }

    public ZoneId zone() { return zone; }

    public String today() {
        return DateTimeFormatter.ofPattern("yyyy-MM-dd").withZone(zone).format(Instant.now());
    }

    public String fileName(String day) {
        return day + ".log";
    }

    public String path(String day) {
        return fs.child(dir, fileName(day));
    }

    /** Записать событие. extra может быть null. */
    public void log(String event, Map<String, Object> fields) {
        Map<String, Object> e = Json.obj();
        long now = System.currentTimeMillis();
        e.put("ts", ISO.format(Instant.ofEpochMilli(now)));
        e.put("ms", now);
        e.put("event", event);
        if (fields != null) e.putAll(fields);
        String line = Json.writeCompact(e);
        synchronized (lock) {
            recent.addLast(e);
            while (recent.size() > recentCap) recent.removeFirst();
        }
        try {
            fs.append(path(today()), line + "\n");
        } catch (Exception ignored) {
            // лог не должен ронять игровой процесс
        }
    }

    /** Последние N записей из памяти (быстро, для дашборда). */
    public List<Map<String, Object>> recent(int limit) {
        synchronized (lock) {
            List<Map<String, Object>> all = new ArrayList<>(recent);
            int from = Math.max(0, all.size() - limit);
            List<Map<String, Object>> out = new ArrayList<>(all.subList(from, all.size()));
            java.util.Collections.reverse(out);
            return out;
        }
    }

    /** Последние N строк файла за день. */
    public List<String> tail(String day, int limit) {
        String raw = fs.readOr(path(day), "");
        if (raw.isEmpty()) return new ArrayList<>();
        String[] lines = raw.split("\n");
        int from = Math.max(0, lines.length - Math.max(1, limit));
        List<String> out = new ArrayList<>();
        for (int i = lines.length - 1; i >= from; i--) {
            if (!lines[i].trim().isEmpty()) out.add(lines[i]);
        }
        return out;
    }

    public List<String> days() {
        List<String> days = new ArrayList<>();
        for (String name : fs.list(dir)) {
            if (name.endsWith(".log")) days.add(name.substring(0, name.length() - 4));
        }
        days.sort(java.util.Collections.reverseOrder());
        return days;
    }

    public String raw(String day) {
        return fs.readOr(path(day), "");
    }

    /** Удалить логи старше keepDays (0 = не удалять). */
    public int prune(int keepDays) {
        if (keepDays <= 0) return 0;
        long cutoff = System.currentTimeMillis() - keepDays * 86_400_000L;
        String cutDay = DateTimeFormatter.ofPattern("yyyy-MM-dd").withZone(zone)
                .format(Instant.ofEpochMilli(cutoff));
        int removed = 0;
        for (String day : days()) {
            if (day.compareTo(cutDay) < 0) {
                if (fs.delete(path(day))) removed++;
            }
        }
        return removed;
    }

    /** ID -> последний известный ник (только для админки, берётся из логов). */
    public Map<String, String> idToNick(int scanLimit) {
        Map<String, String> out = new LinkedHashMapSafe();
        for (String day : days()) {
            for (String line : tail(day, scanLimit)) {
                Json.Node n = Json.Node.of(Json.parse(line));
                String id = n.str("id", "");
                String nick = n.str("nick", "");
                if (!id.isEmpty() && !nick.isEmpty()) out.put(id, nick);
            }
        }
        for (Map<String, Object> e : recent(scanLimit)) {
            Json.Node n = Json.Node.of(e);
            String id = n.str("id", "");
            String nick = n.str("nick", "");
            if (!id.isEmpty() && !nick.isEmpty()) out.put(id, nick);
        }
        return out;
    }

    /** LinkedHashMap с сохранением порядка вставки (отдельный класс, чтобы не тянуть импорт в сигнатуру). */
    private static final class LinkedHashMapSafe extends java.util.LinkedHashMap<String, String> {}
}
