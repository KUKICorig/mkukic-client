# Сторонние компоненты / Third-party notices

Этот файл описывает происхождение и лицензирование частей MKUKIC Client, которые
производны от сторонних открытых проектов. Остальной код мода принадлежит его автору
и этим файлом не перелицензируется.

---

## 1. Foo's Client (mindustry-mod)

- Автор: **BalaM314**
- Репозиторий: <https://github.com/BalaM314/mindustry-mod>
- Лицензия: **GNU General Public License v3.0 (GPL-3.0)**
- Полный текст лицензии: <https://www.gnu.org/licenses/gpl-3.0.txt>

Foo's Client — открытый клиент-мод для Mindustry, реализующий авто-стройку, авто-копку,
pathfinding-навигацию, freecam, отображение дальности турелей, force place, защищённый чат
и набор клиентских команд.

**Как используется в MKUKIC.** Отдельные механизмы Onix-слоя v1.19
(`src/mkukic/client/onix/`: `OnixAutoUnit`, `OnixAutoFill`, `OnixBot`, `OnixNav`,
`OnixCommands`, `OnixChat`) повторяют по назначению функции, впервые описанные/реализованные
в Foo's Client, и являются **производной работой** в смысле GPL-3.0. Эти модули написаны
самостоятельно под архитектуру MKUKIC (общий `MKUKICSettings`, фирменный `MKUKICSkin`,
фасад `Onix.java`, подключение через `ClientHook`), без копирования исходного кода
Foo's Client; заимствованы идеи и поведение. В силу GPL-3.0 данные модули распространяются
на условиях GPL-3.0 — включая обязательство предоставлять их исходный текст (он находится
в этом же репозитории, в `src/mkukic/client/onix/`) и сохранять уведомления об авторстве.

## 2. Onix Lite

- Автор: **DiscoD3979**
- Репозиторий: <https://github.com/DiscoD3979/OnixLite> (релизы: `Onix-Lite.jar`)
- Лицензия репозитория: **GPL-3.0**

Onix Lite — клиент-мод для Mindustry, форк Foo's Client. Распространяется в виде jar с
зашифрованным содержимым (`data.bin` не дешифруется сторонними средствами), исходный код
в публичном репозитории отсутствует.

**Как используется в MKUKIC.** Список возможностей Onix-слоя v1.19 восстановлен **по
публичной документации**: текстовый перечень `features` внутри распространяемого jar и
описания релизов 3.4.4–3.4.6 (авто-юнит, копирование из чата, ники с цветами, детект Onix,
кнопки голосования, единый индикатор загрузки с ETA, фоновые обновления, переключатели
анимаций, поиск по панели, клиентские команды, консоль, аккаунты, обход бана).
**Зашифрованный код Onix Lite не декомпилировался и не копировался**; вся реализация
написана с нуля. Там, где соответствующая функция восходит к Foo's Client, применяются
условия раздела 1.

Функции, которые в Onix Lite помечены как доступные «только в полной версии»
(спам, гриф, авто-выход, Discord RPC, Seer), **не портировались намеренно**.

**Отличия реализации.** Детект клиентов в Onix основан на «мышиных маяках» — скрытом
обмене сигналами через ввод, что требует контроля над клиентом игры и недоступно моду.
`OnixClientDetect` в MKUKIC — **поведенческая эвристика** (реакция на движение курсора,
паттерны ввода, теги ника), она не воспроизводит протокол Onix и не даёт гарантий:
возможны как ложные срабатывания, так и пропуски.

## 3. Mindustry

- Автор: **Anuken**
- Репозиторий: <https://github.com/Anuken/Mindustry>
- Лицензия: **GPL-3.0**

MKUKIC Client — мод (производная работа) для Mindustry v8 build 160.x и собирается
против `dependencies.jar`/`vanilla.jar` соответствующей версии игры.

---

## Уведомление GPL-3.0 (шапка для производных файлов)

Файлы в `src/mkukic/client/onix/` и `src/mkukic/client/OnixPanel.java` распространяются
на условиях GNU General Public License версии 3:

    MKUKIC Client — Onix layer
    Copyright (C) 2026  MKUKIC / KUKIC

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <https://www.gnu.org/licenses/>.

Полный текст GPL-3.0 в состав архива не включён (объём ~35 КБ) — он доступен по адресу
<https://www.gnu.org/licenses/gpl-3.0.txt>. При публичном распространении мода
рекомендуется положить рядом файл `LICENSE` с полным текстом GPL-3.0.
