package rl.core;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Все настройки рулетки. Хранятся в config.json в папке мода и правятся через веб-админку.
 *
 * Всё публичные поля — конфиг намеренно «плоский» и сериализуется в тот же JSON,
 * который видит админка (см. {@link #toMap()} / {@link #fromMap(Map)}).
 */
public class Config {

    // ------------------------------------------------------------------ общее
    public static class General {
        /** Мастер-выключатель: если false — ставки не принимаются. */
        public boolean enabled = true;
        /** ID (uuid) аккаунта бота-казино. Проигрыши уходят ему, выигрыши платятся из него. */
        public String houseId = "HOUSE";
        /** Часовой пояс для суточных лимитов и дат логов. */
        public String timezone = "UTC";
        /** Как подписывать игрока в общих сообщениях (в чате видно всем). */
        public String displayName = "Игрок";
    }

    // --------------------------------------------------------------- команды
    public static class Commands {
        /** /pay <id> <сумма> — перевод на ID бота = ставка в рулетку. */
        public boolean payAlias = true;
        /** /rl <сумма> — основная команда ставки. */
        public String bet = "rl";
        /** Дополнительный алиас ставки. */
        public String betAlias = "roulette";
        /** Разрешить P2P-переводы между игроками внутри нашего кошелька (если на сервере нет своего /pay). */
        public boolean allowTransfers = true;
        /** Комиссия на P2P-перевод, %. */
        public double transferFeePercent = 0.0;
    }

    // --------------------------------------------------------------- рулетка
    public static class Roulette {
        /** "classic" = шанс/множитель, "segments" = секторы с весами. */
        public String mode = "segments";
        /** Шанс победы в classic-режиме, %. */
        public double winChancePercent = 45.0;
        /** Множитель выплаты в classic-режиме (2.0 = x2). */
        public double multiplier = 2.0;
        /**
         * Если > 0 — множитель в classic-режиме подбирается автоматически под нужный RTP:
         * multiplier = targetRtpPercent / winChancePercent.
         */
        public double targetRtpPercent = 0.0;
        /** Комиссия казино с каждой выплаты, %. */
        public double rakePercent = 0.0;
        /** Секторы для режима segments. */
        public List<Segment> segments = defaultSegments();
    }

    // ---------------------------------------------------------------- ставки
    public static class Betting {
        public long minBet = 50;
        public long maxBet = 100_000;
        /** Кулдаун между ставками одного игрока, мс. */
        public long cooldownMs = 5_000;
        /** Не более одной одновременной глобальной анимации (иначе каша в чате). */
        public boolean oneSpinAtATime = true;
        /** Сколько ставок можно «поставить в очередь» пока крутится чужая рулетка. 0 = очередь выключена. */
        public int maxQueue = 0;
        /** Лимит проигрыша на игрока в сутки, 0 = выкл. */
        public long dailyLossLimit = 0;
        /** Лимит выигрыша на игрока в сутки, 0 = выкл. */
        public long dailyWinLimit = 0;
        /** Максимум одновременных незакрытых ставок на игрока. */
        public int maxActiveBetsPerPlayer = 1;
    }

    // -------------------------------------------------------------- экономика
    public static class Economy {
        /** "internal" — кошелёк ведёт сам плагин (балансы по ID в accounts.json). */
        public String mode = "internal";
        /** Стартовый баланс нового игрока (первый раз, когда плагин его увидел). */
        public long startingBalance = 0;
        /** Если > 0 — начислять игроку раз в N минут. */
        public long incomeIntervalMinutes = 0;
        public long incomeAmount = 0;
        /**
         * Если на сервере стоит свой плагин экономики — можно «зеркалить» операции туда
         * через рефлексию. По умолчанию выключено.
         */
        public static class Mirror {
            public boolean enabled = false;
            public String className = "";
            public String balanceMethod = "getBalance";       // (String id) -> long
            public String withdrawMethod = "withdraw";       // (String id, long amount) -> boolean
            public String depositMethod = "deposit";         // (String id, long amount) -> boolean
        }
        public Mirror mirror = new Mirror();
        /**
         * Автоматически пополнять банкролл бота, если он ушёл в минус ниже houseMinBalance
         * («эмиссия», пишется в лог как house_topup).
         */
        public boolean houseAutoTopup = false;
        public long houseMinBalance = 1_000_000;
        public long houseTopupAmount = 1_000_000;
    }

    // ------------------------------------------------------------- анимация
    public static class Animation {
        public boolean enabled = true;
        /** Кадров анимации. */
        public int frames = 14;
        /** Интервал между кадрами, мс. */
        public long frameMs = 130;
        /** Сколько символов видно в «окне» ленты. */
        public int window = 7;
        /** Символ-указатель. */
        public String marker = "▲";
        /** Символы ленты (последний символ используется как «пустышка»-разделитель). */
        public String symbols = "🍒🍋🔔⭐💎7️⃣🍀";
        /** Показывать ник игрока в кадрах анимации. */
        public boolean showNick = true;
        /** Писать результат только ставившему (в общий чат не спамим). */
        public boolean privateOnly = false;
        /** Транслировать анимацию в общий чат (если false — только старт и результат). */
        public boolean broadcastFrames = true;
    }

    // ------------------------------------------------------------ provably fair
    public static class Fair {
        /** Включить проверяемый рандом (serverSeedHash + clientSeed + nonce -> HMAC-SHA256). */
        public boolean enabled = true;
        /** Сид игрока по умолчанию (игрок может сменить через /rl seed). */
        public String defaultClientSeed = "rawhex";
    }

    // ------------------------------------------------------------ сообщения
    public static class Messages {
        public String prefix = "[gold]🎰[royal] Рулетка[] ";
        public String balance = "Баланс ID {id}: {balance} 🪙";
        public String notEnough = "Не хватает монет. Баланс ID {id}: {balance} 🪙, ставка: {bet} 🪙";
        public String betTooSmall = "Минимальная ставка: {min} 🪙";
        public String betTooBig = "Максимальная ставка: {max} 🪙";
        public String cooldown = "Подожди {sec} сек. до следующей ставки.";
        public String busy = "Рулетка сейчас крутится. Попробуй через пару секунд.";
        public String queueFull = "Очередь ставок заполнена. Подожди окончания текущего спина.";
        public String spinStart = "{nick} ставит {bet} 🪙 на x{mult}…";
        public String win = "{nick} выигрывает {payout} 🪙 (ставка {bet}, x{mult}, сектор {symbol})!";
        public String lose = "{nick} проигрывает {bet} 🪙 (сектор {symbol}). Монеты уходят боту.";
        public String dailyLoss = "Достигнут суточный лимит проигрыша ({limit} 🪙). Приходи завтра.";
        public String dailyWin = "Достигнут суточный лимит выигрыша ({limit} 🪙). Приходи завтра.";
        public String disabled = "Рулетка сейчас выключена.";
        public String banned = "Тебе запрещено играть.";
        public String unknownId = "Не разобрал ID/сумму. Пример: /pay {house} 500";
        public String depositOk = "Ставка принята: {amount} 🪙 с ID {id}. Крутим!";
        public String transferOk = "Переведено {amount} 🪙 на ID {to}. Баланс: {balance} 🪙";
        public String transferNoFunds = "Недостаточно монет для перевода. Баланс: {balance} 🪙";
        public String houseShort = "У бота не хватает монет на выплату. Попробуй ставку меньше.";
        public String verify = "Спин #{nonce}: seedHash={seedHash} clientSeed={client} hash={hash}";
    }

    // --------------------------------------------------------------- лимиты
    public static class Limits {
        /** ID, которым запрещено играть. */
        public List<String> bannedIds = new ArrayList<>();
        /** ID админов рулетки (могут крутить настройки прямо из игры). Пусто = только админы сервера. */
        public List<String> adminIds = new ArrayList<>();
    }

    // ------------------------------------------------------------- веб-админка
    public static class Web {
        public boolean enabled = true;
        /** 0.0.0.0 — слушать все интерфейсы (нужно для внешнего доступа), 127.0.0.1 — только локально. */
        public String bind = "0.0.0.0";
        public int port = 8787;
        /** Токен админки. ОБЯЗАТЕЛЬНО смените на свой! */
        public String token = "changeme-roulette-token";
        /** Разрешать вход только с этих IP (пусто = без ограничений). */
        public List<String> allowIps = new ArrayList<>();
        public boolean enableCors = true;
        /** Сколько дней хранить файлы логов, 0 = вечно. */
        public int logKeepDays = 30;
        /** Максимум строк лога, отдаваемых за один запрос. */
        public int maxLogLines = 5000;
        /** Максимум спинов в симуляторе RTP за один запрос. */
        public int maxSimSpins = 200_000;
    }

    public General general = new General();
    public Commands commands = new Commands();
    public Roulette roulette = new Roulette();
    public Betting betting = new Betting();
    public Economy economy = new Economy();
    public Animation animation = new Animation();
    public Fair fair = new Fair();
    public Messages messages = new Messages();
    public Limits limits = new Limits();
    public Web web = new Web();

    // ------------------------------------------------------------- сегменты

    public static class Segment {
        public String symbol = "?";
        /** Относительный вес (вероятность = weight / сумма весов). */
        public double weight = 1.0;
        /** Множитель выплаты. 0 = сектор проигрыша. */
        public double multiplier = 0.0;
        /** Необязательная подпись для чата/админки. */
        public String label = "";

        public Segment() {}

        public Segment(String symbol, double weight, double multiplier) {
            this.symbol = symbol;
            this.weight = weight;
            this.multiplier = multiplier;
        }

        public Segment(String symbol, double weight, double multiplier, String label) {
            this(symbol, weight, multiplier);
            this.label = label;
        }
    }

    /** Раскладка по умолчанию: RTP ≈ 95% без комиссии. */
    public static List<Segment> defaultSegments() {
        List<Segment> s = new ArrayList<>();
        s.add(new Segment("🍒", 30, 0, "пусто"));
        s.add(new Segment("🍋", 25, 0, "пусто"));
        s.add(new Segment("🍀", 18, 0, "пусто"));
        s.add(new Segment("🔔", 12, 1.5, "x1.5"));
        s.add(new Segment("⭐", 9, 2.0, "x2"));
        s.add(new Segment("💎", 4, 5.0, "x5"));
        s.add(new Segment("7️⃣", 2, 20.0, "джекпот x20"));
        return s;
    }

    // -------------------------------------------------------- сериализация

    public Map<String, Object> toMap() {
        Map<String, Object> root = Json.obj();

        root.put("general", Json.obj(
                "enabled", general.enabled,
                "houseId", general.houseId,
                "timezone", general.timezone,
                "displayName", general.displayName));

        root.put("commands", Json.obj(
                "payAlias", commands.payAlias,
                "bet", commands.bet,
                "betAlias", commands.betAlias,
                "allowTransfers", commands.allowTransfers,
                "transferFeePercent", commands.transferFeePercent));

        List<Object> segs = new ArrayList<>();
        for (Segment s : roulette.segments) {
            segs.add(Json.obj("symbol", s.symbol, "weight", s.weight,
                    "multiplier", s.multiplier, "label", s.label));
        }
        root.put("roulette", Json.obj(
                "mode", roulette.mode,
                "winChancePercent", roulette.winChancePercent,
                "multiplier", roulette.multiplier,
                "targetRtpPercent", roulette.targetRtpPercent,
                "rakePercent", roulette.rakePercent,
                "segments", segs));

        root.put("betting", Json.obj(
                "minBet", betting.minBet,
                "maxBet", betting.maxBet,
                "cooldownMs", betting.cooldownMs,
                "oneSpinAtATime", betting.oneSpinAtATime,
                "maxQueue", betting.maxQueue,
                "dailyLossLimit", betting.dailyLossLimit,
                "dailyWinLimit", betting.dailyWinLimit,
                "maxActiveBetsPerPlayer", betting.maxActiveBetsPerPlayer));

        root.put("economy", Json.obj(
                "mode", economy.mode,
                "startingBalance", economy.startingBalance,
                "incomeIntervalMinutes", economy.incomeIntervalMinutes,
                "incomeAmount", economy.incomeAmount,
                "houseAutoTopup", economy.houseAutoTopup,
                "houseMinBalance", economy.houseMinBalance,
                "houseTopupAmount", economy.houseTopupAmount,
                "mirror", Json.obj(
                        "enabled", economy.mirror.enabled,
                        "className", economy.mirror.className,
                        "balanceMethod", economy.mirror.balanceMethod,
                        "withdrawMethod", economy.mirror.withdrawMethod,
                        "depositMethod", economy.mirror.depositMethod)));

        root.put("animation", Json.obj(
                "enabled", animation.enabled,
                "frames", animation.frames,
                "frameMs", animation.frameMs,
                "window", animation.window,
                "marker", animation.marker,
                "symbols", animation.symbols,
                "showNick", animation.showNick,
                "privateOnly", animation.privateOnly,
                "broadcastFrames", animation.broadcastFrames));

        root.put("fair", Json.obj(
                "enabled", fair.enabled,
                "defaultClientSeed", fair.defaultClientSeed));

        Map<String, Object> msgs = Json.obj();
        for (java.lang.reflect.Field f : Messages.class.getFields()) {
            try {
                msgs.put(f.getName(), f.get(messages));
            } catch (IllegalAccessException ignored) {
            }
        }
        root.put("messages", msgs);

        root.put("limits", Json.obj(
                "bannedIds", new ArrayList<Object>(limits.bannedIds),
                "adminIds", new ArrayList<Object>(limits.adminIds)));

        root.put("web", Json.obj(
                "enabled", web.enabled,
                "bind", web.bind,
                "port", web.port,
                "token", web.token,
                "allowIps", new ArrayList<Object>(web.allowIps),
                "enableCors", web.enableCors,
                "logKeepDays", web.logKeepDays,
                "maxLogLines", web.maxLogLines,
                "maxSimSpins", web.maxSimSpins));

        return root;
    }

    @SuppressWarnings("unchecked")
    public void fromMap(Map<String, Object> root) {
        if (root == null) return;

        Json.Node g = Json.Node.of(root.get("general"));
        general.enabled = g.bool("enabled", general.enabled);
        general.houseId = nz(g.str("houseId", general.houseId));
        general.timezone = nz(g.str("timezone", general.timezone));
        general.displayName = nz(g.str("displayName", general.displayName));

        Json.Node c = Json.Node.of(root.get("commands"));
        commands.payAlias = c.bool("payAlias", commands.payAlias);
        commands.bet = cleanCmd(c.str("bet", commands.bet));
        commands.betAlias = cleanCmd(c.str("betAlias", commands.betAlias));
        commands.allowTransfers = c.bool("allowTransfers", commands.allowTransfers);
        commands.transferFeePercent = clamp(c.dbl("transferFeePercent", commands.transferFeePercent), 0, 90);

        Json.Node r = Json.Node.of(root.get("roulette"));
        String mode = r.str("mode", roulette.mode).toLowerCase();
        roulette.mode = (mode.equals("classic") || mode.equals("segments")) ? mode : "segments";
        roulette.winChancePercent = clamp(r.dbl("winChancePercent", roulette.winChancePercent), 0.01, 99.99);
        roulette.multiplier = clamp(r.dbl("multiplier", roulette.multiplier), 0, 10000);
        roulette.targetRtpPercent = clamp(r.dbl("targetRtpPercent", roulette.targetRtpPercent), 0, 200);
        roulette.rakePercent = clamp(r.dbl("rakePercent", roulette.rakePercent), 0, 90);
        if (r.raw() instanceof Map && ((Map<String, Object>) r.raw()).get("segments") instanceof List) {
            List<Segment> segs = new ArrayList<>();
            for (Json.Node sn : r.nodes("segments")) {
                Segment s = new Segment();
                s.symbol = nz(sn.str("symbol", "?"));
                s.weight = clamp(sn.dbl("weight", 1), 0, 1_000_000);
                s.multiplier = clamp(sn.dbl("multiplier", 0), 0, 100000);
                s.label = nz(sn.str("label", ""));
                if (s.weight > 0) segs.add(s);
            }
            if (!segs.isEmpty()) roulette.segments = segs;
        }

        Json.Node b = Json.Node.of(root.get("betting"));
        betting.minBet = Math.max(0, b.lng("minBet", betting.minBet));
        betting.maxBet = Math.max(betting.minBet, b.lng("maxBet", betting.maxBet));
        betting.cooldownMs = clampLong(b.lng("cooldownMs", betting.cooldownMs), 0, 3_600_000);
        betting.oneSpinAtATime = b.bool("oneSpinAtATime", betting.oneSpinAtATime);
        betting.maxQueue = (int) clampLong(b.lng("maxQueue", betting.maxQueue), 0, 100);
        betting.dailyLossLimit = Math.max(0, b.lng("dailyLossLimit", betting.dailyLossLimit));
        betting.dailyWinLimit = Math.max(0, b.lng("dailyWinLimit", betting.dailyWinLimit));
        betting.maxActiveBetsPerPlayer = (int) clampLong(b.lng("maxActiveBetsPerPlayer", betting.maxActiveBetsPerPlayer), 1, 10);

        Json.Node e = Json.Node.of(root.get("economy"));
        economy.mode = nz(e.str("mode", economy.mode));
        economy.startingBalance = Math.max(0, e.lng("startingBalance", economy.startingBalance));
        economy.incomeIntervalMinutes = Math.max(0, e.lng("incomeIntervalMinutes", economy.incomeIntervalMinutes));
        economy.incomeAmount = Math.max(0, e.lng("incomeAmount", economy.incomeAmount));
        economy.houseAutoTopup = e.bool("houseAutoTopup", economy.houseAutoTopup);
        economy.houseMinBalance = e.lng("houseMinBalance", economy.houseMinBalance);
        economy.houseTopupAmount = Math.max(0, e.lng("houseTopupAmount", economy.houseTopupAmount));
        Json.Node m = e.child("mirror");
        economy.mirror.enabled = m.bool("enabled", economy.mirror.enabled);
        economy.mirror.className = nz(m.str("className", economy.mirror.className));
        economy.mirror.balanceMethod = nz(m.str("balanceMethod", economy.mirror.balanceMethod));
        economy.mirror.withdrawMethod = nz(m.str("withdrawMethod", economy.mirror.withdrawMethod));
        economy.mirror.depositMethod = nz(m.str("depositMethod", economy.mirror.depositMethod));

        Json.Node a = Json.Node.of(root.get("animation"));
        animation.enabled = a.bool("enabled", animation.enabled);
        animation.frames = (int) clampLong(a.lng("frames", animation.frames), 1, 200);
        animation.frameMs = clampLong(a.lng("frameMs", animation.frameMs), 20, 5000);
        animation.window = (int) clampLong(a.lng("window", animation.window), 3, 25);
        animation.marker = nz(a.str("marker", animation.marker));
        animation.symbols = nz(a.str("symbols", animation.symbols));
        animation.showNick = a.bool("showNick", animation.showNick);
        animation.privateOnly = a.bool("privateOnly", animation.privateOnly);
        animation.broadcastFrames = a.bool("broadcastFrames", animation.broadcastFrames));

        Json.Node f = Json.Node.of(root.get("fair"));
        fair.enabled = f.bool("enabled", fair.enabled);
        fair.defaultClientSeed = nz(f.str("defaultClientSeed", fair.defaultClientSeed));

        Json.Node mm = Json.Node.of(root.get("messages"));
        for (java.lang.reflect.Field fld : Messages.class.getFields()) {
            if (mm.has(fld.getName())) {
                try {
                    fld.set(messages, mm.str(fld.getName(), (String) fld.get(messages)));
                } catch (IllegalAccessException ignored) {
                }
            }
        }

        Json.Node l = Json.Node.of(root.get("limits"));
        if (l.raw() instanceof Map && ((Map<String, Object>) l.raw()).get("bannedIds") instanceof List) {
            limits.bannedIds = strList(l.list("bannedIds"));
        }
        if (l.raw() instanceof Map && ((Map<String, Object>) l.raw()).get("adminIds") instanceof List) {
            limits.adminIds = strList(l.list("adminIds"));
        }

        Json.Node w = Json.Node.of(root.get("web"));
        web.enabled = w.bool("enabled", web.enabled);
        web.bind = nz(w.str("bind", web.bind));
        web.port = (int) clampLong(w.lng("port", web.port), 1, 65535);
        web.token = nz(w.str("token", web.token));
        if (w.raw() instanceof Map && ((Map<String, Object>) w.raw()).get("allowIps") instanceof List) {
            web.allowIps = strList(w.list("allowIps"));
        }
        web.enableCors = w.bool("enableCors", web.enableCors);
        web.logKeepDays = (int) clampLong(w.lng("logKeepDays", web.logKeepDays), 0, 3650);
        web.maxLogLines = (int) clampLong(w.lng("maxLogLines", web.maxLogLines), 10, 200_000);
        web.maxSimSpins = (int) clampLong(w.lng("maxSimSpins", web.maxSimSpins), 100, 5_000_000);
    }

    // ------------------------------------------------------------- утилиты

    private static List<String> strList(List<Object> raw) {
        List<String> out = new ArrayList<>();
        for (Object o : raw) {
            if (o == null) continue;
            String s = String.valueOf(o).trim();
            if (!s.isEmpty()) out.add(s);
        }
        return out;
    }

    private static String nz(String s) { return s == null ? "" : s; }

    private static String cleanCmd(String s) {
        s = nz(s).trim();
        while (s.startsWith("/")) s = s.substring(1);
        s = s.replaceAll("[^A-Za-z0-9_-]", "");
        return s.isEmpty() ? "rl" : s;
    }

    private static double clamp(double v, double min, double max) {
        if (Double.isNaN(v)) return min;
        return Math.max(min, Math.min(max, v));
    }

    private static long clampLong(long v, long min, long max) {
        return Math.max(min, Math.min(max, v));
    }

    /** Загрузить конфиг из JSON-строки (дефолты сохраняются для отсутствующих полей). */
    public static Config fromJson(String json) {
        Config cfg = new Config();
        if (json != null && !json.trim().isEmpty()) {
            cfg.fromMap(Json.parseObject(json));
        }
        cfg.sanitize();
        return cfg;
    }

    /** Дозаполнить/починить значения, чтобы движок не словил деление на ноль и т.п. */
    public void sanitize() {
        if (general.houseId == null || general.houseId.trim().isEmpty()) general.houseId = "HOUSE";
        if (general.timezone == null || general.timezone.trim().isEmpty()) general.timezone = "UTC";
        if (general.displayName == null || general.displayName.trim().isEmpty()) general.displayName = "Игрок";
        if (roulette.segments == null || roulette.segments.isEmpty()) roulette.segments = defaultSegments();
        if (animation.symbols == null || animation.symbols.isEmpty()) animation.symbols = "🍒🍋🔔⭐💎";
        if (animation.marker == null || animation.marker.isEmpty()) animation.marker = "▲";
        if (betting.maxBet < betting.minBet) betting.maxBet = Math.max(betting.minBet, 1);
        if (web.token == null || web.token.trim().isEmpty()) web.token = "changeme-roulette-token";
        if (commands.bet == null || commands.bet.isEmpty()) commands.bet = "rl";
    }

    /** Эффективные сектора рулетки с учётом режима (classic превращается в 2 сектора). */
    public List<Segment> effectiveSegments() {
        List<Segment> out = new ArrayList<>();
        if ("classic".equals(roulette.mode)) {
            double chance = clamp(roulette.winChancePercent, 0.01, 99.99) / 100.0;
            double mult = roulette.targetRtpPercent > 0
                    ? round2(roulette.targetRtpPercent / 100.0 / chance)
                    : round2(roulette.multiplier);
            out.add(new Segment("✅", chance * 1000.0, mult, "выигрыш x" + fmt(mult)));
            out.add(new Segment("❌", (1 - chance) * 1000.0, 0, "проигрыш"));
            return out;
        }
        double total = 0;
        for (Segment s : roulette.segments) total += Math.max(0, s.weight);
        if (total <= 0) return defaultSegments();
        for (Segment s : roulette.segments) {
            if (s.weight <= 0) continue;
            out.add(new Segment(s.symbol, s.weight / total * 1000.0, Math.max(0, s.multiplier), s.label));
        }
        return out;
    }

    /** Реальный RTP текущих настроек, %. */
    public double theoreticalRtpPercent() {
        double total = 0, ev = 0;
        for (Segment s : effectiveSegments()) {
            total += s.weight;
            ev += s.weight * s.multiplier;
        }
        if (total <= 0) return 0;
        double rtp = ev / total * 100.0;
        return round2(rtp * (1 - clamp(roulette.rakePercent, 0, 90) / 100.0));
    }

    /** Шанс любого выигрыша, %. */
    public double winChancePercent() {
        double total = 0, win = 0;
        for (Segment s : effectiveSegments()) {
            total += s.weight;
            if (s.multiplier > 0) win += s.weight;
        }
        return total <= 0 ? 0 : round2(win / total * 100.0);
    }

    public static double round2(double v) { return Math.round(v * 100.0) / 100.0; }

    public static String fmt(double v) {
        if (v == Math.rint(v)) return Long.toString((long) v);
        return String.valueOf(v);
    }
}
