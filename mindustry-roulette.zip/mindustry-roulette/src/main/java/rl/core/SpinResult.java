package rl.core;

/** Итог одного спина (посчитан детерминированно, до анимации). */
public class SpinResult {
    public long nonce;
    public String serverSeedHash = "";
    public String clientSeed = "";
    public String resultHash = "";
    public double roll;
    public int index;
    public Segment segment;
    public boolean win;

    public long bet;
    public double multiplier;
    public long gross;
    public long rake;
    public long payout;

    public long balanceBefore;
    public long balanceAfter;
    public long houseBefore;
    public long houseAfter;

    /** Сколько монет «ушло боту» при проигрыше (= ставка). */
    public long toHouse() { return win ? rake : bet; }
}
