// =====================================================================================
//  Сборщик MKUKIC Client
//
//    ./gradlew dist          — главная команда: проверки + тесты + jar в папку dist/
//    ./gradlew installMod    — dist + установка jar в папку модов игры (старые копии удаляются)
//    ./gradlew runTests      — только тесты
//    ./gradlew checkMod      — только проверка mod.hjson / структуры проекта
//
//  Флаги (-P...):
//    -PskipTests             — не гонять тесты перед dist
//    -PmindustryVersion=...  — версия Mindustry: v160.7 (по умолчанию), latest, be
//    -PmodsDir=ПУТЬ          — куда ставить мод командой installMod
//    -PandroidSdk=ПУТЬ       — Android SDK (если нет ANDROID_HOME)
//
//  Версия мода берётся из mod.hjson — больше нигде её править не нужно.
// =====================================================================================

import java.security.MessageDigest

plugins{
    java
}

// ------------------------------------------------------------------ метаданные из mod.hjson

val modHjsonText = file("mod.hjson").readText(Charsets.UTF_8)

fun hjsonString(key: String): String{
    val rx = Regex("(?m)^\\s*" + key + ":\\s*\"([^\"]*)\"")
    return rx.find(modHjsonText)?.groupValues?.get(1)
        ?: throw GradleException("mod.hjson: не найдено строковое поле '$key'")
}

val modName = hjsonString("name")
val modVersion = hjsonString("version")
val modMain = hjsonString("main")
val artifactName = "MKUKICClient"

version = modVersion

// ------------------------------------------------------------------ параметры

val mindustryVersion = (findProperty("mindustryVersion") as String?) ?: "v160.7"
val skipTests = project.hasProperty("skipTests")
val isWindows = System.getProperty("os.name").lowercase().contains("windows")
val isMac = System.getProperty("os.name").lowercase().contains("mac")

sourceSets.main{
    java.setSrcDirs(listOf("src"))
}

// ------------------------------------------------------------------ зависимости (Mindustry)

repositories{
    mavenCentral()

    // Качает dependencies.jar прямо из релизов Mindustry на GitHub.
    ivy{
        url = uri("https://github.com/")
        patternLayout{
            val pattern = when(mindustryVersion){
                "latest" -> "/[organisation]/[module]/releases/[revision]/download/dependencies.jar"
                "be" -> "/[organisation]/[module]/releases/download/master/[revision].jar"
                else -> "/[organisation]/[module]/releases/download/[revision]/dependencies.jar"
            }
            val path = pattern.substring(0, pattern.lastIndexOf('/'))

            artifact("$path/[classifier].jar")
            artifact(pattern.replaceFirst(Regex("""\.jar$"""), "(-[classifier]).jar"))
        }
        metadataSources{ artifact() }

        content{
            if(mindustryVersion == "be"){
                includeVersion("Anuken", "MindustryBuilds", "latest")
            }else{
                includeVersion("Anuken", "Mindustry", mindustryVersion)
            }
        }
    }
}

java{
    // Байткод 17 — его понимает и Java 17, и Java 21/25, которые требует v8.
    sourceCompatibility = JavaVersion.VERSION_17
    targetCompatibility = JavaVersion.VERSION_17
}

dependencies{
    compileOnly(if(mindustryVersion == "be") "Anuken:MindustryBuilds:latest" else "Anuken:Mindustry:$mindustryVersion")
}

tasks.withType<JavaCompile>().configureEach{
    // Исходники на русском: без этого на Windows (cp1251) строки в jar превращаются в мусор.
    options.encoding = "UTF-8"
}

// ------------------------------------------------------------------ проверка проекта

val checkMod = tasks.register("checkMod"){
    group = "verification"
    description = "Проверяет mod.hjson, главный класс, иконку и список исходников."

    doLast{
        val problems = ArrayList<String>()

        if(!Regex("""\d+\.\d+(\.\d+)?""").matches(modVersion)){
            problems += "mod.hjson: version '$modVersion' не похожа на 1.2.3"
        }
        val mainFile = file("src/" + modMain.replace('.', '/') + ".java")
        if(!mainFile.exists()){
            problems += "mod.hjson: main '$modMain' — нет файла ${mainFile.relativeTo(projectDir)}"
        }
        if(!Regex("(?m)^\\s*minGameVersion:").containsMatchIn(modHjsonText)){
            problems += "mod.hjson: нет поля minGameVersion"
        }
        if(!file("assets/icon.png").exists()){
            problems += "нет assets/icon.png (иконка мода)"
        }
        if(!Regex("(?m)^\\s*java:\\s*true").containsMatchIn(modHjsonText)){
            problems += "mod.hjson: должно быть java: true"
        }

        // sources.txt — справочный список; предупреждаем, если разошёлся с src/
        val listed = file("sources.txt").takeIf{ it.exists() }?.readLines()?.map{ it.trim() }?.filter{ it.isNotEmpty() }?.toSet()
        if(listed != null){
            val actual = fileTree("src").matching{ include("**/*.java") }.files
                .map{ it.relativeTo(projectDir).invariantSeparatorsPath }.toSet()
            val missing = actual - listed
            val stale = listed - actual
            if(missing.isNotEmpty() || stale.isNotEmpty()){
                logger.warn("sources.txt разошёлся с src/ (на сборку не влияет): нет в списке=${missing.size}, лишних=${stale.size}")
            }
        }

        if(problems.isNotEmpty()){
            throw GradleException("Проект не готов к сборке:\n - " + problems.joinToString("\n - "))
        }
        logger.lifecycle("OK: $modName v$modVersion (main=$modMain, Mindustry $mindustryVersion)")
    }
}

tasks.compileJava{ dependsOn(checkMod) }

// ------------------------------------------------------------------ тесты (папка tests/)

val testSet = sourceSets.create("tests"){
    java.setSrcDirs(listOf("tests"))
    compileClasspath += sourceSets.main.get().output + sourceSets.main.get().compileClasspath
    runtimeClasspath += sourceSets.main.get().output + sourceSets.main.get().compileClasspath
}

tasks.named<JavaCompile>("compileTestsJava"){
    options.encoding = "UTF-8"
}

val runTests = tasks.register("runTests"){
    group = "verification"
    description = "Запускает SmokeTest, FeatureTest, SceneTest, TimeTest, TestSer."
}

listOf("SmokeTest", "FeatureTest", "SceneTest", "TimeTest", "TestSer").forEach{ testName ->
    val t = tasks.register<JavaExec>("run$testName"){
        group = "verification"
        description = "Запускает $testName."
        dependsOn("testsClasses")
        mainClass.set(testName)
        classpath = testSet.runtimeClasspath
        // SmokeTest сканирует папку со скомпилированными классами мода
        if(testName == "SmokeTest"){
            args(sourceSets.main.get().output.classesDirs.files.first().absolutePath)
        }
        jvmArgs("-Djava.awt.headless=true", "-Dfile.encoding=UTF-8")
        val work = layout.buildDirectory.dir("test-work").get().asFile
        workingDir = work
        doFirst{ work.mkdirs() }
    }
    runTests.configure{ dependsOn(t) }
}

// ------------------------------------------------------------------ desktop jar

tasks.jar{
    archiveFileName.set("${artifactName}Desktop.jar")
    duplicatesStrategy = DuplicatesStrategy.EXCLUDE
    isPreserveFileTimestamps = false
    isReproducibleFileOrder = true

    from(configurations.runtimeClasspath.map{ files ->
        files.map{ if(it.isDirectory) it else zipTree(it) }
    })

    from(projectDir){
        include("mod.hjson")
    }

    // icon.png и прочие ресурсы мода — в корень jar
    from("assets/"){
        include("**")
    }

    manifest{
        attributes(
            "Implementation-Title" to modName,
            "Implementation-Version" to modVersion
        )
    }
}

// ------------------------------------------------------------------ Android (d8)

fun versionKey(name: String): Long{
    val p = name.split(".").map{ part -> part.takeWhile{ c -> c.isDigit() }.toLongOrNull() ?: 0L }
    return p.getOrElse(0){ 0L } * 1_000_000L + p.getOrElse(1){ 0L } * 1_000L + p.getOrElse(2){ 0L }
}

val sdkRoot: File? = ((findProperty("androidSdk") as String?) ?: System.getenv("ANDROID_HOME") ?: System.getenv("ANDROID_SDK_ROOT"))
    ?.let{ File(it) }?.takeIf{ it.exists() }

// android.jar: берём платформу с наибольшим НОМЕРОМ (строковая сортировка ставила android-9 выше android-34)
val androidJarFile: File? = sdkRoot?.let{ sdk ->
    File(sdk, "platforms").listFiles()
        ?.filter{ File(it, "android.jar").exists() }
        ?.maxByOrNull{ Regex("\\d+").find(it.name)?.value?.toIntOrNull() ?: 0 }
        ?.let{ File(it, "android.jar") }
}

// d8: сначала build-tools/<самая новая>/d8, потом то, что есть в PATH
val d8Exe: String? = run{
    val exe = if(isWindows) "d8.bat" else "d8"
    val fromSdk = sdkRoot?.let{ sdk ->
        File(sdk, "build-tools").listFiles()
            ?.filter{ File(it, exe).exists() }
            ?.maxByOrNull{ versionKey(it.name) }
            ?.let{ File(it, exe).absolutePath }
    }
    fromSdk ?: System.getenv("PATH")?.split(File.pathSeparator)?.map{ File(it, exe) }?.firstOrNull{ it.exists() }?.absolutePath
}

val androidAvailable = d8Exe != null && androidJarFile != null

val jarAndroid = tasks.register("jarAndroid"){
    group = "build"
    description = "Конвертирует desktop jar в dex для Android (нужен Android SDK + d8)."
    dependsOn(tasks.jar)

    doLast{
        val d8 = d8Exe ?: throw GradleException("Не найден d8. Установите Android SDK Build-Tools и задайте ANDROID_HOME (или -PandroidSdk=ПУТЬ).")
        val androidJar = androidJarFile ?: throw GradleException("Не найден android.jar. Установите любую Android Platform (SDK Platforms) и задайте ANDROID_HOME.")

        val libs = layout.buildDirectory.dir("libs").get().asFile
        val desktop = File(libs, "${artifactName}Desktop.jar")
        val out = File(libs, "${artifactName}Android.jar")
        out.delete()

        val classpath = configurations.compileClasspath.get().files + configurations.runtimeClasspath.get().files + androidJar

        val command = ArrayList<String>()
        command.add(d8)
        classpath.forEach{ command.add("--classpath"); command.add(it.absolutePath) }
        command.addAll(listOf("--min-api", "21", "--output", out.absolutePath, desktop.absolutePath))

        val exit = ProcessBuilder(command).directory(libs).inheritIO().start().waitFor()
        if(exit != 0) throw GradleException("d8 завершился с кодом $exit")
    }
}

// Универсальный jar (desktop + android) — именно его кладут в релиз.
val deploy = tasks.register<Jar>("deploy"){
    group = "build"
    description = "Универсальный jar (ПК + Android)."
    dependsOn(jarAndroid, tasks.jar)
    archiveFileName.set("$artifactName.jar")
    duplicatesStrategy = DuplicatesStrategy.EXCLUDE
    isPreserveFileTimestamps = false
    isReproducibleFileOrder = true

    val libs = layout.buildDirectory.dir("libs")
    from(provider{
        listOf(
            zipTree(libs.get().file("${artifactName}Desktop.jar")),
            zipTree(libs.get().file("${artifactName}Android.jar"))
        )
    })
}

// ------------------------------------------------------------------ dist: итоговый jar

val finalJar: TaskProvider<Jar> = if(androidAvailable) deploy else tasks.jar

val dist = tasks.register("dist"){
    group = "build"
    description = "Проверки + тесты + итоговый jar в dist/$artifactName.jar."
    dependsOn(checkMod, finalJar)
    if(!skipTests) dependsOn(runTests)

    // тесты должны отработать раньше, чем мы объявим сборку готовой
    if(!skipTests) finalJar.configure{ mustRunAfter(runTests) }

    doLast{
        val src = finalJar.get().archiveFile.get().asFile
        val dir = file("dist")
        dir.mkdirs()
        val target = File(dir, "$artifactName.jar")
        src.copyTo(target, overwrite = true)

        val sha = MessageDigest.getInstance("SHA-256").digest(target.readBytes()).joinToString(""){ "%02x".format(it) }
        File(dir, "$artifactName.jar.sha256").writeText("$sha  $artifactName.jar\n")

        logger.lifecycle("")
        logger.lifecycle("==========================================================")
        logger.lifecycle(" Готово: ${target.relativeTo(projectDir)}  (${target.length() / 1024} КБ)")
        logger.lifecycle(" Мод: $modName v$modVersion, Mindustry $mindustryVersion")
        logger.lifecycle(" Платформы: " + if(androidAvailable) "ПК + сервер + Android" else "ПК + сервер (БЕЗ Android — не найден Android SDK/d8)")
        if(skipTests) logger.lifecycle(" Тесты: пропущены (-PskipTests)")
        logger.lifecycle(" SHA-256: $sha")
        logger.lifecycle("==========================================================")
    }
}

// ------------------------------------------------------------------ установка в игру

fun defaultModsDir(): File{
    (findProperty("modsDir") as String?)?.let{ return File(it) }
    System.getenv("MINDUSTRY_MODS")?.let{ return File(it) }
    val home = System.getProperty("user.home")
    return when{
        isWindows -> File(System.getenv("APPDATA") ?: "$home/AppData/Roaming", "Mindustry/mods")
        isMac -> File(home, "Library/Application Support/Mindustry/mods")
        else -> File(System.getenv("XDG_DATA_HOME") ?: "$home/.local/share", "Mindustry/mods")
    }
}

tasks.register("installMod"){
    group = "build"
    description = "Собирает dist и кладёт jar в папку модов (старые копии мода удаляются)."
    dependsOn(dist)

    doLast{
        val mods = defaultModsDir()
        mods.mkdirs()

        // Две копии мода с одним именем дают в игре экран «Ошибки были вызваны загружаемым содержимым».
        val old = Regex("(?i)^(" + artifactName + "|" + Regex.escape(modName) + ").*\\.jar$")
        mods.listFiles()?.filter{ it.isFile && old.matches(it.name) }?.forEach{
            logger.lifecycle("Удаляю старую копию: ${it.name}")
            it.delete()
        }
        mods.listFiles()?.filter{ it.isDirectory && it.name.equals(modName, ignoreCase = true) }?.forEach{
            logger.warn("ВНИМАНИЕ: в папке модов лежит ПАПКА ${it.name} — удалите её вручную, иначе будет конфликт имён мода.")
        }

        val target = File(mods, "$artifactName.jar")
        file("dist/$artifactName.jar").copyTo(target, overwrite = true)
        logger.lifecycle("Установлено: ${target.absolutePath}")
    }
}

// Удобно знать, чем собираем
tasks.register("buildInfo"){
    group = "help"
    description = "Показывает, что найдено: версия мода, Mindustry, Android SDK, папка модов."
    doLast{
        println("Мод:            $modName v$modVersion  (main=$modMain)")
        println("Mindustry:      $mindustryVersion")
        println("JDK сборки:     " + System.getProperty("java.version"))
        println("Android SDK:    " + (sdkRoot?.absolutePath ?: "не найден"))
        println("  android.jar:  " + (androidJarFile?.absolutePath ?: "не найден"))
        println("  d8:           " + (d8Exe ?: "не найден"))
        println("Android-сборка: " + if(androidAvailable) "будет" else "НЕ будет (нужны SDK Platform + Build-Tools)")
        println("Папка модов:    " + defaultModsDir().absolutePath)
    }
}
