package oneunit;

import arc.*;
import arc.files.*;
import arc.math.*;
import arc.struct.*;
import arc.util.*;
import mindustry.*;
import mindustry.core.*;
import mindustry.game.*;
import mindustry.game.EventType.*;
import mindustry.gen.*;
import mindustry.mod.*;
import mindustry.net.*;
import mindustry.world.*;

/**
 * One Unit Arena - PvP-режим "один юнит, одна жизнь".
 * Точка входа плагина: конфиги, события, команды чата и консоли.
 */
public class OneUnitPlugin extends Plugin{

    @Override
    public void init(){
        Fi folder = Vars.mods.getConfigFolder(this);
        ConfigIO.load(folder);

        new Ui();
        new Match();
        Lock.installActionFilter();
        events();

        Log.info("[OneUnitArena] v@ загружен. Конфиги: @", OneUnit.VERSION, folder.path());
        Log.info("[OneUnitArena] Юнитов в каталоге: @, режим по умолчанию: @",
            OneUnit.catalog.entries.count(UnitEntry::valid), OneUnit.settings.defaultMode);
    }

    private void events(){
        Events.on(PlayerJoin.class, e -> guard(() -> Match.inst.onJoin(e.player)));
        Events.on(PlayerLeave.class, e -> guard(() -> {
            Ui.inst.forget(e.player);
            Match.inst.onLeave(e.player);
        }));

        Events.on(UnitDestroyEvent.class, e -> guard(() -> Match.inst.onDeath(e.unit)));
        Events.on(UnitDamageEvent.class, e -> guard(() -> Match.inst.onDamage(e.unit, e.bullet)));
        Events.on(BulletCreateEvent.class, e -> guard(() -> Match.inst.onBullet(e.bullet)));
        Events.on(UnitChangeEvent.class, e -> guard(() -> Lock.onUnitChange(e.player, e.unit)));

        Events.on(BuildSelectEvent.class, e -> guard(() -> Lock.onBuildSelect(e)));
        Events.on(ConfigEvent.class, e -> guard(() -> Lock.onConfig(e)));
        Events.on(PickupEvent.class, e -> guard(() -> Lock.onPickup(e)));

        Events.on(ResetEvent.class, e -> guard(() -> Match.inst.onWorldReset()));

        Events.run(Trigger.update, () -> guard(() -> Match.inst.update()));
    }

    /** Плагин не должен ронять серверный цикл из-за одной ошибки. */
    private void guard(Runnable run){
        try{
            run.run();
        }catch(Throwable t){
            Log.err("[OneUnitArena] Ошибка в обработчике", t);
        }
    }

    // ------------------------------------------------------------------ команды

    @Override
    public void registerClientCommands(CommandHandler handler){
        handler.<Player>register("lobby", "Меню лобби: команды, готовность, старт", (args, p) -> Ui.inst.lobby(p));

        handler.<Player>register("join", "[команда]", "Войти в лобби (за команду или автоматически)",
            (args, p) -> Match.inst.join(p, args.length > 0 ? args[0] : null));

        handler.<Player>register("leave", "Выйти из лобби", (args, p) -> Match.inst.leave(p));

        handler.<Player>register("ready", "Отметить готовность", (args, p) -> Match.inst.toggleReady(p));

        handler.<Player>register("pick", "[id]", "Меню выбора юнита (драфт и респавн)", (args, p) -> {
            if(args.length > 0) Match.inst.pick(p, args[0]);
            else Ui.inst.openPick(p);
        });

        handler.<Player>register("roster", "Состав команд: кто на ком играет", (args, p) -> Ui.inst.roster(p));
        handler.<Player>register("score", "Таблица очков", (args, p) -> Ui.inst.score(p));
        handler.<Player>register("uhelp", "Помощь по режиму", (args, p) -> Ui.inst.help(p));

        handler.<Player>register("mode", "<classic|respawn>", "Переключить режим матча (админ)", (args, p) -> {
            if(!p.admin){
                Txt.send(p, "notAdmin");
                return;
            }
            setMode(args[0], p);
        });

        handler.<Player>register("start", "Запустить драфт и матч (админ)", (args, p) -> {
            if(!p.admin){
                Txt.send(p, "notAdmin");
                return;
            }
            Match.inst.startDraft(p);
        });

        handler.<Player>register("stop", "Остановить матч (админ)", (args, p) -> {
            if(!p.admin){
                Txt.send(p, "notAdmin");
                return;
            }
            Match.inst.stop(p);
        });

        handler.<Player>register("arena", "<подкоманда> [аргументы]", "Админ-команды: /arena help",
            (args, p) -> {
                if(!p.admin){
                    Txt.send(p, "notAdmin");
                    return;
                }
                arena(args, p);
            });
    }

    @Override
    public void registerServerCommands(CommandHandler handler){
        handler.register("arena", "<подкоманда> [аргументы]", "One Unit Arena: arena help", this::arena);
    }

    private void setMode(String arg, Player p){
        if(arg.equalsIgnoreCase("classic") || arg.equalsIgnoreCase("1")){
            Match.inst.setMode(false);
        }else if(arg.equalsIgnoreCase("respawn") || arg.equalsIgnoreCase("wt") || arg.equalsIgnoreCase("2")){
            Match.inst.setMode(true);
        }else{
            Txt.send(p, "usage", "/mode classic|respawn");
        }
    }

    // ------------------------------------------------------------------ /arena

    private void arena(String[] args, Player p){
        String sub = args.length == 0 ? "help" : args[0].toLowerCase();
        Match match = Match.inst;

        switch(sub){
            case "help" -> {
                String help = """
                    [accent]/arena[] - админ-команды One Unit Arena
                    [green]status[] - состояние матча
                    [green]reload[] - перечитать settings/units/messages
                    [green]start[] / [green]stop[] - запустить / остановить матч
                    [green]mode <classic|respawn>[] - режим
                    [green]addspawn <команда> [x y][] - добавить точку спавна (без координат - там, где стоишь)
                    [green]setspawn <команда> [x y][] - заменить точки спавна команды
                    [green]delspawn <команда>[] - удалить точки спавна команды
                    [green]spawns[] - список точек текущей карты
                    [green]zone add <имя> [x y] [радиус][] - точка захвата
                    [green]zone del <имя>[] / [green]zones[] - управление точками захвата
                    [green]points <ник> <очки>[] - выдать очки
                    [green]map add <имя>[] / [green]map del <имя>[] / [green]maps[] - список арен
                    [green]save[] - сохранить settings.json
                    """;
                if(p != null) Txt.raw(p, help);
                else Log.info(Strings.stripColors(help));
            }
            case "status" -> {
                String s = "[accent]One Unit Arena[] v" + OneUnit.VERSION +
                    "\nФаза: [gold]" + match.phaseName() + "[]  Режим: [gold]" + Txt.f(match.respawnMode ? "modeRespawn" : "modeClassic") +
                    "\nКарта: [gold]" + (match.mapName.isEmpty() ? "-" : match.mapName) + "[]  Раунд: " + match.round +
                    "\nИгроков: [gold]" + match.roster.size + "[]  Время: " + Txt.time(match.timeLeft()) +
                    "\nКаталог: [gold]" + OneUnit.catalog.entries.count(UnitEntry::valid) + "[] юнитов, тиры 1.." + OneUnit.catalog.maxTier;
                for(Team t : match.teams){
                    s += "\n" + Txt.team(t) + ": " + match.of(t).size + " игр., в бою " + match.fightingCount(t);
                }
                if(p != null) Txt.raw(p, s);
                else Log.info(Strings.stripColors(s));
            }
            case "reload" -> {
                ConfigIO.load(ConfigIO.dir);
                match.loadTeams();
                Txt.send(p, "reloaded", OneUnit.catalog.entries.count(UnitEntry::valid));
                if(p == null) Log.info("[OneUnitArena] Конфиги перезагружены.");
            }
            case "start" -> match.startDraft(p);
            case "stop" -> match.stop(p);
            case "mode" -> {
                if(args.length < 2){
                    usage(p, "/arena mode classic|respawn");
                    return;
                }
                setMode(args[1], p);
            }
            case "save" -> {
                ConfigIO.saveSettings();
                Txt.raw(p, "[green]settings.json сохранён.");
                if(p == null) Log.info("[OneUnitArena] settings.json сохранён.");
            }
            case "addspawn", "setspawn" -> {
                if(args.length < 2){
                    usage(p, "/arena " + sub + " <команда> [x y]");
                    return;
                }
                Team team = findTeam(args[1]);
                if(team == null){
                    Txt.send(p, "badTeam", match.teams.toString(", ", t -> t.name));
                    return;
                }
                int[] pos = coords(args, 2, p);
                if(pos == null) return;
                String map = currentMapName();
                if(map == null){
                    Txt.raw(p, "[scarlet]Карта не загружена.");
                    return;
                }
                Settings.MapConfig cfg = Spawns.configOrCreate(map);
                Seq<String> list = cfg.spawns.get(team.name, Seq::new);
                if(sub.equals("setspawn")) list.clear();
                list.add(pos[0] + "," + pos[1]);
                ConfigIO.saveSettings();
                Txt.send(p, "spawnSaved", Txt.team(team), pos[0], pos[1]);
            }
            case "delspawn" -> {
                if(args.length < 2){
                    usage(p, "/arena delspawn <команда>");
                    return;
                }
                Team team = findTeam(args[1]);
                if(team == null){
                    Txt.send(p, "badTeam", match.teams.toString(", ", t -> t.name));
                    return;
                }
                Settings.MapConfig cfg = Spawns.configFor(currentMapName());
                if(cfg != null) cfg.spawns.remove(team.name);
                ConfigIO.saveSettings();
                Txt.send(p, "spawnRemoved", Txt.team(team));
            }
            case "spawns" -> {
                Settings.MapConfig cfg = Spawns.configFor(currentMapName());
                StringBuilder sb = new StringBuilder("[accent]Точки спавна:[] " + currentMapName());
                if(cfg == null || cfg.spawns.isEmpty()){
                    sb.append("\n[gray]не заданы - используются ядра или геометрия карты[]");
                }else{
                    for(ObjectMap.Entry<String, Seq<String>> e : cfg.spawns){
                        sb.append("\n[gold]").append(e.key).append("[]: ").append(e.value.toString(", "));
                    }
                }
                Txt.raw(p, sb.toString());
                if(p == null) Log.info(Strings.stripColors(sb.toString()));
            }
            case "zone" -> {
                if(args.length < 3){
                    usage(p, "/arena zone add <имя> [x y] [радиус] | /arena zone del <имя>");
                    return;
                }
                String map = currentMapName();
                if(map == null){
                    Txt.raw(p, "[scarlet]Карта не загружена.");
                    return;
                }
                Settings.MapConfig cfg = Spawns.configOrCreate(map);
                String action = args[1].toLowerCase();
                String name = args[2];
                if(action.equals("del")){
                    cfg.zones.removeAll(z -> z.name.equalsIgnoreCase(name));
                    ConfigIO.saveSettings();
                    Txt.send(p, "zoneRemoved", name);
                }else if(action.equals("add")){
                    int[] pos = coords(args, 3, p);
                    if(pos == null) return;
                    float radius = 6f;
                    if(args.length > 5){
                        try{
                            radius = Float.parseFloat(args[5]);
                        }catch(NumberFormatException ex){
                            Txt.send(p, "badNumber", args[5]);
                            return;
                        }
                    }
                    Settings.Zone z = new Settings.Zone();
                    z.name = name;
                    z.x = pos[0];
                    z.y = pos[1];
                    z.radius = radius;
                    cfg.zones.removeAll(o -> o.name.equalsIgnoreCase(name));
                    cfg.zones.add(z);
                    ConfigIO.saveSettings();
                    Txt.send(p, "zoneSaved", name, pos[0], pos[1], radius);
                }else{
                    usage(p, "/arena zone add|del <имя>");
                }
            }
            case "zones" -> {
                Settings.MapConfig cfg = Spawns.configFor(currentMapName());
                StringBuilder sb = new StringBuilder("[accent]Точки захвата:[] " + currentMapName());
                if(cfg == null || cfg.zones.isEmpty()) sb.append("\n[gray]нет[]");
                for(Settings.Zone z : cfg == null ? new Seq<Settings.Zone>() : cfg.zones){
                    sb.append("\n[gold]").append(z.name).append("[]: ").append(z.x).append(",").append(z.y).append(" r=").append(z.radius);
                }
                Txt.raw(p, sb.toString());
                if(p == null) Log.info(Strings.stripColors(sb.toString()));
            }
            case "points" -> {
                if(args.length < 3){
                    usage(p, "/arena points <ник> <очки>");
                    return;
                }
                Player target = Groups.player.find(o -> Strings.stripColors(o.name).toLowerCase().contains(args[1].toLowerCase()));
                if(target == null){
                    Txt.send(p, "playerNotFound", args[1]);
                    return;
                }
                float amount;
                try{
                    amount = Float.parseFloat(args[2]);
                }catch(NumberFormatException ex){
                    Txt.send(p, "badNumber", args[2]);
                    return;
                }
                match.addPoints(target, amount);
            }
            case "map" -> {
                if(args.length < 3){
                    usage(p, "/arena map add|del <имя>");
                    return;
                }
                StringBuilder nb = new StringBuilder();
                for(int i = 2; i < args.length; i++){
                    if(i > 2) nb.append(" ");
                    nb.append(args[i]);
                }
                String name = nb.toString();
                if(args[1].equalsIgnoreCase("add")){
                    if(!OneUnit.settings.arenaMaps.contains(name)) OneUnit.settings.arenaMaps.add(name);
                }else{
                    OneUnit.settings.arenaMaps.remove(name);
                }
                ConfigIO.saveSettings();
                Txt.raw(p, "[green]Список арен:[] " + OneUnit.settings.arenaMaps.toString(", "));
            }
            case "maps" -> {
                StringBuilder sb = new StringBuilder("[accent]Арены в settings.json:[] " + OneUnit.settings.arenaMaps.toString(", "));
                sb.append("\n[accent]Карты на сервере:[]");
                for(mindustry.maps.Map mp : Vars.maps.all()){
                    sb.append("\n[gray]- []").append(mp.plainName());
                }
                Txt.raw(p, sb.toString());
                if(p == null) Log.info(Strings.stripColors(sb.toString()));
            }
            default -> usage(p, "/arena help");
        }
    }

    private void usage(Player p, String text){
        Txt.send(p, "usage", text);
        if(p == null) Log.info(Strings.stripColors(text));
    }

    private Team findTeam(String name){
        for(Team t : Team.all){
            if(t.name.equalsIgnoreCase(name)) return t;
        }
        return null;
    }

    private String currentMapName(){
        return Vars.state.map == null ? null : Vars.state.map.plainName();
    }

    /** Координаты из аргументов или позиция игрока. */
    private int[] coords(String[] args, int index, Player p){
        if(args.length >= index + 2){
            try{
                return new int[]{Integer.parseInt(args[index]), Integer.parseInt(args[index + 1])};
            }catch(NumberFormatException ex){
                Txt.send(p, "badNumber", args[index] + " " + args[index + 1]);
                return null;
            }
        }
        if(p != null && p.unit() != null){
            return new int[]{World.toTile(p.unit().x), World.toTile(p.unit().y)};
        }
        usage(p, "нужны координаты x y");
        return null;
    }
}
