package rl.core;

/** Куда слать сообщения. В бою — чат Mindustry, в тестах — список строк. */
public interface Messenger {
    void toPlayer(String id, String message);

    void broadcast(String message);
}
