package rl.core;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Крошечный JSON-парсер/сериализатор без внешних зависимостей.
 * Нужен, чтобы jar плагина не тащил за собой gson/jackson (Mindustry грузит jar'ы
 * своим classloader'ом и лишний shade = лишний повод для конфликтов).
 *
 * Поддерживает: object, array, string (с \uXXXX и экранированием), number, true/false/null.
 */
public final class Json {

    private Json() {}

    // ------------------------------------------------------------------ parse

    public static Object parse(String text) {
        if (text == null) return null;
        Parser p = new Parser(text);
        p.ws();
        Object v = p.value();
        p.ws();
        return v;
    }

    @SuppressWarnings("unchecked")
    public static Map<String, Object> parseObject(String text) {
        Object v = parse(text);
        return v instanceof Map ? (Map<String, Object>) v : new LinkedHashMap<>();
    }

    // ------------------------------------------------------------------- node

    /** Обёртка над Object-деревом с удобными геттерами и дефолтами. */
    public static final class Node {
        private final Object raw;

        public Node(Object raw) { this.raw = raw; }

        public static Node of(Object o) { return new Node(o); }

        public Object raw() { return raw; }

        public boolean isNull() { return raw == null; }

        @SuppressWarnings("unchecked")
        public Map<String, Object> map() {
            return raw instanceof Map ? (Map<String, Object>) raw : new LinkedHashMap<>();
        }

        public Node child(String key) { return new Node(map().get(key)); }

        public boolean has(String key) { return map().containsKey(key); }

        public String str(String key, String def) {
            Object v = map().get(key);
            if (v == null) return def;
            return v instanceof String ? (String) v : String.valueOf(v);
        }

        public boolean bool(String key, boolean def) {
            Object v = map().get(key);
            if (v == null) return def;
            if (v instanceof Boolean) return (Boolean) v;
            if (v instanceof Number) return ((Number) v).doubleValue() != 0;
            String s = String.valueOf(v).trim().toLowerCase();
            if (s.equals("true") || s.equals("1") || s.equals("yes") || s.equals("on")) return true;
            if (s.equals("false") || s.equals("0") || s.equals("no") || s.equals("off")) return false;
            return def;
        }

        public long lng(String key, long def) {
            Object v = map().get(key);
            if (v == null) return def;
            if (v instanceof Number) return ((Number) v).longValue();
            try {
                return (long) Double.parseDouble(String.valueOf(v).trim());
            } catch (Exception e) {
                return def;
            }
        }

        public int integer(String key, int def) { return (int) lng(key, def); }

        public double dbl(String key, double def) {
            Object v = map().get(key);
            if (v == null) return def;
            if (v instanceof Number) return ((Number) v).doubleValue();
            try {
                return Double.parseDouble(String.valueOf(v).trim());
            } catch (Exception e) {
                return def;
            }
        }

        @SuppressWarnings("unchecked")
        public List<Object> list(String key) {
            Object v = map().get(key);
            return v instanceof List ? (List<Object>) v : new ArrayList<>();
        }

        public List<Node> nodes(String key) {
            List<Node> out = new ArrayList<>();
            for (Object o : list(key)) out.add(new Node(o));
            return out;
        }
    }

    // ------------------------------------------------------------------ write

    public static String write(Object value) {
        StringBuilder sb = new StringBuilder();
        writeValue(sb, value, 0, true);
        return sb.toString();
    }

    public static String writeCompact(Object value) {
        StringBuilder sb = new StringBuilder();
        writeValue(sb, value, 0, false);
        return sb.toString();
    }

    @SuppressWarnings("unchecked")
    private static void writeValue(StringBuilder sb, Object v, int depth, boolean pretty) {
        if (v == null) { sb.append("null"); return; }
        if (v instanceof String) { writeString(sb, (String) v); return; }
        if (v instanceof Boolean) { sb.append(v.toString()); return; }
        if (v instanceof Number) {
            double d = ((Number) v).doubleValue();
            if (Double.isNaN(d) || Double.isInfinite(d)) { sb.append("null"); return; }
            if (v instanceof Float || v instanceof Double) {
                if (d == Math.floor(d) && Math.abs(d) < 1e15) sb.append(Long.toString((long) d));
                else sb.append(String.valueOf(d));
            } else {
                sb.append(v.toString());
            }
            return;
        }
        if (v instanceof Map) {
            Map<String, Object> m = (Map<String, Object>) v;
            if (m.isEmpty()) { sb.append("{}"); return; }
            sb.append('{');
            boolean first = true;
            for (Map.Entry<String, Object> e : m.entrySet()) {
                if (!first) sb.append(',');
                first = false;
                nl(sb, pretty, depth + 1);
                writeString(sb, e.getKey());
                sb.append(':');
                if (pretty) sb.append(' ');
                writeValue(sb, e.getValue(), depth + 1, pretty);
            }
            nl(sb, pretty, depth);
            sb.append('}');
            return;
        }
        if (v instanceof Iterable) {
            sb.append('[');
            boolean first = true;
            for (Object o : (Iterable<Object>) v) {
                if (!first) sb.append(',');
                first = false;
                nl(sb, pretty, depth + 1);
                writeValue(sb, o, depth + 1, pretty);
            }
            if (!first) nl(sb, pretty, depth);
            sb.append(']');
            return;
        }
        if (v.getClass().isArray()) {
            List<Object> l = new ArrayList<>();
            int len = java.lang.reflect.Array.getLength(v);
            for (int i = 0; i < len; i++) l.add(java.lang.reflect.Array.get(v, i));
            writeValue(sb, l, depth, pretty);
            return;
        }
        writeString(sb, String.valueOf(v));
    }

    private static void nl(StringBuilder sb, boolean pretty, int depth) {
        if (!pretty) return;
        sb.append('\n');
        for (int i = 0; i < depth; i++) sb.append("  ");
    }

    private static void writeString(StringBuilder sb, String s) {
        sb.append('"');
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            switch (c) {
                case '"': sb.append("\\\""); break;
                case '\\': sb.append("\\\\"); break;
                case '\n': sb.append("\\n"); break;
                case '\r': sb.append("\\r"); break;
                case '\t': sb.append("\\t"); break;
                case '\b': sb.append("\\b"); break;
                case '\f': sb.append("\\f"); break;
                default:
                    if (c < 0x20) sb.append(String.format("\\u%04x", (int) c));
                    else sb.append(c);
            }
        }
        sb.append('"');
    }

    // ------------------------------------------------------------ helpers/map

    public static Map<String, Object> obj() { return new LinkedHashMap<>(); }

    public static Map<String, Object> obj(Object... kv) {
        Map<String, Object> m = new LinkedHashMap<>();
        for (int i = 0; i + 1 < kv.length; i += 2) m.put(String.valueOf(kv[i]), kv[i + 1]);
        return m;
    }

    public static List<Object> arr(Object... items) {
        List<Object> l = new ArrayList<>();
        for (Object o : items) l.add(o);
        return l;
    }

    /** Глубокое слияние patch в base (patch побеждает). Мутирует и возвращает base. */
    @SuppressWarnings("unchecked")
    public static Map<String, Object> deepMerge(Map<String, Object> base, Map<String, Object> patch) {
        if (patch == null) return base;
        for (Map.Entry<String, Object> e : patch.entrySet()) {
            Object pv = e.getValue();
            Object bv = base.get(e.getKey());
            if (pv instanceof Map && bv instanceof Map) {
                deepMerge((Map<String, Object>) bv, (Map<String, Object>) pv);
            } else {
                base.put(e.getKey(), pv);
            }
        }
        return base;
    }

    // ----------------------------------------------------------------- parser

    private static final class Parser {
        private final String s;
        private int i;

        Parser(String s) { this.s = s; }

        void ws() {
            while (i < s.length()) {
                char c = s.charAt(i);
                if (c == ' ' || c == '\n' || c == '\r' || c == '\t') i++;
                else if (c == '/' && i + 1 < s.length() && s.charAt(i + 1) == '/') { // комментарии //
                    while (i < s.length() && s.charAt(i) != '\n') i++;
                } else break;
            }
        }

        Object value() {
            ws();
            if (i >= s.length()) return null;
            char c = s.charAt(i);
            switch (c) {
                case '{': return object();
                case '[': return array();
                case '"': return string();
                case 't': i += 4; return Boolean.TRUE;
                case 'f': i += 5; return Boolean.FALSE;
                case 'n': i += 4; return null;
                default: return number();
            }
        }

        Map<String, Object> object() {
            Map<String, Object> m = new LinkedHashMap<>();
            i++; // {
            ws();
            if (i < s.length() && s.charAt(i) == '}') { i++; return m; }
            while (i < s.length()) {
                ws();
                String key = string();
                ws();
                if (i < s.length() && s.charAt(i) == ':') i++;
                Object v = value();
                m.put(key, v);
                ws();
                if (i < s.length() && s.charAt(i) == ',') { i++; continue; }
                if (i < s.length() && s.charAt(i) == '}') { i++; break; }
                break;
            }
            return m;
        }

        List<Object> array() {
            List<Object> l = new ArrayList<>();
            i++; // [
            ws();
            if (i < s.length() && s.charAt(i) == ']') { i++; return l; }
            while (i < s.length()) {
                l.add(value());
                ws();
                if (i < s.length() && s.charAt(i) == ',') { i++; continue; }
                if (i < s.length() && s.charAt(i) == ']') { i++; break; }
                break;
            }
            return l;
        }

        String string() {
            StringBuilder sb = new StringBuilder();
            if (i < s.length() && s.charAt(i) == '"') i++;
            while (i < s.length()) {
                char c = s.charAt(i++);
                if (c == '"') break;
                if (c == '\\' && i < s.length()) {
                    char e = s.charAt(i++);
                    switch (e) {
                        case 'n': sb.append('\n'); break;
                        case 't': sb.append('\t'); break;
                        case 'r': sb.append('\r'); break;
                        case 'b': sb.append('\b'); break;
                        case 'f': sb.append('\f'); break;
                        case 'u':
                            if (i + 4 <= s.length()) {
                                sb.append((char) Integer.parseInt(s.substring(i, i + 4), 16));
                                i += 4;
                            }
                            break;
                        default: sb.append(e);
                    }
                } else {
                    sb.append(c);
                }
            }
            return sb.toString();
        }

        Object number() {
            int start = i;
            while (i < s.length()) {
                char c = s.charAt(i);
                if ((c >= '0' && c <= '9') || c == '-' || c == '+' || c == '.' || c == 'e' || c == 'E') i++;
                else break;
            }
            String tok = s.substring(start, i);
            if (tok.isEmpty()) return null;
            try {
                if (tok.contains(".") || tok.contains("e") || tok.contains("E")) return Double.parseDouble(tok);
                long l = Long.parseLong(tok);
                if (l >= Integer.MIN_VALUE && l <= Integer.MAX_VALUE) return (int) l;
                return l;
            } catch (NumberFormatException e) {
                return tok;
            }
        }
    }
}
