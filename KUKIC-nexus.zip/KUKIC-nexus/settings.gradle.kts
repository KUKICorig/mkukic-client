rootProject.name = "mkukic-client"
