package rl.core;

/** Сектор рулетки: вес (вероятность) и множитель выплаты. */
public class Segment {
    public final String symbol;
    public final double weight;
    public final double multiplier;
    public final String label;

    public Segment(String symbol, double weight, double multiplier, String label) {
        this.symbol = symbol == null || symbol.isEmpty() ? "?" : symbol;
        this.weight = Math.max(0, weight);
        this.multiplier = Math.max(0, multiplier);
        this.label = label == null ? "" : label;
    }

    public boolean isWin() { return multiplier > 0; }

    public String name() {
        if (!label.isEmpty()) return label;
        return symbol + (multiplier > 0 ? " x" + Config.fmt(multiplier) : "");
    }
}
