package oneunit;

import arc.*;
import arc.math.*;
import arc.math.geom.*;
import arc.struct.*;
import arc.util.*;
import mindustry.*;
import mindustry.content.*;
import mindustry.game.*;
import mindustry.game.EventType.*;
import mindustry.gen.*;
import mindustry.maps.*;
import mindustry.net.*;
import mindustry.type.*;

/** Ядро режима: лобби -> драфт -> отсчёт -> бой -> итоги. Всё считается на сервере. */
public class Match{
    public static Match inst;

    public enum Phase{lobby, draft, countdown, live, ending}

    public Phase phase = Phase.lobby;
    /** true - режим War Thunder (жизни + очки), false - классика на выбывание. */
    public boolean respawnMode = true;

    public Seq<ArenaPlayer> roster = new Seq<>();
    public ObjectMap<String, ArenaPlayer> byUuid = new ObjectMap<>();
    public transient IntMap<ArenaPlayer> byUnit = new IntMap<>();
    public Seq<Team> teams = new Seq<>();

    public String mapName = "";
    public int mapIndex = 0;
    public int round = 0;
    public float timer = 0f;
    public float matchTime = 0f;
    public float now = 0f;
    public Team winner;
    public boolean reloading;

    private float hudTimer, secondTimer, winTimer;

    public Match(){
        inst = this;
        respawnMode = OneUnit.settings.defaultMode.equals("respawn");
        loadTeams();
    }

    public void loadTeams(){
        teams.clear();
        for(String name : OneUnit.settings.teams){
            Team found = null;
            for(Team t : Team.all){
                if(t.name.equalsIgnoreCase(name)){
                    found = t;
                    break;
                }
            }
            if(found == null){
                Log.warn("[OneUnitArena] Команда '@' не найдена, пропускаю.", name);
                continue;
            }
            if(!teams.contains(found)) teams.add(found);
        }
        if(teams.size < 2){
            teams.clear();
            teams.add(Team.sharded, Team.crux);
        }
    }

    // ---------------------------------------------------------------- участники

    public ArenaPlayer get(Player p){
        return p == null ? null : byUuid.get(p.uuid());
    }

    public boolean joined(Player p){
        return get(p) != null;
    }

    public Seq<ArenaPlayer> of(Team team){
        return roster.select(p -> p.team == team);
    }

    public int aliveCount(Team team){
        return of(team).count(ArenaPlayer::alive);
    }

    public int fightingCount(Team team){
        return of(team).count(ArenaPlayer::fighting);
    }

    public void join(Player p, @Nullable String teamName){
        if(joined(p)){
            Txt.send(p, "alreadyJoined");
            return;
        }
        Team team;
        if(teamName == null || teamName.isEmpty()){
            team = balancedTeam();
        }else{
            team = teams.find(t -> t.name.equalsIgnoreCase(teamName));
            if(team == null){
                Txt.send(p, "badTeam", teams.toString(", ", t -> t.name));
                return;
            }
        }

        ArenaPlayer ap = new ArenaPlayer(p, team);
        ap.resetMatchStats(respawnMode);
        if(phase != Phase.lobby){
            // подключился во время матча - наблюдатель до следующего раунда
            ap.out = true;
            ap.lives = 0;
        }
        roster.add(ap);
        byUuid.put(ap.uuid, ap);

        Txt.all(teamName == null ? "joined" : "joinedTeam", p.name, Txt.team(team), roster.size);
        if(phase != Phase.lobby) Txt.send(p, "spectating");
        Ui.inst.lobby(p);
    }

    public void leave(Player p){
        ArenaPlayer ap = get(p);
        if(ap == null){
            Txt.send(p, "notJoined");
            return;
        }
        remove(ap);
        Txt.all("left", p.name);
        if(phase == Phase.live) checkWin();
        else if(phase == Phase.draft && allPicked()) beginCountdown();
    }

    public void remove(ArenaPlayer ap){
        despawn(ap);
        roster.remove(ap);
        byUuid.remove(ap.uuid);
        // чистим ссылки на ушедшего в истории урона
        for(ArenaPlayer other : roster){
            other.incoming.remove(ap);
            other.incomingTime.remove(ap);
        }
    }

    public void setTeam(Player p, String teamName){
        ArenaPlayer ap = get(p);
        if(ap == null){
            join(p, teamName);
            return;
        }
        if(phase == Phase.live || phase == Phase.countdown){
            Txt.send(p, "pickLocked");
            return;
        }
        Team team = teams.find(t -> t.name.equalsIgnoreCase(teamName));
        if(team == null){
            Txt.send(p, "badTeam", teams.toString(", ", t -> t.name));
            return;
        }
        ap.team = team;
        ap.player.team(team);
        Txt.send(p, "teamSwitched", Txt.team(team));
    }

    public Team balancedTeam(){
        Team best = teams.first();
        int min = Integer.MAX_VALUE;
        for(Team t : teams){
            int size = of(t).size;
            if(size < min){
                min = size;
                best = t;
            }
        }
        return best;
    }

    public void toggleReady(Player p){
        ArenaPlayer ap = get(p);
        if(ap == null){
            Txt.send(p, "notJoined");
            return;
        }
        ap.ready = !ap.ready;
        Txt.send(p, ap.ready ? "readyOn" : "readyOff");
    }

    public boolean allPicked(){
        return roster.allMatch(a -> a.pick != null);
    }

    // ---------------------------------------------------------------- фазы

    public void startDraft(Player by){
        if(phase != Phase.lobby){
            Txt.send(by, "matchRunning");
            return;
        }
        if(roster.size < OneUnit.settings.minPlayers){
            Txt.send(by, "needPlayers", OneUnit.settings.minPlayers, roster.size);
            return;
        }
        if(teams.count(t -> of(t).size > 0) < 2){
            Txt.send(by, "needTwoTeams");
            return;
        }
        if(OneUnit.catalog.cheapest() == null){
            Txt.raw(by, "[scarlet]Каталог юнитов пуст - проверь units.json");
            return;
        }

        for(ArenaPlayer ap : roster){
            ap.resetMatchStats(respawnMode);
            ap.player.team(ap.team);
        }
        phase = Phase.draft;
        timer = OneUnit.settings.draftSeconds;
        Txt.all("draftStarted", OneUnit.settings.draftSeconds);
        for(ArenaPlayer ap : roster){
            Ui.inst.draft(ap.player);
        }
    }

    /** Выбор юнита: и на драфте, и при респавне. */
    public void pick(Player p, String entryId){
        ArenaPlayer ap = get(p);
        if(ap == null){
            Txt.send(p, "notJoined");
            return;
        }
        UnitEntry entry = OneUnit.catalog.byId(entryId);
        if(entry == null || !entry.valid()){
            Txt.send(p, "pickInvalid");
            return;
        }

        boolean draftPick = phase == Phase.draft;
        boolean respawnPick = phase == Phase.live && !ap.alive();

        if(!draftPick && !respawnPick){
            if(!(phase == Phase.live && OneUnit.settings.allowLiveSwitch && ap.alive())){
                Txt.send(p, "pickLocked");
                return;
            }
        }

        if(draftPick){
            if(entry.tier > OneUnit.settings.draft.maxTier){
                Txt.send(p, "tierLocked", OneUnit.settings.draft.maxTier);
                return;
            }
            if(!OneUnit.settings.draft.allowDuplicates && of(ap.team).contains(o -> o != ap && o.pick == entry)){
                Txt.raw(p, "[scarlet]Этот юнит уже занят союзником.");
                return;
            }
            if(OneUnit.settings.draft.chargePoints && entry.cost > ap.points){
                Txt.send(p, "notEnough", entry.cost, Txt.n(ap.points));
                return;
            }
            if(OneUnit.settings.draft.chargePoints) ap.points -= entry.cost;
            ap.pick = entry;
            if(ap.firstPick == null) ap.firstPick = entry;
            Txt.send(p, "youPicked", entry.display(), entry.tier, entry.cost);
            Ui.inst.draft(p);
            Ui.inst.refreshRosterAll();
            if(allPicked()) beginCountdown();
            return;
        }

        // респавн / живая смена
        if(ap.out || ap.lives <= 0){
            Txt.send(p, "outOfLives");
            return;
        }
        if(entry.tier > ap.maxTierAllowed()){
            Txt.send(p, "tierLocked", ap.maxTierAllowed());
            return;
        }
        if(entry.cost > ap.points){
            Txt.send(p, "notEnough", entry.cost, Txt.n(ap.points));
            return;
        }
        ap.points -= entry.cost;
        ap.pick = entry;
        if(ap.firstPick == null) ap.firstPick = entry;
        ap.respawnTimer = ap.respawnMenuTimer = -1f;
        ap.menuOpen = false;
        Ui.inst.close(p, Ui.RESPAWN);
        spawn(ap);
    }

    public void beginCountdown(){
        if(phase != Phase.draft) return;
        phase = Phase.countdown;
        timer = OneUnit.settings.countdownSeconds;
        Txt.all("countdown", OneUnit.settings.countdownSeconds);
        for(ArenaPlayer ap : roster){
            Ui.inst.close(ap.player, Ui.DRAFT);
            Ui.inst.roster(ap.player);
        }
    }

    public void startMatch(){
        Settings s = OneUnit.settings;
        Map map = nextMap();
        if(map == null){
            Txt.all("mapMissing", s.arenaMaps.isEmpty() ? "?" : s.arenaMaps.peek());
            phase = Phase.lobby;
            return;
        }
        mapName = map.plainName();
        round++;

        // 1. Перезагрузка мира с сохранением подключений
        reloading = true;
        try{
            WorldReloader reloader = new WorldReloader();
            reloader.begin();

            Vars.world.loadMap(map);
            Rules rules = Vars.state.rules;
            Lock.apply(rules);
            Events.fire(new RulesLoadEvent(rules));
            Vars.logic.play();

            reloader.end();

            // 2. Точки спавна: снимаем ядра, затем при необходимости удаляем
            Spawns.captureCores();
            if(s.removeCores) Spawns.removeCores();

            // 3. Команды и юниты
            byUnit.clear();
            for(ArenaPlayer ap : roster){
                ap.player.team(ap.team);
                ap.unit = null;
                ap.spawnIndex = 0;
                ap.clearIncoming();
                if(ap.pick == null) ap.pick = OneUnit.catalog.cheapest();
                if(ap.firstPick == null) ap.firstPick = ap.pick;
                spawn(ap);
            }
            Call.setRules(Vars.state.rules);
        }catch(Throwable t){
            Log.err("[OneUnitArena] Не удалось запустить матч", t);
            Txt.all("mapMissing", mapName);
            phase = Phase.lobby;
            return;
        }finally{
            reloading = false;
        }

        phase = Phase.live;
        matchTime = 0f;
        winner = null;
        Txt.all("matchStarted", Txt.f(respawnMode ? "modeRespawn" : "modeClassic"));
        Ui.inst.closeAllMenus();
        Ui.inst.hudAll();
    }

    public Map nextMap(){
        Settings s = OneUnit.settings;
        if(s.arenaMaps.isEmpty()) return null;
        for(int i = 0; i < s.arenaMaps.size; i++){
            String name = s.arenaMaps.get((mapIndex + i) % s.arenaMaps.size);
            Map found = findMap(name);
            if(found != null){
                mapIndex = (mapIndex + i + 1) % s.arenaMaps.size;
                return found;
            }
        }
        return null;
    }

    public static Map findMap(String name){
        if(name == null || name.isEmpty()) return null;
        String target = name.toLowerCase().replace('_', ' ').replace(".msav", "").trim();
        for(Map m : Vars.maps.all()){
            String plain = m.plainName().toLowerCase().replace('_', ' ').trim();
            if(plain.equals(target) || m.name().toLowerCase().equals(name.toLowerCase())) return m;
        }
        return Vars.maps.byName(name);
    }

    // ---------------------------------------------------------------- юниты

    public void spawn(ArenaPlayer ap){
        if(ap.pick == null || ap.player == null) return;
        UnitEntry entry = ap.pick;
        Vec2 pos = Spawns.find(ap);

        Unit unit = entry.type.spawn(ap.team, pos.x, pos.y, 90f);
        unit.maxHealth(entry.maxHp());
        unit.health(unit.maxHealth());
        unit.spawnedByCore(false);
        unit.controller(ap.player);
        ap.player.unit(unit);

        applyEffects(ap, true);
        float protection = OneUnit.settings.respawn.spawnProtection;
        if(protection > 0) unit.apply(StatusEffects.invincible, protection * 60f);

        ap.unit = unit;
        ap.clearIncoming();
        byUnit.put(unit.id(), ap);
        Call.spawnEffect(pos.x, pos.y, 90f, entry.type);
        Txt.send(ap.player, "spawned", entry.display(), entry.tier);
        Ui.inst.hud(ap.player);
    }

    public void despawn(ArenaPlayer ap){
        if(ap.unit != null){
            byUnit.remove(ap.unit.id());
            if(ap.unit.isAdded()) ap.unit.remove();
            ap.unit = null;
        }
        if(ap.player != null && ap.player.isAdded()) ap.player.clearUnit();
    }

    public void applyEffects(ArenaPlayer ap, boolean force){
        if(ap.unit == null || ap.pick == null || ap.pick.parsedEffects.isEmpty()) return;
        if(!force){
            ap.effectTimer -= Time.delta / Time.toSeconds;
            if(ap.effectTimer > 0) return;
        }
        ap.effectTimer = 1f;
        for(StatusEffect effect : ap.pick.parsedEffects){
            ap.unit.apply(effect, 130f);
        }
    }

    // ---------------------------------------------------------------- урон и смерть

    public void onDamage(Unit victim, Bullet bullet){
        ArenaPlayer target = byUnit.get(victim.id());
        if(target == null || bullet == null) return;
        if(!(bullet.owner instanceof Unit owner)) return;
        ArenaPlayer from = byUnit.get(owner.id());
        if(from == null || from == target || from.team == target.team) return;

        float amount = Math.max(0f, bullet.damage);
        target.hit(from, amount, now);
        from.damage += amount;

        float rate = OneUnit.settings.respawn.damagePointsPer1000;
        if(respawnMode && rate > 0){
            from.points += amount / 1000f * rate;
        }
    }

    public void onDeath(Unit unit){
        ArenaPlayer ap = byUnit.get(unit.id());
        if(ap == null) return;
        byUnit.remove(unit.id());
        ap.unit = null;
        handleDeath(ap);
    }

    public void handleDeath(ArenaPlayer ap){
        Settings.Respawn cfg = OneUnit.settings.respawn;
        ap.deaths++;
        ap.menuOpen = false;
        ap.respawnMenuTimer = -1f;

        // киллер - последний нанёсший урон, ассисты - остальные с достаточным вкладом
        ArenaPlayer killer = null;
        float lastTime = -1f;
        float total = 0f;
        for(ObjectMap.Entry<ArenaPlayer, Float> e : ap.incoming){
            if(now - ap.incomingTime.get(e.key, -999f) > cfg.damageMemory) continue;
            total += e.value;
            float t = ap.incomingTime.get(e.key, 0f);
            if(t > lastTime){
                lastTime = t;
                killer = e.key;
            }
        }
        final ArenaPlayer finalKiller = killer;
        for(ObjectMap.Entry<ArenaPlayer, Float> e : ap.incoming){
            ArenaPlayer other = e.key;
            if(other == finalKiller || !other.connected()) continue;
            if(now - ap.incomingTime.get(other, -999f) > cfg.damageMemory) continue;
            if(total > 0 && e.value / total >= cfg.assistThreshold){
                other.assists++;
                if(respawnMode){
                    other.points += cfg.assistPoints;
                    Txt.send(other.player, "youAssisted", cfg.assistPoints, ap.name());
                }
            }
        }
        if(killer != null && killer.connected()){
            killer.kills++;
            int bounty = cfg.killPoints + (ap.pick == null ? 0 : ap.pick.cost / 2);
            if(respawnMode){
                killer.points += bounty;
                Txt.send(killer.player, "youKilled", bounty, ap.name());
            }
            if(OneUnit.settings.hud.killFeed){
                Txt.all("killFeed", killer.name(), killer.pick == null ? "?" : killer.pick.display(), ap.name(), ap.pick == null ? "?" : ap.pick.display());
            }
        }else if(OneUnit.settings.hud.killFeed){
            Txt.all("killFeed", "-", "-", ap.name(), ap.pick == null ? "?" : ap.pick.display());
        }
        ap.clearIncoming();

        // штраф/возврат очков
        if(ap.pick != null && cfg.refundOnDeath > 0 && respawnMode){
            ap.points += ap.pick.cost * cfg.refundOnDeath;
        }
        if(cfg.pointsLossOnDeath > 0 && respawnMode){
            ap.points *= 1f - Mathf.clamp(cfg.pointsLossOnDeath / 100f, 0f, 1f);
        }

        Txt.send(ap.player, "youDied", killer == null ? "-" : killer.name());

        ap.lives--;
        if(!respawnMode || ap.lives <= 0){
            ap.out = true;
            ap.lives = Math.max(0, ap.lives);
            Txt.send(ap.player, respawnMode ? "outOfLives" : "diedClassic");
            if(ap.player != null && ap.player.isAdded()) ap.player.clearUnit();
        }else{
            ap.respawnTimer = cfg.respawnDelay;
            Txt.send(ap.player, "diedRespawn", ap.lives, Txt.n(ap.points));
            Txt.send(ap.player, "respawnWait", Txt.n(cfg.respawnDelay));
        }
        Ui.inst.hud(ap.player);
        checkWin();
    }

    // ---------------------------------------------------------------- победа

    public void checkWin(){
        if(phase != Phase.live) return;
        Seq<Team> alive = teams.select(t -> fightingCount(t) > 0);
        if(alive.size <= 1){
            endMatch(alive.isEmpty() ? null : alive.first());
        }
    }

    public void endMatch(Team win){
        if(phase != Phase.live) return;
        winner = win;
        phase = Phase.ending;
        timer = OneUnit.settings.endScreenSeconds;

        for(Team t : teams){
            if(fightingCount(t) == 0 && of(t).size > 0){
                Txt.all("teamEliminated", Txt.team(t));
            }
        }
        if(win == null) Txt.all("draw");
        else Txt.all("win", Txt.team(win));

        for(ArenaPlayer ap : roster){
            despawn(ap);
            Ui.inst.results(ap.player);
        }
        Ui.inst.hudAll();
    }

    public void timeUp(){
        Team best = null;
        float bestScore = -1f;
        boolean tie = false;
        for(Team t : teams){
            float score = 0f;
            for(ArenaPlayer ap : of(t)) score += ap.points + ap.kills * 50f;
            if(score > bestScore){
                bestScore = score;
                best = t;
                tie = false;
            }else if(score == bestScore){
                tie = true;
            }
        }
        Txt.all("timeUp", best == null || tie ? "-" : Txt.team(best));
        endMatch(tie ? null : best);
    }

    public void stop(Player by){
        if(phase == Phase.lobby){
            Txt.send(by, "noMatch");
            return;
        }
        Txt.all("matchStop");
        for(ArenaPlayer ap : roster){
            despawn(ap);
            Ui.inst.closeAll(ap.player);
        }
        byUnit.clear();
        phase = Phase.lobby;
        winner = null;
        for(ArenaPlayer ap : roster){
            ap.ready = false;
            ap.out = false;
        }
        Ui.inst.hudAll();
    }

    public void resetToLobby(){
        for(ArenaPlayer ap : roster){
            despawn(ap);
            ap.ready = false;
            ap.out = false;
            ap.pick = null;
            ap.respawnTimer = ap.respawnMenuTimer = -1f;
            ap.menuOpen = false;
            Ui.inst.closeAll(ap.player);
        }
        byUnit.clear();
        phase = Phase.lobby;
        winner = null;

        String lobbyMap = OneUnit.settings.lobbyMap;
        if(lobbyMap != null && !lobbyMap.isEmpty()){
            Map map = findMap(lobbyMap);
            if(map != null){
                reloading = true;
                try{
                    WorldReloader reloader = new WorldReloader();
                    reloader.begin();
                    Vars.world.loadMap(map);
                    Rules rules = Vars.state.rules;
                    Lock.apply(rules);
                    Events.fire(new RulesLoadEvent(rules));
                    Vars.logic.play();
                    reloader.end();
                    for(ArenaPlayer ap : roster) ap.player.team(ap.team);
                }catch(Throwable t){
                    Log.err("[OneUnitArena] Не удалось загрузить лобби-карту", t);
                }finally{
                    reloading = false;
                }
            }
        }
        Txt.all("backToLobby");
        Ui.inst.hudAll();
    }

    /** Внешняя смена карты (host/changemap из консоли) - сбрасываем матч. */
    public void onWorldReset(){
        if(reloading) return;
        if(phase == Phase.lobby) return;
        phase = Phase.lobby;
        byUnit.clear();
        for(ArenaPlayer ap : roster){
            ap.unit = null;
            ap.ready = false;
            ap.out = false;
            ap.pick = null;
        }
        Log.info("[OneUnitArena] Мир сброшен извне - матч остановлен.");
    }

    public void setMode(boolean respawn){
        respawnMode = respawn;
        Txt.all("modeChanged", Txt.f(respawn ? "modeRespawn" : "modeClassic"));
    }

    public void addPoints(Player target, float amount){
        ArenaPlayer ap = get(target);
        if(ap == null) return;
        ap.points += amount;
        Txt.send(target, "pointsAdded", target.name, Txt.n(amount));
        Ui.inst.hud(target);
    }

    // ---------------------------------------------------------------- тик

    public void update(){
        float dt = Time.delta / Time.toSeconds;
        now += dt;

        switch(phase){
            case draft -> {
                timer -= dt;
                if(timer <= 0f){
                    for(ArenaPlayer ap : roster){
                        if(ap.pick != null) continue;
                        UnitEntry auto = OneUnit.settings.draft.chargePoints
                            ? OneUnit.catalog.bestAffordable((int)ap.points, OneUnit.settings.draft.maxTier)
                            : OneUnit.catalog.bestAffordable(Integer.MAX_VALUE, OneUnit.settings.draft.maxTier);
                        if(auto == null) auto = OneUnit.catalog.cheapest();
                        ap.pick = auto;
                        if(ap.firstPick == null) ap.firstPick = auto;
                        Txt.all("draftAuto", ap.name(), auto == null ? "?" : auto.display());
                    }
                    beginCountdown();
                }
            }
            case countdown -> {
                timer -= dt;
                if(timer <= 0f) startMatch();
            }
            case live -> tickLive(dt);
            case ending -> {
                timer -= dt;
                if(timer <= 0f){
                    if(OneUnit.settings.autoReturnToLobby) resetToLobby();
                    else phase = Phase.lobby;
                }
            }
            default -> { }
        }

        hudTimer -= dt;
        if(hudTimer <= 0f){
            hudTimer = OneUnit.settings.hud.interval;
            Ui.inst.hudAll();
        }
    }

    private void tickLive(float dt){
        matchTime += dt;
        Settings.Respawn cfg = OneUnit.settings.respawn;

        for(ArenaPlayer ap : roster){
            if(!ap.connected()) continue;

            if(ap.alive()){
                Lock.tick(ap);
                applyEffects(ap, false);
                if(respawnMode && cfg.pointsPerSecond > 0) ap.points += cfg.pointsPerSecond * dt;
                if(respawnMode && cfg.capturePointsPerSecond > 0) capture(ap, dt);
            }else{
                // страховка: юнит исчез без события смерти
                if(ap.unit != null && !ap.unit.isAdded()){
                    byUnit.remove(ap.unit.id());
                    ap.unit = null;
                    handleDeath(ap);
                    continue;
                }
                if(ap.out || ap.lives <= 0 || !respawnMode) continue;

                if(ap.respawnTimer > 0f){
                    ap.respawnTimer -= dt;
                    if(ap.respawnTimer <= 0f){
                        ap.respawnTimer = -1f;
                        ap.menuOpen = true;
                        ap.respawnMenuTimer = cfg.respawnTimeout;
                        Txt.send(ap.player, "respawnReady", Txt.n(ap.points));
                        Ui.inst.respawn(ap.player);
                    }
                }else if(ap.menuOpen){
                    ap.respawnMenuTimer -= dt;
                    if(ap.respawnMenuTimer <= 0f){
                        UnitEntry auto = OneUnit.catalog.bestAffordable((int)ap.points, ap.maxTierAllowed());
                        ap.menuOpen = false;
                        ap.respawnMenuTimer = -1f;
                        if(auto != null){
                            Txt.send(ap.player, "respawnAuto", auto.display());
                            pick(ap.player, auto.id());
                        }
                    }
                }
            }
        }

        winTimer -= dt;
        if(winTimer <= 0f){
            winTimer = 0.5f;
            checkWin();
        }

        int limit = OneUnit.settings.matchMinutes;
        if(limit > 0 && matchTime >= limit * 60f){
            timeUp();
        }
    }

    private void capture(ArenaPlayer ap, float dt){
        Settings.MapConfig cfg = Spawns.configFor(mapName);
        if(cfg == null || cfg.zones.isEmpty()){
            ap.captureZone = "";
            return;
        }
        String inside = "";
        for(Settings.Zone z : cfg.zones){
            float zx = z.x * Vars.tilesize, zy = z.y * Vars.tilesize;
            if(Mathf.dst(ap.unit.x, ap.unit.y, zx, zy) <= z.radius * Vars.tilesize){
                inside = z.name;
                break;
            }
        }
        if(inside.isEmpty()){
            ap.captureZone = "";
            ap.captureTimer = 0f;
            return;
        }
        ap.captureZone = inside;
        ap.points += OneUnit.settings.respawn.capturePointsPerSecond * dt;
        ap.captureTimer += dt;
        if(ap.captureTimer >= 10f){
            ap.captureTimer = 0f;
            ap.captures++;
            Txt.all("capture", ap.name(), inside);
        }
    }

    // ---------------------------------------------------------------- разное

    public void onJoin(Player p){
        Txt.send(p, "welcome");
        if(OneUnit.settings.autoJoin && !joined(p)){
            join(p, null);
        }else if(phase == Phase.live){
            Txt.send(p, "spectating");
        }
    }

    public void onLeave(Player p){
        ArenaPlayer ap = get(p);
        if(ap == null) return;
        String name = p.name;
        remove(ap);
        Txt.all("left", name);
        if(phase == Phase.live) checkWin();
        else if(phase == Phase.draft && allPicked()) beginCountdown();
    }

    public String phaseName(){
        return switch(phase){
            case lobby -> "лобби";
            case draft -> "драфт";
            case countdown -> "старт";
            case live -> "бой";
            case ending -> "итоги";
        };
    }

    public float timeLeft(){
        int limit = OneUnit.settings.matchMinutes;
        if(phase == Phase.live && limit > 0) return Math.max(0f, limit * 60f - matchTime);
        return Math.max(0f, timer);
    }
}
