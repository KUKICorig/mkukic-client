import sys, urllib.request, json
def get(url, raw=False):
    req=urllib.request.Request(url, headers={"User-Agent":"probe"})
    try:
        with urllib.request.urlopen(req, timeout=30) as r:
            d=r.read()
            return r.status, d
    except Exception as e:
        return getattr(e,'code',type(e).__name__), str(e).encode()
if __name__=="__main__":
    for url in sys.argv[1:]:
        s,d=get(url)
        print(url, "->", s, len(d) if isinstance(d,bytes) else "")
        if s!=200: print("   ", d[:200])
