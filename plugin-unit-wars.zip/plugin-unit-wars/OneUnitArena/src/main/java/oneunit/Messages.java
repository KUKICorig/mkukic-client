package oneunit;

import arc.struct.*;
import arc.util.*;

/**
 * Все строки режима. Файл messages.json создаётся автоматически, можно править вручную.
 * Плейсхолдер '@' подставляется по порядку (arc Strings.format).
 * Цвета: [accent], [green], [scarlet], [gold], [gray], [white], [] - сброс.
 */
public class Messages{
    public ObjectMap<String, String> lines = new ObjectMap<>();

    public String get(String key){
        String s = lines.get(key);
        return s == null ? key : s;
    }

    public String f(String key, Object... args){
        return Strings.format(get(key), args);
    }

    public void fillDefaults(){
        ObjectMap<String, String> d = defaults();
        for(ObjectMap.Entry<String, String> e : d){
            if(!lines.containsKey(e.key)) lines.put(e.key, e.value);
        }
    }

    public static Messages create(){
        Messages m = new Messages();
        m.lines = defaults();
        return m;
    }

    public static ObjectMap<String, String> defaults(){
        ObjectMap<String, String> m = new ObjectMap<>();

        // --- системное / чат ---
        m.put("prefix", "[accent][Арена][] ");
        m.put("welcome", "[accent]One Unit Arena[]: один юнит - одна жизнь. Напиши [green]/lobby[] чтобы войти в лобби, [green]/uhelp[] - помощь.");
        m.put("joined", "[green]@[] вошёл в лобби. Игроков: [accent]@[]");
        m.put("joinedTeam", "[green]@[] вошёл в лобби за команду @[]. Игроков: [accent]@[]");
        m.put("left", "[gray]@[] покинул лобби.");
        m.put("alreadyJoined", "[scarlet]Ты уже в лобби.[] Меню: [green]/lobby[]");
        m.put("notJoined", "[scarlet]Ты не в лобби.[] Напиши [green]/join[]");
        m.put("badTeam", "[scarlet]Нет такой команды.[] Доступны: @");
        m.put("teamSwitched", "Команда изменена на @[]");
        m.put("readyOn", "[green]Ты готов.[] Ждём остальных.");
        m.put("readyOff", "[gray]Готовность снята.");
        m.put("allReady", "[accent]Все готовы![] Драфт начинается.");
        m.put("needPlayers", "[scarlet]Нужно минимум @ игроков[] (сейчас @).");
        m.put("needTwoTeams", "[scarlet]Нужны игроки хотя бы в двух разных командах.");
        m.put("matchRunning", "[scarlet]Матч уже идёт.[] Дождись конца или /arena stop");
        m.put("noMatch", "[scarlet]Сейчас нет матча.[] /lobby");
        m.put("notAdmin", "[scarlet]Только для админов.");
        m.put("draftStarted", "[accent]Драфт начался![] Выбери юнита: [green]/pick[] (@ сек).");
        m.put("draftAuto", "[gray]Время вышло - @ получил автопик: [accent]@[]");
        m.put("youPicked", "[green]Выбрано:[] @ [gray](T@, @ очк.)[]");
        m.put("pickInvalid", "[scarlet]Такого юнита нет в каталоге.");
        m.put("notEnough", "[scarlet]Не хватает очков:[] нужно @, есть @.");
        m.put("tierLocked", "[scarlet]Тир недоступен:[] максимум T@.");
        m.put("pickLocked", "[scarlet]Сменить юнита сейчас нельзя.");
        m.put("duplicateUnit", "[scarlet]Этот юнит уже занят союзником.");
        m.put("countdown", "[accent]Состав зафиксирован.[] Старт через [gold]@[] сек. Смотри [green]/roster[]");
        m.put("matchStarted", "[accent]Матч начался![] Режим: [gold]@[]. Уничтожьте все юниты врага.");
        m.put("modeClassic", "Классика (1 жизнь)");
        m.put("modeRespawn", "War Thunder (жизни + очки)");
        m.put("modeChanged", "Режим переключён: [gold]@[]");
        m.put("killFeed", "[scarlet]@[] [gray](@)[] уничтожил [accent]@[] [gray](@)[]");
        m.put("youKilled", "[green]+@ очк.[] за убийство @");
        m.put("youAssisted", "[green]+@ очк.[] за помощь против @");
        m.put("youDied", "[scarlet]Твой юнит уничтожен.[] Убийца: [accent]@[]");
        m.put("diedClassic", "[scarlet]Ты выбыл.[] Наблюдай за боем; итоги в конце матча.");
        m.put("diedRespawn", "[scarlet]Юнит уничтожен.[] Осталось жизней: [gold]@[]. Очки: [accent]@[]");
        m.put("outOfLives", "[scarlet]Жизни закончились - ты выбыл.[]");
        m.put("respawnWait", "[gray]Меню респавна откроется через @ сек...");
        m.put("respawnReady", "[accent]Выбери нового юнита![] Очки: [gold]@[]");
        m.put("respawnAuto", "[gray]Автовыбор: [accent]@[]");
        m.put("respawnReopen", "[gray]Меню респавна закрыто. Откроется снова через @ сек (или /pick).");
        m.put("spawned", "[green]В бой:[] @ [gray](T@)[]");
        m.put("teamEliminated", "[scarlet]Команда @[] полностью выбыла!");
        m.put("win", "[accent]Победа команды @[]! Поздравляем.");
        m.put("draw", "[gold]Ничья![] Обе команды выбыли одновременно.");
        m.put("timeUp", "[gold]Время матча вышло.[] Победитель по очкам: @[]");
        m.put("matchStop", "[gray]Матч остановлен админом. Возврат в лобби.");
        m.put("backToLobby", "[accent]Возврат в лобби.[] [green]/lobby[] - состав, [green]/start[] - новый матч.");
        m.put("reloaded", "[green]Конфиги перезагружены.[] Юнитов в каталоге: @");
        m.put("spawnSaved", "[green]Точка спавна команды @[] сохранена: @,@");
        m.put("spawnRemoved", "[gray]Точки спавна команды @[] удалены.");
        m.put("zoneSaved", "[green]Точка захвата '@' сохранена: @,@ (радиус @)");
        m.put("zoneRemoved", "[gray]Точка захвата '@' удалена.");
        m.put("pointsAdded", "[green]@[] получил @ очк.");
        m.put("mapMissing", "[scarlet]Карта '@' не найдена.[] Положи арену в maps/ и укажи её в settings.json");
        m.put("spectating", "[gray]Ты наблюдатель. Меню матча: [green]/roster[]");
        m.put("capture", "[gold]@[] удерживает точку @");
        m.put("noCatalog", "[scarlet]Каталог юнитов пуст - проверь units.json");
        m.put("playerNotFound", "[scarlet]Игрок '@' не найден.");
        m.put("badNumber", "[scarlet]Нужно число, а не '@'.");
        m.put("usage", "[gray]Использование: @");

        // --- UI: общее ---
        m.put("ui.close", "Закрыть");
        m.put("ui.back", "Назад");
        m.put("ui.refresh", "Обновить");
        m.put("ui.points", "Очки");
        m.put("ui.lives", "Жизни");
        m.put("ui.tier", "Тир");
        m.put("ui.cost", "Цена");
        m.put("ui.hp", "HP");
        m.put("ui.dmg", "Урон");
        m.put("ui.ready", "Готов");
        m.put("ui.notReady", "Не готов");
        m.put("ui.spectator", "Наблюдатель");
        m.put("ui.dead", "Выбыл");
        m.put("ui.alive", "В бою");
        m.put("ui.waiting", "Ожидание");
        m.put("ui.noUnit", "не выбран");
        m.put("ui.free", "бесплатно");
        m.put("ui.emptyTeam", "- пусто -");
        m.put("ui.noUnits", "В этом тире нет доступных юнитов");

        // --- UI: лобби ---
        m.put("ui.lobbyTitle", "ЛОББИ - One Unit Arena");
        m.put("ui.lobbyInfo", "Режим: @   |   Игроков: @   |   Карта: @");
        m.put("ui.lobbyHint", "Выбери команду, отметь готовность. Админ запускает матч кнопкой ниже.");
        m.put("ui.join", "Войти в лобби");
        m.put("ui.leave", "Выйти");
        m.put("ui.readyBtn", "Я готов");
        m.put("ui.unreadyBtn", "Отменить готовность");
        m.put("ui.start", "НАЧАТЬ МАТЧ");
        m.put("ui.stop", "ОСТАНОВИТЬ");
        m.put("ui.mode", "Режим: @");
        m.put("ui.teamHeader", "Команда @");
        m.put("ui.teamLabel", "Команда:");

        // --- UI: драфт / респавн ---
        m.put("ui.draftTitle", "ДРАФТ - выбери своего юнита");
        m.put("ui.respawnTitle", "РЕСПАВН - купи нового юнита");
        m.put("ui.draftInfo", "Очки: @   |   Жизни: @   |   Время: @ сек");
        m.put("ui.draftHint", "Один юнит на весь матч. Дороже тир - сильнее юнит. Враги видят твой пик.");
        m.put("ui.respawnHint", "Покупка списывает очки. Не хватает - берите тир ниже.");
        m.put("ui.selected", "Выбрано: @");
        m.put("ui.pick", "Выбрать");
        m.put("ui.locked", "Дорого");
        m.put("ui.tierClosed", "тир закрыт");
        m.put("ui.enemyHidden", "скрыто");
        m.put("ui.picksTitle", "КТО НА КОМ ИГРАЕТ");
        m.put("ui.tierTab", "T@ (@)");

        // --- UI: состав / счёт ---
        m.put("ui.rosterTitle", "СОСТАВ КОМАНД");
        m.put("ui.scoreTitle", "ТАБЛИЦА ОЧКОВ");
        m.put("ui.resultsTitle", "ИТОГИ МАТЧА");
        m.put("ui.colPlayer", "Игрок");
        m.put("ui.colUnit", "Юнит");
        m.put("ui.colScore", "Очки");
        m.put("ui.colKills", "Убийства");
        m.put("ui.colAssists", "Ассисты");
        m.put("ui.colDeaths", "Смерти");
        m.put("ui.colLives", "Жизни");
        m.put("ui.colDamage", "Урон");
        m.put("ui.colStatus", "Статус");
        m.put("ui.winner", "Победитель: @");
        m.put("ui.helpTitle", "One Unit Arena - помощь");

        return m;
    }
}
