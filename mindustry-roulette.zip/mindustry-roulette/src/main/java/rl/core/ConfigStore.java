package rl.core;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Работа с файлами плагина: config.json, accounts.json, state.json, логи.
 * Всё пишется атомарно (tmp + move) и под локом.
 */
public class ConfigStore {

    private final Fs fs;
    private final String dir;
    private final Object lock = new Object();

    private String serverSeed;
    private String sessionToken;
    private long startedAt = System.currentTimeMillis();

    public ConfigStore(Fs fs, String dir) {
        this.fs = fs;
        this.dir = dir;
        fs.mkdirs(dir);
        fs.mkdirs(fs.child(dir, "logs"));
    }

    public Fs fs() { return fs; }

    public String dir() { return dir; }

    public String path(String name) { return fs.child(dir, name); }

    public String logsDir() { return fs.child(dir, "logs"); }

    // -------------------------------------------------------------- config

    public Config loadConfig() {
        String raw = fs.readOr(path("config.json"), "");
        Config cfg = Config.fromJson(raw);
        cfg.sanitize();
        return cfg;
    }

    public String saveConfig(Config cfg) {
        cfg.sanitize();
        String json = Json.write(cfg.toMap());
        return fs.writeQuiet(path("config.json"), json) ? null : "не удалось записать config.json";
    }

    /** Применить частичные правки (deep merge) и сохранить. Возвращает ошибку или null. */
    public String patchConfig(Config cfg, Map<String, Object> patch) {
        Map<String, Object> current = cfg.toMap();
        Json.deepMerge(current, patch);
        cfg.fromMap(current);
        cfg.sanitize();
        return saveConfig(cfg);
    }

    // ---------------------------------------------------------------- state

    /** Сид и прочее, что нельзя показывать игрокам, хранится отдельно от config.json. */
    public synchronized String loadOrCreateServerSeed() {
        if (serverSeed != null) return serverSeed;
        String raw = fs.readOr(path("state.json"), "");
        Json.Node n = Json.Node.of(raw.isEmpty() ? Json.obj() : Json.parse(raw));
        serverSeed = n.str("serverSeed", "");
        sessionToken = n.str("sessionToken", "");
        if (serverSeed.isEmpty()) {
            serverSeed = ProvablyFair.newServerSeed();
            saveState();
        }
        return serverSeed;
    }

    public synchronized String rotateServerSeed() {
        serverSeed = ProvablyFair.newServerSeed();
        saveState();
        return serverSeed;
    }

    public synchronized String sessionToken() {
        if (sessionToken == null || sessionToken.isEmpty()) {
            sessionToken = ProvablyFair.newServerSeed().substring(0, 32);
            saveState();
        }
        return sessionToken;
    }

    private void saveState() {
        Map<String, Object> st = new LinkedHashMap<>();
        st.put("serverSeed", serverSeed);
        st.put("sessionToken", sessionToken);
        st.put("updatedAt", System.currentTimeMillis());
        fs.writeQuiet(path("state.json"), Json.write(st));
    }

    public long startedAt() { return startedAt; }

    // ----------------------------------------------------------------- web

    public static String resource(String name) {
        try (java.io.InputStream in = ConfigStore.class.getResourceAsStream(name)) {
            if (in == null) return null;
            java.io.ByteArrayOutputStream out = new java.io.ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int r;
            while ((r = in.read(buf)) > 0) out.write(buf, 0, r);
            return new String(out.toByteArray(), StandardCharsets.UTF_8);
        } catch (IOException e) {
            return null;
        }
    }

    /** Список файлов конфигурации/данных с размером — для вкладки «Файлы». */
    public List<Map<String, Object>> dataFiles() {
        List<Map<String, Object>> out = new ArrayList<>();
        for (String name : new String[]{"config.json", "accounts.json", "state.json"}) {
            String p = path(name);
            out.add(Json.obj("name", name, "exists", fs.exists(p), "sensitive", name.equals("state.json")));
        }
        return out;
    }

    /** Скачать файл (только из папки мода). Возвращает null, если файла нет. */
    public String readFileSafe(String name) {
        if (name == null) return null;
        if (name.contains("..") || name.contains("/") || name.contains("\\")) return null;
        String p = path(name);
        return fs.exists(p) ? fs.readOr(p, "") : null;
    }

    /** Экспорт файла в произвольное место на диске (для ручного бэкапа). */
    public String exportTo(String name, Path target) {
        String content = readFileSafe(name);
        if (content == null) return "файл не найден: " + name;
        try {
            if (target.getParent() != null) Files.createDirectories(target.getParent());
            Path tmp = target.resolveSibling(target.getFileName() + ".tmp");
            Files.write(tmp, content.getBytes(StandardCharsets.UTF_8));
            Files.move(tmp, target, StandardCopyOption.REPLACE_EXISTING);
            return null;
        } catch (IOException e) {
            return String.valueOf(e.getMessage());
        }
    }
}
