package oneunit;

import arc.struct.*;
import arc.util.*;
import mindustry.game.*;
import mindustry.gen.*;
import mindustry.ui.builder.*;
import mindustry.ui.builder.UiBuilder.*;

import static mindustry.ui.builder.UiBuilder.*;

/**
 * Весь интерфейс строится на сервере через v8 UiBuilder/MenuBuilder.
 * Клиентский мод не нужен: игрок видит нормальные диалоги Mindustry с иконками юнитов.
 */
public class Ui{
    public static Ui inst;

    public static final int LOBBY = 4101, DRAFT = 4102, ROSTER = 4103, SCORE = 4104, HELP = 4105, RESULTS = 4106, RESPAWN = 4107;

    public Ui(){
        inst = this;
    }

    // ------------------------------------------------------------------ каркас

    private TableBuilder wrap(TableBuilder body){
        TableBuilder root = table();
        root.add(body.id("body").growX());
        return root;
    }

    private void show(Player p, int id, String title, TableBuilder body, boolean fill){
        if(p == null || p.con == null) return;
        MenuBuilder.of(wrap(body)).id(id).title(title).hideOnClick(false).hideExisting(true).fillScreen(fill).show(p);
    }

    private void update(Player p, int id, TableBuilder body){
        if(p == null || p.con == null) return;
        MenuBuilder.of(body).id(id).update(p, "body");
    }

    public void close(Player p, int id){
        if(p == null || p.con == null) return;
        Call.hideMenuBuilder(p.con, id);
    }

    public void closeAll(Player p){
        for(int id : new int[]{LOBBY, DRAFT, ROSTER, SCORE, HELP, RESULTS, RESPAWN}) close(p, id);
    }

    public void closeAllMenus(){
        Groups.player.each(this::closeAll);
    }

    private String m(String key, Object... args){
        return OneUnit.msg.f(key, args);
    }

    // ------------------------------------------------------------------ лобби

    public void lobby(Player p){
        show(p, LOBBY, m("ui.lobbyTitle"), lobbyBody(p), true);
    }

    private TableBuilder lobbyBody(Player p){
        Match match = Match.inst;
        ArenaPlayer ap = match.get(p);
        TableBuilder body = table();

        body.add(label(m("ui.lobbyInfo",
            Txt.f(match.respawnMode ? "modeRespawn" : "modeClassic"),
            match.roster.size,
            match.mapName.isEmpty() ? (OneUnit.settings.arenaMaps.isEmpty() ? "-" : OneUnit.settings.arenaMaps.first()) : match.mapName
        )).style("techLabel")).growX().pad(4f).row();

        body.add(label(m("ui.lobbyHint")).wrap().color("gray")).growX().padBottom(6f).row();
        body.add(teamColumns(true)).growX().row();

        TableBuilder buttons = table();
        if(ap == null){
            buttons.add(button(m("ui.join")).style("fullTogglet").clicked("join").width(200f).height(50f));
        }else{
            buttons.add(button(ap.ready ? m("ui.unreadyBtn") : m("ui.readyBtn"))
                .style(ap.ready ? "clearTogglet" : "fullTogglet").checked(ap.ready)
                .clicked("ready").width(200f).height(50f));
            buttons.add(button(m("ui.leave")).style("cleart").clicked("leave").width(130f).height(50f));
        }
        buttons.row();
        buttons.add(button(m("ui.rosterTitle")).style("cleart").clicked("roster").width(200f).height(44f));
        buttons.add(button(m("ui.helpTitle")).style("cleart").clicked("help").width(200f).height(44f));
        buttons.row();
        if(p.admin){
            buttons.add(button(m("ui.start")).style("fullTogglet").clicked("start").width(200f).height(50f).disabled(match.phase != Match.Phase.lobby));
            buttons.add(button(m("ui.mode", Txt.f(match.respawnMode ? "modeRespawn" : "modeClassic"))).style("cleart").clicked("mode").width(260f).height(50f));
            buttons.row();
        }
        buttons.add(button(m("ui.close")).style("cleart").clicked("close").width(150f).height(44f));
        body.add(buttons).padTop(8f).row();

        // выбор команды
        TableBuilder teamRow = table();
        teamRow.add(label("Команда: ").color("gray"));
        for(Team t : match.teams){
            boolean mine = ap != null && ap.team == t;
            teamRow.add(button(Txt.team(t)).style(mine ? "fullTogglet" : "cleart").checked(mine)
                .clicked("team:" + t.name).width(120f).height(42f));
        }
        body.add(teamRow).padTop(6f).row();
        return body;
    }

    /** Два (или N) столбика: ник + выбранный юнит. */
    private TableBuilder teamColumns(boolean lobbyStyle){
        Match match = Match.inst;
        ArenaPlayer me = match.get(Groups.player.find(p -> p.isLocal()));
        TableBuilder cols = table();
        for(Team team : match.teams){
            TableBuilder col = table();
            col.add(label(Txt.col(team) + "◤ " + team.name.toUpperCase() + " ◢").style("techLabel")).growX().padBottom(4f).row();

            Seq<ArenaPlayer> list = match.of(team);
            if(list.isEmpty()){
                col.add(label("[gray]- пусто -[]")).growX().padBottom(2f).row();
            }
            for(ArenaPlayer ap : list){
                String unit;
                boolean hidden = !OneUnit.settings.showEnemyPicks && me != null && me.team != team && match.phase == Match.Phase.draft;
                if(hidden) unit = "[gray]" + m("ui.enemyHidden") + "[]";
                else if(ap.pick == null) unit = "[gray]" + m("ui.noUnit") + "[]";
                else unit = "[accent]" + ap.pick.display() + "[] [gray]T" + ap.pick.tier + "[]";

                String status;
                if(match.phase == Match.Phase.lobby) status = ap.ready ? "[green]" + m("ui.ready") + "[]" : "[gray]" + m("ui.notReady") + "[]";
                else status = ap.alive() ? "[green]" + m("ui.alive") + "[]" : (ap.out ? "[scarlet]" + m("ui.dead") + "[]" : "[gold]" + m("ui.waiting") + "[]");

                col.add(label("[white]" + ap.name() + "[]  " + unit + (lobbyStyle ? "  " + status : ""))).growX().padBottom(2f).align("left").row();
            }
            cols.add(col).width(320f).align("top").pad(6f);
        }
        return cols;
    }

    // ------------------------------------------------------------------ драфт / респавн

    public void draft(Player p){
        ArenaPlayer ap = Match.inst.get(p);
        if(ap == null) return;
        show(p, DRAFT, m("ui.draftTitle"), pickBody(ap, false), true);
    }

    public void respawn(Player p){
        ArenaPlayer ap = Match.inst.get(p);
        if(ap == null) return;
        show(p, RESPAWN, m("ui.respawnTitle"), pickBody(ap, true), true);
    }

    private TableBuilder pickBody(ArenaPlayer ap, boolean isRespawn){
        Match match = Match.inst;
        TableBuilder body = table();

        String info = isRespawn
            ? m("ui.draftInfo", Txt.n(ap.points), ap.lives, Txt.n(Math.max(0f, ap.respawnMenuTimer)))
            : m("ui.draftInfo", Txt.n(ap.points), ap.lives, Txt.n(Math.max(0f, match.timer)));
        body.add(label(info).style("techLabel")).growX().pad(4f).row();
        body.add(label(m("ui.selected", ap.pick == null ? "[gray]" + m("ui.noUnit") + "[]" : "[accent]" + ap.pick.display() + "[] T" + ap.pick.tier))).growX().row();
        body.add(label(m(isRespawn ? "ui.respawnHint" : "ui.draftHint")).wrap().color("gray")).growX().padBottom(6f).row();

        TableBuilder grid = table();
        grid.add(unitGrid(ap, isRespawn, 3).condition("landscape")).growX().row();
        grid.add(unitGrid(ap, isRespawn, 2).condition("portrait")).growX().row();

        body.add(pane().add(grid).growX().style("defaultPane")).height(400f).growX().row();

        TableBuilder buttons = table();
        buttons.add(button(m("ui.rosterTitle")).style("cleart").clicked("roster").width(180f).height(46f));
        buttons.add(button(m("ui.refresh")).style("cleart").clicked("refresh").width(140f).height(46f));
        buttons.add(button(m("ui.close")).style("cleart").clicked("close").width(140f).height(46f));
        body.add(buttons).padTop(8f).row();
        return body;
    }

    private TableBuilder unitGrid(ArenaPlayer ap, boolean isRespawn, int columns){
        Catalog cat = OneUnit.catalog;
        int maxTier = isRespawn ? ap.maxTierAllowed() : OneUnit.settings.draft.maxTier;
        TableBuilder grid = table();
        int col = 0;
        for(int tier = 1; tier <= cat.maxTier; tier++){
            Seq<UnitEntry> list = cat.tier(tier).select(UnitEntry::valid);
            if(list.isEmpty()) continue;

            if(col != 0){
                grid.row();
                col = 0;
            }
            grid.add(label("[accent]" + cat.label(tier) + "[]").style("techLabel")).colspan(columns).growX().padTop(8f).padBottom(4f).align("left").row();

            for(UnitEntry e : list){
                boolean affordable = !isRespawn || e.cost <= ap.points;
                boolean tierOk = e.tier <= maxTier;
                boolean selected = ap.pick == e;
                String text = e.display() + "\n" + (e.cost <= 0 ? "бесплатно" : e.cost + " очк.") + " | HP " + Txt.n(e.maxHp());
                if(!tierOk) text = e.display() + "\n[scarlet]тир закрыт[]";
                else if(!affordable) text = e.display() + "\n[scarlet]" + m("ui.locked") + ": " + e.cost + "[]";

                grid.add(button(text).icon(e.unit)
                    .style(selected ? "fullTogglet" : "cleart")
                    .checked(selected)
                    .disabled(!affordable || !tierOk)
                    .clicked("pick:" + e.id())
                    .width(columns == 3 ? 215f : 190f).height(58f).pad(2f));
                col++;
                if(col >= columns){
                    grid.row();
                    col = 0;
                }
            }
        }
        return grid;
    }

    // ------------------------------------------------------------------ состав / счёт / итоги

    public void roster(Player p){
        TableBuilder body = table();
        body.add(label(m("ui.lobbyInfo", Txt.f(Match.inst.respawnMode ? "modeRespawn" : "modeClassic"), Match.inst.roster.size, Match.inst.mapName)).style("techLabel")).growX().pad(4f).row();
        body.add(teamColumns(false)).growX().row();
        TableBuilder buttons = table();
        buttons.add(button(m("ui.colScore")).style("cleart").clicked("score").width(170f).height(46f));
        buttons.add(button(m("ui.refresh")).style("cleart").clicked("refresh").width(140f).height(46f));
        buttons.add(button(m("ui.close")).style("cleart").clicked("close").width(140f).height(46f));
        body.add(buttons).padTop(8f).row();
        show(p, ROSTER, m("ui.rosterTitle"), body, true);
    }

    public void refreshRosterAll(){
        Groups.player.each(p -> {
            ArenaPlayer ap = Match.inst.get(p);
            if(ap != null && Match.inst.phase == Match.Phase.countdown) roster(p);
        });
    }

    public void score(Player p){
        show(p, SCORE, m("ui.scoreTitle"), scoreBody(), true);
    }

    public void results(Player p){
        TableBuilder body = table();
        body.add(label(m("ui.winner", Match.inst.winner == null ? "[gold]ничья[]" : Txt.team(Match.inst.winner))).style("techLabel")).growX().pad(6f).row();
        body.add(scoreBody()).growX().row();
        TableBuilder buttons = table();
        buttons.add(button(m("ui.close")).style("cleart").clicked("close").width(150f).height(46f));
        body.add(buttons).padTop(8f).row();
        show(p, RESULTS, m("ui.resultsTitle"), body, true);
    }

    private TableBuilder scoreBody(){
        TableBuilder body = table();
        for(Team team : Match.inst.teams){
            Seq<ArenaPlayer> list = Match.inst.of(team);
            if(list.isEmpty()) continue;
            list.sort(a -> -a.kills * 1000 - (int)a.points);

            body.add(label(Txt.col(team) + "◤ " + team.name.toUpperCase() + " ◢").style("techLabel")).growX().padTop(8f).align("left").row();

            TableBuilder head = table();
            head.add(label("[gray]" + m("ui.colPlayer") + "[]")).width(170f).align("left");
            head.add(label("[gray]" + m("ui.colUnit") + "[]")).width(180f).align("left");
            head.add(label("[gray]" + m("ui.colKills") + "[]")).width(60f);
            head.add(label("[gray]" + m("ui.colDeaths") + "[]")).width(60f);
            head.add(label("[gray]" + m("ui.colLives") + "[]")).width(60f);
            head.add(label("[gray]" + m("ui.colScore") + "[]")).width(80f);
            body.add(head).growX().row();

            for(ArenaPlayer ap : list){
                TableBuilder row = table();
                row.add(label("[white]" + ap.name() + "[]")).width(170f).align("left");
                row.add(label(ap.unitName())).width(180f).align("left");
                row.add(label("[green]" + ap.kills + "[]")).width(60f);
                row.add(label("[scarlet]" + ap.deaths + "[]")).width(60f);
                row.add(label("[gold]" + ap.lives + "[]")).width(60f);
                row.add(label("[accent]" + Txt.n(ap.points) + "[]")).width(80f);
                body.add(row).growX().row();
            }
        }
        return body;
    }

    // ------------------------------------------------------------------ помощь

    public void help(Player p){
        TableBuilder body = table();
        String text = """
            [accent]One Unit Arena[] - один юнит, одна жизнь.

            [green]/lobby[] - меню лобби: команды, готовность, старт
            [green]/join [команда][] - войти в лобби
            [green]/leave[] - выйти из лобби
            [green]/pick[] - меню выбора юнита (драфт и респавн)
            [green]/ready[] - готовность
            [green]/roster[] - состав команд (кто на ком играет)
            [green]/score[] - таблица очков
            [green]/mode classic|respawn[] - режим (админ)
            [green]/start[] - запустить матч (админ)

            [accent]Режимы[]
            [gold]Классика[]: одна жизнь. Умер - наблюдаешь. Команда проигрывает, когда выбыли все.
            [gold]War Thunder[]: 3 жизни и очки. За убийства, ассисты, урон и точки дают очки; после смерти покупаешь нового юнита - чем сильнее тир, тем дороже.

            [accent]Управление[]
            Строительство, добыча и вселение в другие юниты отключены. Камера следует за твоим юнитом.
            """;
        body.add(label(text).wrap()).growX().pad(6f).row();
        TableBuilder buttons = table();
        buttons.add(button(m("ui.back")).style("cleart").clicked("lobby").width(150f).height(46f));
        buttons.add(button(m("ui.close")).style("cleart").clicked("close").width(150f).height(46f));
        body.add(buttons).padTop(8f).row();
        show(p, HELP, m("ui.helpTitle"), body, true);
    }

    // ------------------------------------------------------------------ HUD

    public void hudAll(){
        if(!OneUnit.settings.hud.enabled) return;
        Groups.player.each(this::hud);
    }

    public void hud(Player p){
        if(!OneUnit.settings.hud.enabled || p == null || p.con == null) return;
        Match match = Match.inst;
        ArenaPlayer ap = match.get(p);
        String text;

        if(ap == null){
            text = "[accent]One Unit Arena[] | /lobby - войти в лобби";
        }else{
            switch(match.phase){
                case draft -> text = "[accent]ДРАФТ[] " + Txt.time(match.timer) + " | " + m("ui.points") + ": [gold]" + Txt.n(ap.points) + "[] | " +
                    (ap.pick == null ? "[scarlet]/pick[]" : "[green]" + ap.pick.display() + "[]");
                case countdown -> text = "[accent]СТАРТ ЧЕРЕЗ " + Txt.n(match.timer) + "[] | " + ap.unitName();
                case live -> {
                    if(ap.alive()){
                        text = "[accent]" + (ap.pick == null ? "?" : ap.pick.display() + " T" + ap.pick.tier) + "[]" +
                            " | HP [green]" + Txt.n(ap.unit.health) + "[]" +
                            " | " + m("ui.points") + ": [gold]" + Txt.n(ap.points) + "[]" +
                            " | " + m("ui.lives") + ": [gold]" + ap.lives + "[]" +
                            (ap.captureZone.isEmpty() ? "" : " | [accent]" + ap.captureZone + "[]") +
                            " | " + Txt.time(match.timeLeft());
                    }else if(ap.out || ap.lives <= 0){
                        text = "[scarlet]" + m("ui.dead") + "[] | " + m("ui.points") + ": [gold]" + Txt.n(ap.points) + "[] | /roster /score | " + Txt.time(match.timeLeft());
                    }else{
                        text = "[scarlet]Юнит уничтожен[] | " + (ap.respawnTimer > 0 ? "респавн через " + Txt.n(ap.respawnTimer) + "с" : "[accent]/pick[]") +
                            " | " + m("ui.points") + ": [gold]" + Txt.n(ap.points) + "[] | " + m("ui.lives") + ": [gold]" + ap.lives + "[]";
                    }
                }
                case ending -> text = m("ui.winner", match.winner == null ? "[gold]ничья[]" : Txt.team(match.winner)) + " | /score";
                default -> {
                    if(!OneUnit.settings.hud.lobbyHud){
                        Call.hideHudText(p.con);
                        return;
                    }
                    text = "[accent]ЛОББИ[] " + match.roster.size + " игр. | " + Txt.f(match.respawnMode ? "modeRespawn" : "modeClassic") +
                        " | " + (ap.ready ? "[green]готов[]" : "[gray]не готов[]") + " | /lobby";
                }
            }
        }
        Call.setHudText(p.con, text);
    }

    // ------------------------------------------------------------------ обработка кликов

    public void handle(Player p, int menuId, MenuResult res){
        Match match = Match.inst;
        String result = res == null ? null : res.result;
        ArenaPlayer ap = match.get(p);

        if(result == null || result.isEmpty()){
            // диалог закрыли крестиком
            if(ap != null && menuId == RESPAWN) ap.menuOpen = false;
            return;
        }

        if(result.equals("close")){
            close(p, menuId);
            if(ap != null && menuId == RESPAWN) ap.menuOpen = false;
            return;
        }

        switch(result){
            case "join" -> {
                match.join(p, null);
                update(p, LOBBY, lobbyBody(p));
            }
            case "leave" -> {
                match.leave(p);
                close(p, LOBBY);
            }
            case "ready" -> {
                match.toggleReady(p);
                update(p, LOBBY, lobbyBody(p));
            }
            case "start" -> {
                if(!p.admin){
                    Txt.send(p, "notAdmin");
                    return;
                }
                close(p, LOBBY);
                match.startDraft(p);
            }
            case "mode" -> {
                if(!p.admin){
                    Txt.send(p, "notAdmin");
                    return;
                }
                match.setMode(!match.respawnMode);
                update(p, LOBBY, lobbyBody(p));
            }
            case "roster" -> roster(p);
            case "score" -> score(p);
            case "help" -> help(p);
            case "lobby" -> lobby(p);
            case "refresh" -> {
                switch(menuId){
                    case LOBBY -> update(p, LOBBY, lobbyBody(p));
                    case DRAFT -> {
                        if(ap != null) update(p, DRAFT, pickBody(ap, false));
                    }
                    case RESPAWN -> {
                        if(ap != null) update(p, RESPAWN, pickBody(ap, true));
                    }
                    case ROSTER -> roster(p);
                    case SCORE -> update(p, SCORE, scoreBody());
                    default -> { }
                }
            }
            default -> {
                if(result.startsWith("team:")){
                    match.setTeam(p, result.substring(5));
                    update(p, LOBBY, lobbyBody(p));
                }else if(result.startsWith("pick:")){
                    String id = result.substring(5);
                    boolean wasRespawn = menuId == RESPAWN;
                    match.pick(p, id);
                    if(!wasRespawn && match.phase == Match.Phase.draft){
                        update(p, DRAFT, pickBody(match.get(p), false));
                    }
                }
            }
        }
    }
}
