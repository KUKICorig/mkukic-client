package oneunit;

import arc.struct.*;
import mindustry.game.*;
import mindustry.gen.*;

/** Состояние одного участника матча. Живёт на сервере, клиенту уходят только UI-обновления. */
public class ArenaPlayer{
    public Player player;
    public String uuid;
    public Team team;

    public boolean ready;
    /** Выбыл: нет жизней / подключился во время матча. */
    public boolean out;
    public UnitEntry pick;
    public UnitEntry firstPick;
    public Unit unit;

    public float points;
    public int lives;
    public int kills, assists, deaths;
    public float damage;
    public int captures;

    /** Таймер до открытия меню респавна (-1 - не активен). */
    public float respawnTimer = -1f;
    /** Таймер автопика в открытом меню респавна (-1 - не активен). */
    public float respawnMenuTimer = -1f;
    public boolean menuOpen;
    /** Какая вкладка тира открыта в меню выбора. */
    public int viewTier = 1;

    /** Кто и сколько урона нанёс этому игроку (для киллера/ассистов). */
    public transient ObjectMap<ArenaPlayer, Float> incoming = new ObjectMap<>();
    public transient ObjectMap<ArenaPlayer, Float> incomingTime = new ObjectMap<>();

    public float effectTimer, captureTimer;
    public int spawnIndex;
    public String captureZone = "";

    public ArenaPlayer(Player player, Team team){
        this.player = player;
        this.uuid = player.uuid();
        this.team = team;
    }

    public String name(){
        return player == null ? "?" : player.name;
    }

    public boolean connected(){
        return player != null && player.con != null && player.isAdded();
    }

    public boolean alive(){
        return unit != null && unit.isAdded() && !unit.dead();
    }

    /** Может ещё вернуться в бой (жив или есть жизни). */
    public boolean fighting(){
        return alive() || (!out && lives > 0);
    }

    public boolean spectator(){
        return out || (!alive() && lives <= 0);
    }

    public String unitName(){
        return pick == null ? Txt.f("ui.noUnit") : pick.display() + " [gray](T" + pick.tier + ")[]";
    }

    /** Итоговый счёт для сортировки таблицы. */
    public float score(){
        return points + kills * 50f + assists * 20f;
    }

    public void resetMatchStats(boolean respawnMode){
        Settings.Respawn r = OneUnit.settings.respawn;
        points = respawnMode ? r.startPoints : 0f;
        lives = respawnMode ? r.lives : 1;
        kills = assists = deaths = captures = 0;
        damage = 0f;
        out = false;
        pick = null;
        firstPick = null;
        unit = null;
        respawnTimer = respawnMenuTimer = -1f;
        menuOpen = false;
        spawnIndex = 0;
        captureZone = "";
        captureTimer = 0f;
        viewTier = Math.max(1, OneUnit.settings.draft.defaultTier);
        incoming.clear();
        incomingTime.clear();
    }

    /** Запоминает урон от атакующего. */
    public void hit(ArenaPlayer from, float amount, float now){
        incoming.put(from, incoming.get(from, 0f) + amount);
        incomingTime.put(from, now);
    }

    public void clearIncoming(){
        incoming.clear();
        incomingTime.clear();
    }

    public int maxTierAllowed(){
        Settings.Respawn r = OneUnit.settings.respawn;
        if(!r.limitTierGrowth || firstPick == null) return OneUnit.catalog.maxTier;
        return Math.min(OneUnit.catalog.maxTier, firstPick.tier + 1);
    }
}
