package oneunit;

import arc.util.*;
import mindustry.*;
import mindustry.game.*;
import mindustry.game.EventType.*;
import mindustry.gen.*;
import mindustry.net.*;

/**
 * Перехват управления: правила карты + покадровая проверка юнита + фильтр действий.
 * Игрок не строит, не добывает, не вселяется в другие юниты/блоки и не спавнится от ядра.
 */
public class Lock{
    /** Ставится, когда плагин сам меняет юнита игрока - чтобы не ловить собственные события. */
    private static boolean applying;

    /** Применяет правила режима к правилам карты (вызывается до logic.play()). */
    public static void apply(Rules r){
        Settings.Tweaks t = OneUnit.settings.tweaks;

        // победа считается плагином, а не ванилой
        r.canGameOver = false;
        r.cleanupDeadTeams = false;
        r.coreCapture = false;

        // pvp нужен для команд, но авто-пауза ломает арены без ядер
        r.pvp = true;
        r.pvpAutoPause = false;
        r.pauseDisabled = true;

        // никаких волн
        r.waves = false;
        r.waveSending = false;
        r.attackMode = false;
        r.spawns.clear();

        // запрет строительства/добычи/вселения
        r.possessionAllowed = !t.blockPossession;
        r.schematicsAllowed = !t.disableSchematics;
        r.buildSpeedMultiplier = t.removeBuilding ? 0f : 1f;
        r.unitBuildSpeedMultiplier = t.removeBuilding ? 0f : 1f;
        r.unitMineSpeedMultiplier = t.removeMining ? 0f : 1f;
        r.instantBuild = false;
        r.infiniteResources = false;
        r.loadout.clear();

        r.bannedBlocks.clear();
        if(t.removeBuilding){
            r.bannedBlocks.addAll(Vars.content.blocks());
        }

        // логика не должна отбирать юнитов
        r.logicUnitControl = !t.disableLogicControl;
        r.logicUnitBuild = false;
        r.logicUnitDeconstruct = false;
        r.disableWorldProcessors = t.disableWorldProcessors;

        // лимиты юнитов не должны убивать наших бойцов
        r.unitCap = t.unitCap;
        r.disableUnitCap = true;

        r.hideSpawns = t.hideSpawns;
        r.fire = t.fire;
        r.reactorExplosions = t.reactorExplosions;
        r.fog = false;
        r.staticFog = false;
    }

    /**
     * Серверный фильтр действий. Ставится один раз при загрузке плагина.
     * Отклоняет попытки строить/ломать/конфигурировать/таскать полезную нагрузку у участников матча.
     */
    public static void installActionFilter(){
        Vars.netServer.admins.addActionFilter(action -> {
            Player p = action.player;
            if(p == null) return true;
            Match match = Match.inst;
            if(match == null || !match.inMatch()) return true;
            ArenaPlayer ap = match.get(p);
            if(ap == null) return true;

            Settings.Tweaks t = OneUnit.settings.tweaks;
            return switch(action.type){
                case placeBlock, breakBlock, rotate, buildSelect, removePlanned -> !t.removeBuilding;
                case configure, withdrawItem, depositItem -> !t.removeBuilding;
                case pickupBlock, dropPayload -> !t.blockPayloads;
                case control -> !t.blockPossession;
                case command, commandUnits, commandBuilding -> !t.blockUnitCommands;
                // ванильный респавн от ядра запрещён - респавном управляет плагин
                case respawn -> false;
                default -> true;
            };
        });
    }

    /** Покадровая защита: контроль, планы стройки, добыча, команда. */
    public static void tick(ArenaPlayer ap){
        Unit u = ap.unit;
        if(u == null || !u.isAdded() || ap.player == null) return;

        if(u.plans != null && u.plans.size > 0) u.plans.clear();
        if(u.buildPlan() != null) u.updateBuilding(false);
        if(u.mineTile != null) u.mineTile(null);
        if(u.team() != ap.team) u.team(ap.team);

        // игрока могло "выкинуть" из юнита (смерть, вселение, пакет) - возвращаем
        if(ap.player.unit() != u){
            setUnit(ap, u);
        }
    }

    /** Назначает юнита игроку, не вызывая рекурсию через UnitChangeEvent. */
    public static void setUnit(ArenaPlayer ap, Unit unit){
        if(ap.player == null || !ap.player.isAdded()) return;
        applying = true;
        try{
            if(unit == null){
                ap.player.clearUnit();
            }else{
                ap.player.unit(unit);
            }
        }finally{
            applying = false;
        }
    }

    /** Игрок пытается сменить юнита (вселение, выход из юнита, смерть). */
    public static void onUnitChange(Player player, Unit unit){
        if(applying || player == null) return;
        Match match = Match.inst;
        if(match == null || !match.inMatch()) return;
        ArenaPlayer ap = match.get(player);
        if(ap == null) return;

        if(ap.unit != null && ap.unit.isAdded() && unit != ap.unit){
            // возвращаем своего бойца
            setUnit(ap, ap.unit);
        }else if(ap.unit == null && unit != null){
            // выбыл или ждёт респавна - юнитов быть не должно
            setUnit(ap, null);
        }
    }

    /** Блокировка выделения плана стройки. */
    public static void onBuildSelect(BuildSelectEvent e){
        if(!OneUnit.settings.tweaks.removeBuilding) return;
        Match match = Match.inst;
        if(match == null || !match.inMatch() || e.builder == null) return;
        ArenaPlayer ap = match.byUnit.get(e.builder.id());
        if(ap == null) return;
        e.builder.plans.clear();
        e.builder.updateBuilding(false);
    }

    /** Блокировка настройки блоков (сортировки, процессоры и т.п.). */
    public static void onConfig(ConfigEvent e){
        if(!OneUnit.settings.tweaks.removeBuilding) return;
        Match match = Match.inst;
        if(match == null || !match.inMatch() || e.player == null) return;
        if(match.get(e.player) != null && e.tile != null){
            Call.tileConfig(e.player.con, e.tile, null);
        }
    }

    /** Блокировка подъёма блоков/юнитов грузовыми юнитами. */
    public static void onPickup(PickupEvent e){
        if(!OneUnit.settings.tweaks.blockPayloads) return;
        Match match = Match.inst;
        if(match == null || !match.inMatch() || e.carrier == null) return;
        if(match.byUnit.get(e.carrier.id()) != null){
            e.carrier.clearPayload();
        }
    }
}
