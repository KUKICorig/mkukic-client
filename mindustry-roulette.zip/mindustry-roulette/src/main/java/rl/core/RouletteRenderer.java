package rl.core;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * Отрисовка «крутящейся» ленты рулетки для чата Mindustry.
 *
 * Лента собирается заранее, последний кадр всегда центрирует символ-результат,
 * поэтому анимация честная: что показали — то и выпало.
 */
public final class RouletteRenderer {

    private RouletteRenderer() {}

    /** Разбивает строку на «символы» с учётом эмодзи (_variation selectors, ZWJ, суррогаты). */
    public static List<String> splitSymbols(String s) {
        List<String> out = new ArrayList<>();
        if (s == null || s.isEmpty()) return out;
        int i = 0;
        while (i < s.length()) {
            int cp = s.codePointAt(i);
            int len = Character.charCount(cp);
            StringBuilder cur = new StringBuilder(s.substring(i, i + len));
            i += len;
            // приклеиваем следующие не-самостоятельные коды (VS16, ZWJ, скин-тоны, региональные флаги)
            while (i < s.length()) {
                int cp2 = s.codePointAt(i);
                int len2 = Character.charCount(cp2);
                if (cp2 == 0xFE0F || cp2 == 0xFE0E || cp2 == 0x200D
                        || (cp2 >= 0x1F3FB && cp2 <= 0x1F3FF)
                        || (cp2 >= 0x20E3 && cp2 <= 0x20E3)
                        || (cp2 >= 0x1F1E6 && cp2 <= 0x1F1FF && cur.length() <= 4)) {
                    cur.append(s, i, i + len2);
                    i += len2;
                    if (cp2 == 0x200D && i < s.length()) {
                        int len3 = Character.charCount(s.codePointAt(i));
                        cur.append(s, i, i + len3);
                        i += len3;
                    }
                } else {
                    break;
                }
            }
            out.add(cur.toString());
        }
        return out;
    }

    /**
     * @return кадры анимации (без последнего «финального» кадра — он собирается отдельно).
     */
    public static List<String> frames(Config cfg, List<Segment> segs, Segment result, long nonce, String who) {
        List<String> out = new ArrayList<>();
        List<String> syms = symbolsOf(cfg, segs);
        if (syms.isEmpty()) syms.add("❔");
        int window = Math.max(3, cfg.animation.window);
        if (window % 2 == 0) window++;
        int half = window / 2;
        int frames = Math.max(1, cfg.animation.frames);

        String resultSym = result != null ? result.symbol : syms.get(0);
        if (!syms.contains(resultSym)) syms.add(resultSym);

        // лента: достаточно длинная, чтобы «прокрутить» frames шагов
        int len = frames + window + 2;
        Random rnd = new Random(nonce * 1_000_003L ^ 0x5DEECE66DL);
        List<String> strip = new ArrayList<>(len);
        for (int i = 0; i < len; i++) strip.add(syms.get(rnd.nextInt(syms.size())));
        int resultIdx = len - half - 1;
        strip.set(resultIdx, resultSym);

        String marker = markerLine(cfg.animation.marker, window);
        String prefix = (who == null || who.isEmpty()) ? "" : who + " ";
        for (int f = 0; f < frames; f++) {
            int start = resultIdx - half - (frames - 1 - f);
            if (start < 0) start = 0;
            out.add(prefix + marker + "\n" + prefix + window(strip, start, window));
        }
        return out;
    }

    /** Финальный кадр: результат по центру + подпись. */
    public static String finalFrame(Config cfg, List<Segment> segs, Segment result, long nonce, String who, String tail) {
        List<String> syms = symbolsOf(cfg, segs);
        if (syms.isEmpty()) syms.add("❔");
        int window = Math.max(3, cfg.animation.window);
        if (window % 2 == 0) window++;
        int half = window / 2;
        String resultSym = result != null ? result.symbol : syms.get(0);
        if (!syms.contains(resultSym)) syms.add(resultSym);

        int len = window + 2;
        Random rnd = new Random(nonce * 7919L ^ 0x2545F491L);
        List<String> strip = new ArrayList<>(len);
        for (int i = 0; i < len; i++) strip.add(syms.get(rnd.nextInt(syms.size())));
        strip.set(half, resultSym);

        String prefix = (who == null || who.isEmpty()) ? "" : who + " ";
        String marker = markerLine(cfg.animation.marker, window);
        StringBuilder sb = new StringBuilder();
        sb.append(prefix).append(marker).append('\n');
        sb.append(prefix).append(window(strip, 0, window));
        if (tail != null && !tail.isEmpty()) sb.append('\n').append(tail);
        return sb.toString();
    }

    private static List<String> symbolsOf(Config cfg, List<Segment> segs) {
        List<String> syms = splitSymbols(cfg.animation.symbols);
        // если секторов больше, чем символов в ленте — добавляем символы секторов,
        // иначе игрок никогда не увидит «свой» сектор в ленте
        for (Segment s : segs) {
            if (s.symbol != null && !s.symbol.isEmpty() && !syms.contains(s.symbol)) syms.add(s.symbol);
        }
        return syms;
    }

    private static String window(List<String> strip, int start, int window) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < window; i++) {
            int idx = start + i;
            if (idx >= 0 && idx < strip.size()) sb.append(strip.get(idx));
            else sb.append(' ');
            if (i < window - 1) sb.append(' ');
        }
        return sb.toString();
    }

    private static String markerLine(String marker, int window) {
        // каждый слот = символ + пробел; указатель ставим под центральный слот
        StringBuilder sb = new StringBuilder();
        int center = window / 2;
        for (int i = 0; i < center; i++) sb.append("  ");
        sb.append(marker == null || marker.isEmpty() ? "▲" : marker);
        return sb.toString();
    }
}
