package rl.core;

/**
 * Планировщик отложенных задач. В бою реализуется через arc.util.Timers
 * (главный поток сервера), в тестах — синхронно.
 */
public interface Scheduler {

    /** Выполнить runnable через delayMs (один раз). */
    void later(long delayMs, Runnable runnable);

    /** Повторять каждые periodMs. */
    void repeat(long periodMs, Runnable runnable);

    /** Синхронный планироватор для тестов: всё выполняется сразу, в том же потоке. */
    Scheduler IMMEDIATE = new Scheduler() {
        @Override public void later(long delayMs, Runnable runnable) { runnable.run(); }
        @Override public void repeat(long periodMs, Runnable runnable) { /* no-op */ }
    };
}
