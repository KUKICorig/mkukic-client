package rl.core;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.SecureRandom;

/**
 * Provably-fair рандом: результат спина однозначно определяется тройкой
 * (serverSeed, clientSeed, nonce) через HMAC-SHA256.
 *
 * Игрокам показывается только SHA-256 от serverSeed (serverSeedHash), поэтому
 * сменить результат «на ходу» нельзя, а после смены сида любой спин проверяется
 * командой /rl verify или в веб-админке.
 */
public final class ProvablyFair {

    private ProvablyFair() {}

    public static String sha256Hex(String data) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            return hex(md.digest(data.getBytes(StandardCharsets.UTF_8)));
        } catch (Exception e) {
            throw new IllegalStateException("SHA-256 unavailable", e);
        }
    }

    public static String hmacSha256Hex(String key, String data) {
        try {
            Mac mac = Mac.getInstance("HmacSHA256");
            mac.init(new SecretKeySpec(key.getBytes(StandardCharsets.UTF_8), "HmacSHA256"));
            return hex(mac.doFinal(data.getBytes(StandardCharsets.UTF_8)));
        } catch (Exception e) {
            throw new IllegalStateException("HmacSHA256 unavailable", e);
        }
    }

    public static String hex(byte[] b) {
        StringBuilder sb = new StringBuilder(b.length * 2);
        for (byte x : b) sb.append(String.format("%02x", x));
        return sb.toString();
    }

    /** Случайный serverSeed (64 hex-символа). */
    public static String newServerSeed() {
        byte[] b = new byte[32];
        new SecureRandom().nextBytes(b);
        return hex(b);
    }

    /**
     * @return double в [0, 1) — детерминированная «рулеточная» величина.
     */
    public static double roll(String serverSeed, String clientSeed, long nonce) {
        String hash = hmacSha256Hex(serverSeed, clientSeed + ":" + nonce);
        // берём первые 13 hex-символов (52 бита) — мантисса double всё равно 53 бита
        long v = Long.parseUnsignedLong(hash.substring(0, 13), 16);
        return (v >>> 12) / (double) (1L << 52);
    }

    /** Индекс сектора по весам (weights.length > 0, сумма > 0). */
    public static int pickIndex(double roll, double[] weights) {
        double total = 0;
        for (double w : weights) total += w;
        if (total <= 0) return 0;
        double target = Math.min(Math.max(roll, 0.0), 0.9999999999) * total;
        double acc = 0;
        for (int i = 0; i < weights.length; i++) {
            acc += weights[i];
            if (target < acc) return i;
        }
        return weights.length - 1;
    }
}
