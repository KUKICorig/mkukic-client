package oneunit;

import arc.files.*;

/**
 * Глобальные ссылки режима. Заполняется в {@link OneUnitPlugin#init()}.
 * Все вычисления идут на сервере; клиенту уходят только UI-пакеты.
 */
public class OneUnit{
    public static final String VERSION = "1.1.0";

    /** settings.json */
    public static Settings settings = new Settings();
    /** units.json */
    public static Catalog catalog = new Catalog();
    /** messages.json */
    public static Messages msg = Messages.create();
    /** Папка конфигов плагина. */
    public static Fi dir;
}
