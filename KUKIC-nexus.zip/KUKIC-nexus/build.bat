@echo off
rem Сборка MKUKIC Client одной командой (Windows).
rem   build.bat            - проверки + тесты + dist\MKUKICClient.jar
rem   build.bat fast       - то же без тестов
rem   build.bat install    - собрать и положить в папку модов игры
rem   build.bat test       - только тесты
rem   build.bat info       - что найдено: JDK, Android SDK, папка модов
rem   build.bat clean      - очистить build и dist
chcp 65001 >nul
setlocal
cd /d "%~dp0"

where java >nul 2>nul
if errorlevel 1 (
  echo Не найдена Java. Нужен JDK 17 или новее: https://adoptium.net
  goto :end
)

set "TASK=dist"
set "EXTRA="
if /i "%~1"=="fast"    ( set "TASK=dist" & set "EXTRA=-PskipTests" )
if /i "%~1"=="install" set "TASK=installMod"
if /i "%~1"=="test"    set "TASK=runTests"
if /i "%~1"=="info"    set "TASK=buildInfo -q"
if /i "%~1"=="clean"   set "TASK=clean"

call gradlew.bat %TASK% %EXTRA%
if errorlevel 1 (
  echo.
  echo === СБОРКА НЕ УДАЛАСЬ — смотри ошибку выше ===
) else (
  echo.
  echo === Готово ===
)

:end
rem Если запущено двойным кликом — не закрывать окно сразу.
echo %cmdcmdline% | find /i "/c" >nul && pause
endlocal
