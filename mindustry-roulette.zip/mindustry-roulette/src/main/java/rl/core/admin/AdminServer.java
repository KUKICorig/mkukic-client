package rl.core.admin;

import rl.core.Config;
import rl.core.GameLog;
import rl.core.Json;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpServer;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Executors;

/**
 * Встроенный HTTP-сервер админки (com.sun.net.httpserver есть в JDK, зависимостей не добавляет).
 * Отдаёт SPA из ресурсов jar'а и проксирует запросы в {@link AdminApi}.
 */
public class AdminServer {

    public interface Logger {
        void info(String msg);

        void warn(String msg);
    }

    private final AdminApi api;
    private final Config cfg;
    private final GameLog log;
    private final Logger logger;

    private volatile HttpServer server;
    private volatile String boundAddress = "";
    private volatile String lastError = "";

    public AdminServer(AdminApi api, Config cfg, GameLog log, Logger logger) {
        this.api = api;
        this.cfg = cfg;
        this.log = log;
        this.logger = logger;
    }

    public synchronized boolean start() {
        stop();
        if (!cfg.web.enabled) {
            logger.info("[Roulette] веб-админка выключена (web.enabled=false)");
            return false;
        }
        try {
            InetSocketAddress addr = new InetSocketAddress(cfg.web.bind, cfg.web.port);
            HttpServer s = HttpServer.create(addr, 64);
            s.createContext("/", this::handle);
            s.setExecutor(Executors.newFixedThreadPool(4, r -> {
                Thread t = new Thread(r, "roulette-admin");
                t.setDaemon(true);
                return t;
            }));
            s.start();
            server = s;
            boundAddress = addr.getAddress().getHostAddress() + ":" + addr.getPort();
            lastError = "";
            logger.info("[Roulette] веб-админка запущена: http://" + boundAddress + "/ (токен в config.json -> web.token)");
            if ("changeme-roulette-token".equals(cfg.web.token)) {
                logger.warn("[Roulette] ВНИМАНИЕ: web.token не сменён! Зайдите в config.json и поставьте свой токен.");
            }
            return true;
        } catch (Exception e) {
            server = null;
            lastError = String.valueOf(e);
            logger.warn("[Roulette] не удалось поднять веб-админку на " + cfg.web.bind + ":" + cfg.web.port
                    + " — " + e);
            if (log != null) log.log(GameLog.EV_ERROR, Json.obj("where", "admin-server", "error", lastError));
            return false;
        }
    }

    public synchronized void stop() {
        if (server != null) {
            try {
                server.stop(0);
            } catch (Exception ignored) {
            }
            server = null;
        }
    }

    public boolean running() { return server != null; }

    public String boundAddress() { return boundAddress; }

    public String lastError() { return lastError; }

    // ---------------------------------------------------------------- handler

    private void handle(HttpExchange ex) throws IOException {
        long t0 = System.currentTimeMillis();
        AdminApi.Req req = new AdminApi.Req();
        AdminApi.Resp resp;
        try {
            req.method = ex.getRequestMethod();
            String rawPath = ex.getRequestURI().getPath();
            req.path = rawPath == null || rawPath.isEmpty() ? "/" : rawPath;
            req.query = parseQuery(ex.getRequestURI().getRawQuery());
            for (Map.Entry<String, List<String>> e : ex.getRequestHeaders().entrySet()) {
                if (e.getValue() != null && !e.getValue().isEmpty()) {
                    req.headers.put(e.getKey().toLowerCase(), e.getValue().get(0));
                }
            }
            req.ip = clientIp(ex, req.headers);
            req.body = readBody(ex.getRequestBody(), 4 * 1024 * 1024);
            resp = api.handle(req);
        } catch (Exception e) {
            resp = AdminApi.Resp.json(500, Json.obj("ok", false, "error", String.valueOf(e)));
        }

        try {
            if (cfg.web.enableCors) {
                ex.getResponseHeaders().set("Access-Control-Allow-Origin", req.header("origin") == null ? "*" : req.header("origin"));
                ex.getResponseHeaders().set("Access-Control-Allow-Credentials", "true");
                ex.getResponseHeaders().set("Access-Control-Allow-Headers", "Content-Type, X-Admin-Token");
                ex.getResponseHeaders().set("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS");
            }
            for (String c : resp.cookies) ex.getResponseHeaders().add("Set-Cookie", c);
            if ("OPTIONS".equalsIgnoreCase(req.method)) {
                ex.getResponseHeaders().set("Allow", "GET, POST, OPTIONS");
                ex.sendResponseHeaders(204, -1);
                ex.close();
                return;
            }
            ex.getResponseHeaders().set("Content-Type", resp.type);
            ex.getResponseHeaders().set("X-Content-Type-Options", "nosniff");
            ex.getResponseHeaders().set("X-Frame-Options", "SAMEORIGIN");
            ex.getResponseHeaders().set("Referrer-Policy", "no-referrer");
            ex.getResponseHeaders().set("Cache-Control", resp.type.startsWith("text/html") || resp.type.contains("javascript")
                    ? "no-store" : "no-cache");
            byte[] out = resp.body.getBytes(StandardCharsets.UTF_8);
            ex.sendResponseHeaders(resp.status, out.length == 0 ? -1 : out.length);
            if (out.length > 0) {
                try (OutputStream os = ex.getResponseBody()) {
                    os.write(out);
                }
            }
        } finally {
            ex.close();
        }

        if (log != null && req.path.startsWith("/api/") && !"/api/health".equals(req.path)) {
            log.log(GameLog.EV_WEB, Json.obj("action", "request", "method", req.method, "path", req.path,
                    "status", resp.status, "ip", req.ip, "ms", System.currentTimeMillis() - t0));
        }
    }

    private static String clientIp(HttpExchange ex, Map<String, String> headers) {
        String fwd = headers.get("x-forwarded-for");
        if (fwd != null && !fwd.isEmpty()) return fwd.split(",")[0].trim();
        InetSocketAddress a = ex.getRemoteAddress();
        return a == null ? "" : a.getAddress().getHostAddress();
    }

    private static Map<String, String> parseQuery(String q) {
        Map<String, String> out = new LinkedHashMap<>();
        if (q == null || q.isEmpty()) return out;
        for (String part : q.split("&")) {
            if (part.isEmpty()) continue;
            int i = part.indexOf('=');
            String k = i < 0 ? part : part.substring(0, i);
            String v = i < 0 ? "" : part.substring(i + 1);
            out.put(urlDecode(k), urlDecode(v));
        }
        return out;
    }

    private static String urlDecode(String s) {
        try {
            return java.net.URLDecoder.decode(s, "UTF-8");
        } catch (Exception e) {
            return s;
        }
    }

    private static String readBody(InputStream in, int max) throws IOException {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        byte[] buf = new byte[8192];
        int r, total = 0;
        while ((r = in.read(buf)) > 0) {
            total += r;
            if (total > max) throw new IOException("body too large");
            out.write(buf, 0, r);
        }
        return new String(out.toByteArray(), StandardCharsets.UTF_8);
    }
}
