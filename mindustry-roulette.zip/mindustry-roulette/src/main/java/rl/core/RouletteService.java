package rl.core;

import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * Сервис рулетки: приём ставок, анимация, расчёт, выплаты, лимиты, логирование.
 * Не знает ничего про Mindustry — работает с ID и строками.
 */
public class RouletteService {

    private static final DecimalFormat MONEY =
            new DecimalFormat("#,##0", DecimalFormatSymbols.getInstance(Locale.US));

    /** Одна ставка в процессе (или в очереди). */
    public static class PendingSpin {
        public final String id;
        public final String nick;
        public final long bet;
        public final SpinResult result;
        public final String clientSeed;
        public final long startedAt;

        PendingSpin(String id, String nick, long bet, SpinResult result, String clientSeed) {
            this.id = id;
            this.nick = nick;
            this.bet = bet;
            this.result = result;
            this.clientSeed = clientSeed;
            this.startedAt = System.currentTimeMillis();
        }

        public Map<String, Object> toMap() {
            return Json.obj("id", id, "bet", bet, "startedAt", startedAt,
                    "nonce", result.nonce, "segment", result.segment.symbol,
                    "multiplier", result.multiplier);
        }
    }

    private final Config cfg;
    private final AccountStore store;
    private final GameLog log;
    private final RouletteEngine engine;
    private final Scheduler scheduler;
    private final Messenger messenger;

    private final Object lock = new Object();
    private PendingSpin active;
    private final Deque<PendingSpin> queue = new ArrayDeque<>();
    private final List<String> activeIds = new ArrayList<>();

    public RouletteService(Config cfg, AccountStore store, GameLog log, RouletteEngine engine,
                           Scheduler scheduler, Messenger messenger) {
        this.cfg = cfg;
        this.store = store;
        this.log = log;
        this.engine = engine;
        this.scheduler = scheduler;
        this.messenger = messenger;
    }

    public Config config() { return cfg; }

    public AccountStore store() { return store; }

    public GameLog log() { return log; }

    public RouletteEngine engine() { return engine; }

    public static String money(long v) { return MONEY.format(v); }

    // ------------------------------------------------------------- команда /rl

    /** Ставка напрямую (команда /rl <сумма>). */
    public void bet(String id, String nick, String amountRaw) {
        long amount = parseAmount(amountRaw);
        if (amount <= 0) {
            say(id, fill(cfg.messages.unknownId, "house", cfg.general.houseId));
            deny(id, nick, "bad_amount", amountRaw);
            return;
        }
        placeBet(id, nick, amount);
    }

    /**
     * /pay <id> <сумма>: если id == ID бота — это ставка, иначе обычный перевод
     * между игроками (если включён).
     */
    public void pay(String fromId, String fromNick, String toIdRaw, String amountRaw) {
        long amount = parseAmount(amountRaw);
        String toId = toIdRaw == null ? "" : toIdRaw.trim();
        if (amount <= 0 || toId.isEmpty()) {
            say(fromId, fill(cfg.messages.unknownId, "house", cfg.general.houseId));
            deny(fromId, fromNick, "bad_pay", toId + " " + amountRaw);
            return;
        }
        if (isHouse(toId)) {
            placeBet(fromId, fromNick, amount);
            return;
        }
        transfer(fromId, fromNick, toId, amount);
    }

    public boolean isHouse(String id) {
        return id != null && (id.equalsIgnoreCase(cfg.general.houseId) || id.equalsIgnoreCase("HOUSE"));
    }

    public void transfer(String fromId, String fromNick, String toId, long amount) {
        if (!cfg.commands.allowTransfers) {
            say(fromId, fill(cfg.messages.unknownId, "house", cfg.general.houseId));
            return;
        }
        AccountStore.Account from = store.getOrCreate(fromId, cfg.economy.startingBalance, cfg.fair.defaultClientSeed);
        double fee = Math.max(0, cfg.commands.transferFeePercent) / 100.0;
        long feeAmount = (long) Math.floor(amount * fee);
        long total = amount + feeAmount;
        synchronized (lock) {
            if (!store.transfer(fromId, toId, amount)) {
                say(fromId, fill(cfg.messages.transferNoFunds, "balance", money(from.balance)));
                deny(fromId, fromNick, "transfer_no_funds", toId + " " + amount);
                return;
            }
            if (feeAmount > 0) {
                store.withdraw(fromId, feeAmount);
                store.deposit(cfg.general.houseId, feeAmount);
            }
        }
        long bal = store.balance(fromId);
        say(fromId, fill(cfg.messages.transferOk,
                "amount", money(amount), "to", toId, "balance", money(bal),
                "fee", money(feeAmount)));
        Map<String, Object> f = Json.obj();
        f.put("id", fromId);
        f.put("nick", fromNick);
        f.put("to", toId);
        f.put("amount", amount);
        f.put("fee", feeAmount);
        f.put("balanceAfter", bal);
        log.log(GameLog.EV_TRANSFER, f);
    }

    /** Пополнить баланс ID (депозит). */
    public void deposit(String id, String nick, long amount, String reason) {
        if (amount <= 0) return;
        store.deposit(id, amount);
        Map<String, Object> f = Json.obj();
        f.put("id", id);
        f.put("nick", nick);
        f.put("amount", amount);
        f.put("balanceAfter", store.balance(id));
        f.put("reason", reason == null ? "deposit" : reason);
        log.log(GameLog.EV_DEPOSIT, f);
    }

    // ------------------------------------------------------------------ ставка

    public void placeBet(String id, String nick, long bet) {
        String today = log.today();
        AccountStore.Account acc = store.getOrCreate(id, cfg.economy.startingBalance, cfg.fair.defaultClientSeed);
        store.rollDayIfNeeded(acc, today);

        if (!cfg.general.enabled) {
            say(id, cfg.messages.prefix + cfg.messages.disabled);
            deny(id, nick, "disabled", bet);
            return;
        }
        if (cfg.limits.bannedIds.contains(id)) {
            say(id, cfg.messages.prefix + cfg.messages.banned);
            deny(id, nick, "banned", bet);
            return;
        }
        if (bet < cfg.betting.minBet) {
            say(id, fill(cfg.messages.betTooSmall, "min", money(cfg.betting.minBet)));
            deny(id, nick, "min_bet", bet);
            return;
        }
        if (bet > cfg.betting.maxBet) {
            say(id, fill(cfg.messages.betTooBig, "max", money(cfg.betting.maxBet)));
            deny(id, nick, "max_bet", bet);
            return;
        }

        synchronized (lock) {
            // кулдаун
            long since = System.currentTimeMillis() - acc.lastSpinAt;
            if (acc.lastSpinAt > 0 && since < cfg.betting.cooldownMs) {
                long sec = Math.max(1, (cfg.betting.cooldownMs - since + 999) / 1000);
                say(id, fill(cfg.messages.cooldown, "sec", String.valueOf(sec)));
                deny(id, nick, "cooldown", bet);
                return;
            }
            // суточные лимиты
            if (cfg.betting.dailyLossLimit > 0 && acc.dayLost >= cfg.betting.dailyLossLimit) {
                say(id, fill(cfg.messages.dailyLoss, "limit", money(cfg.betting.dailyLossLimit)));
                deny(id, nick, "daily_loss", bet);
                return;
            }
            if (cfg.betting.dailyWinLimit > 0 && acc.dayWon >= cfg.betting.dailyWinLimit) {
                say(id, fill(cfg.messages.dailyWin, "limit", money(cfg.betting.dailyWinLimit)));
                deny(id, nick, "daily_win", bet);
                return;
            }
            // баланс
            if (acc.balance < bet) {
                say(id, fill(cfg.messages.notEnough, "id", id, "balance", money(acc.balance),
                        "bet", money(bet)));
                deny(id, nick, "no_funds", bet);
                return;
            }
            // одновременно незакрытых ставок
            int activeForPlayer = 0;
            for (String aid : activeIds) if (aid.equals(id)) activeForPlayer++;
            if (activeForPlayer >= Math.max(1, cfg.betting.maxActiveBetsPerPlayer)) {
                say(id, cfg.messages.prefix + cfg.messages.busy);
                deny(id, nick, "already_spinning", bet);
                return;
            }
            // одна анимация на всех
            if (cfg.betting.oneSpinAtATime && active != null) {
                if (cfg.betting.maxQueue <= 0 || queue.size() >= cfg.betting.maxQueue) {
                    say(id, cfg.messages.prefix + (cfg.betting.maxQueue <= 0
                            ? cfg.messages.busy : cfg.messages.queueFull));
                    deny(id, nick, "busy", bet);
                    return;
                }
            }

            // банкролл дома
            long houseBefore = store.balance(cfg.general.houseId);
            List<Segment> segs = cfg.effectiveSegments();
            double maxMult = 0;
            for (Segment s : segs) maxMult = Math.max(maxMult, s.multiplier);
            long worstPayout = RouletteEngine.payout(bet, maxMult);
            if (houseBefore < worstPayout) {
                if (cfg.economy.houseAutoTopup && cfg.economy.houseTopupAmount > 0) {
                    long need = Math.max(cfg.economy.houseTopupAmount, worstPayout - houseBefore + cfg.economy.houseMinBalance);
                    store.deposit(cfg.general.houseId, need);
                    log.log(GameLog.EV_HOUSE, Json.obj(
                            "id", cfg.general.houseId, "amount", need,
                            "balanceAfter", store.balance(cfg.general.houseId), "reason", "auto_topup"));
                    houseBefore = store.balance(cfg.general.houseId);
                } else {
                    say(id, cfg.messages.prefix + cfg.messages.houseShort);
                    deny(id, nick, "house_short", bet);
                    return;
                }
            }

            // списываем ставку -> в дом
            if (!store.withdraw(id, bet)) {
                say(id, fill(cfg.messages.notEnough, "id", id, "balance", money(acc.balance),
                        "bet", money(bet)));
                deny(id, nick, "no_funds", bet);
                return;
            }
            store.deposit(cfg.general.houseId, bet);

            long nonce = store.nextNonce();
            String clientSeed = (acc.clientSeed == null || acc.clientSeed.isEmpty())
                    ? cfg.fair.defaultClientSeed : acc.clientSeed;
            SpinResult res = engine.spin(cfg, id, clientSeed, nonce, bet, acc.balance - bet, houseBefore + bet);

            PendingSpin ps = new PendingSpin(id, nick, bet, res, clientSeed);
            activeIds.add(id);
            if (cfg.betting.oneSpinAtATime && active != null) {
                queue.addLast(ps);
                say(id, cfg.messages.prefix + "Ставка в очереди (№" + queue.size() + ").");
            } else {
                active = ps;
                startSpin(ps);
            }
        }
        store.saveThrottled(2000);
    }

    // ---------------------------------------------------------------- анимация

    private void startSpin(PendingSpin ps) {
        String who = displayName(ps.nick, ps.id);
        List<Segment> segs = cfg.effectiveSegments();
        Segment seg = ps.result.segment;
        double shownMult = ps.result.multiplier > 0 ? ps.result.multiplier : maxMult(segs);

        Map<String, Object> betLog = Json.obj();
        betLog.put("id", ps.id);
        betLog.put("nick", ps.nick);
        betLog.put("amount", ps.bet);
        betLog.put("nonce", ps.result.nonce);
        betLog.put("seedHash", ps.result.serverSeedHash);
        betLog.put("clientSeed", ps.clientSeed);
        betLog.put("balanceAfter", ps.result.balanceBefore);
        betLog.put("houseAfter", ps.result.houseBefore);
        log.log(GameLog.EV_BET, betLog);

        say(ps.id, fill(cfg.messages.depositOk, "amount", money(ps.bet), "id", ps.id));
        announce(ps.id, cfg.messages.prefix + fill(cfg.messages.spinStart,
                "nick", who, "bet", money(ps.bet), "mult", Config.fmt(shownMult),
                "symbol", seg.symbol), ps.id);

        if (!cfg.animation.enabled) {
            finish(ps);
            return;
        }

        List<String> frames = RouletteRenderer.frames(cfg, segs, seg, ps.result.nonce,
                cfg.animation.showNick ? who : "");
        long step = Math.max(20, cfg.animation.frameMs);
        for (int i = 0; i < frames.size(); i++) {
            final String frame = frames.get(i);
            final int idx = i;
            scheduler.later(step * (long) idx, () -> {
                if (idx == frames.size() - 1) {
                    // последний кадр крутится вместе с финалом — меньше мусора в чате
                    finish(ps);
                } else {
                    announceFrame(ps.id, frame);
                }
            });
        }
        if (frames.isEmpty()) finish(ps);
    }

    private void announceFrame(String id, String frame) {
        if (cfg.animation.privateOnly) say(id, frame);
        else if (cfg.animation.broadcastFrames) broadcast(frame);
        else say(id, frame);
    }

    private void finish(PendingSpin ps) {
        SpinResult r = ps.result;
        String who = displayName(ps.nick, ps.id);
        List<Segment> segs = cfg.effectiveSegments();
        String today = log.today();

        synchronized (lock) {
            AccountStore.Account acc = store.getOrCreate(ps.id, cfg.economy.startingBalance, cfg.fair.defaultClientSeed);
            store.rollDayIfNeeded(acc, today);
            acc.spins++;
            acc.wagered += ps.bet;
            acc.dayWagered += ps.bet;
            acc.lastSpinAt = System.currentTimeMillis();

            if (r.win) {
                store.deposit(ps.id, r.payout);
                store.withdraw(cfg.general.houseId, r.payout);
                acc.wins++;
                acc.won += r.payout;
                acc.dayWon += r.payout;
                acc.bestWin = Math.max(acc.bestWin, r.payout);
            } else {
                acc.lost += ps.bet;
                acc.dayLost += ps.bet;
            }
            r.balanceAfter = store.balance(ps.id);
            r.houseAfter = store.balance(cfg.general.houseId);
        }

        String tail = r.win
                ? fill(cfg.messages.win, "nick", who, "payout", money(r.payout), "bet", money(ps.bet),
                        "mult", Config.fmt(r.multiplier), "symbol", r.segment.symbol,
                        "balance", money(r.balanceAfter))
                : fill(cfg.messages.lose, "nick", who, "bet", money(ps.bet),
                        "symbol", r.segment.symbol, "balance", money(r.balanceAfter));

        String finalFrame = RouletteRenderer.finalFrame(cfg, segs, r.segment, r.nonce,
                cfg.animation.showNick ? who : "", cfg.messages.prefix + tail);
        if (cfg.animation.enabled) {
            if (cfg.animation.privateOnly) say(ps.id, finalFrame);
            else broadcast(finalFrame);
        } else {
            announce(ps.id, cfg.messages.prefix + tail, ps.id);
        }

        Map<String, Object> f = Json.obj();
        f.put("id", ps.id);
        f.put("nick", ps.nick);
        f.put("bet", ps.bet);
        f.put("segment", r.segment.symbol);
        f.put("label", r.segment.name());
        f.put("index", r.index);
        f.put("multiplier", r.multiplier);
        f.put("win", r.win);
        f.put("gross", r.gross);
        f.put("rake", r.rake);
        f.put("payout", r.payout);
        f.put("toHouse", r.toHouse());
        f.put("balanceBefore", r.balanceBefore);
        f.put("balanceAfter", r.balanceAfter);
        f.put("houseBefore", r.houseBefore);
        f.put("houseAfter", r.houseAfter);
        f.put("nonce", r.nonce);
        f.put("seedHash", r.serverSeedHash);
        f.put("clientSeed", r.clientSeed);
        f.put("hash", r.resultHash);
        f.put("roll", r.roll);
        log.log(GameLog.EV_SPIN, f);

        if (r.win) {
            log.log(GameLog.EV_PAYOUT, Json.obj(
                    "id", ps.id, "nick", ps.nick, "amount", r.payout,
                    "nonce", r.nonce, "balanceAfter", r.balanceAfter));
        }

        store.saveThrottled(1000);

        synchronized (lock) {
            activeIds.remove(ps.id);
            if (active == ps) {
                active = null;
                PendingSpin next = queue.pollFirst();
                if (next != null) {
                    active = next;
                    startSpin(next);
                }
            }
        }
    }

    private static double maxMult(List<Segment> segs) {
        double m = 2.0;
        for (Segment s : segs) m = Math.max(m, s.multiplier);
        return m;
    }

    // ------------------------------------------------------------- инфо-команды

    public void showBalance(String id, String nick) {
        AccountStore.Account acc = store.getOrCreate(id, cfg.economy.startingBalance, cfg.fair.defaultClientSeed);
        say(id, fill(cfg.messages.balance, "id", id, "balance", money(acc.balance), "nick", nick));
    }

    public void showHelp(String id) {
        StringBuilder sb = new StringBuilder();
        sb.append("[gold]🎰 Рулетка rawhex[]\n");
        sb.append("[royal]/pay [orange]").append(cfg.general.houseId)
                .append(" <сумма>[royal] — ставка (монеты уходят боту, выигрыш вернётся вам)\n");
        sb.append("[royal]/").append(cfg.commands.bet).append(" <сумма>[[x<множитель>]][royal] — то же самое\n");
        sb.append("[royal]/rl bal[royal] — баланс по вашему ID\n");
        sb.append("[royal]/rl top[royal] — топ по выигрышам\n");
        sb.append("[royal]/rl stats[royal] — ваша статистика\n");
        sb.append("[royal]/rl seed <свой_сид>[royal] — сменить client seed\n");
        sb.append("[royal]/rl verify[royal] — данные последнего спина для проверки\n");
        sb.append("[royal]/rl info[royal] — секторы, RTP, лимиты\n");
        say(id, sb.toString());
    }

    public void showInfo(String id) {
        List<Segment> segs = cfg.effectiveSegments();
        double total = 0;
        for (Segment s : segs) total += s.weight;
        StringBuilder sb = new StringBuilder();
        sb.append("[gold]🎰 Секторы рулетки[] (RTP [orange]").append(cfg.theoreticalRtpPercent())
                .append("%[], шанс выигрыша [orange]").append(cfg.winChancePercent()).append("%[])\n");
        for (Segment s : segs) {
            double p = total > 0 ? s.weight / total * 100.0 : 0;
            sb.append("  ").append(s.symbol).append(" [lightgray]x").append(Config.fmt(s.multiplier))
                    .append(" — ").append(Config.round2(p)).append("%[]\n");
        }
        sb.append("[lightgray]Ставка: ").append(money(cfg.betting.minBet)).append("–")
                .append(money(cfg.betting.maxBet)).append(" 🪙, комиссия ")
                .append(Config.round2(cfg.roulette.rakePercent)).append("%[]");
        say(id, sb.toString());
    }

    public void showStats(String id, String nick) {
        AccountStore.Account a = store.getOrCreate(id, cfg.economy.startingBalance, cfg.fair.defaultClientSeed);
        long net = a.won - a.lost;
        say(id, "[gold]🎰 Статистика ID [orange]" + id + "[]\n"
                + "[lightgray]Баланс:[] " + money(a.balance) + " 🪙\n"
                + "[lightgray]Спинов:[] " + a.spins + "  [lightgray]Побед:[] " + a.wins
                + "  [lightgray]Шанс:[] " + (a.spins > 0 ? Config.round2((double) a.wins / a.spins * 100.0) : 0) + "%\n"
                + "[lightgray]Поставлено:[] " + money(a.wagered) + "  [lightgray]Выиграно:[] " + money(a.won) + "\n"
                + "[lightgray]Лучший выигрыш:[] " + money(a.bestWin) + "\n"
                + "[lightgray]Итог:[] " + (net >= 0 ? "[green]+" : "[scarlet]") + money(net) + "[] 🪙");
    }

    public void showTop(String id, String requesterNick, java.util.function.Function<String, String> idToNick) {
        List<AccountStore.Account> top = store.top("won", 5);
        if (top.isEmpty()) {
            say(id, "[gold]🎰 Топ[] — пока пусто.");
            return;
        }
        StringBuilder sb = new StringBuilder("[gold]🎰 Топ по выигрышам[]\n");
        int i = 1;
        for (AccountStore.Account a : top) {
            String nm = null;
            if (idToNick != null) {
                try { nm = idToNick.apply(a.id); } catch (Exception ignored) {}
            }
            sb.append("  ").append(i++).append(". [orange]").append(a.id).append("[]");
            if (nm != null && !nm.isEmpty()) sb.append(" [lightgray](").append(nm).append(")[]");
            sb.append(" — ").append(money(a.won)).append(" 🪙 / ").append(a.spins).append(" спинов\n");
        }
        say(id, sb.toString());
    }

    public void showVerify(String id, String nick) {
        List<Map<String, Object>> rec = log.recent(50);
        for (Map<String, Object> e : rec) {
            Json.Node n = Json.Node.of(e);
            if (GameLog.EV_SPIN.equals(n.str("event", "")) && id.equals(n.str("id", ""))) {
                say(id, fill(cfg.messages.verify,
                        "nonce", String.valueOf(n.lng("nonce", 0)),
                        "seedHash", n.str("seedHash", ""),
                        "client", n.str("clientSeed", ""),
                        "hash", n.str("hash", "")));
                return;
            }
        }
        say(id, cfg.messages.prefix + "Спинов ещё не было. SeedHash казино: [orange]" + engine.serverSeedHash() + "[]");
    }

    public void setClientSeed(String id, String nick, String seed) {
        if (seed == null) seed = "";
        seed = seed.replaceAll("[^A-Za-z0-9_.:-]", "");
        if (seed.length() > 32) seed = seed.substring(0, 32);
        AccountStore.Account a = store.getOrCreate(id, cfg.economy.startingBalance, cfg.fair.defaultClientSeed);
        synchronized (lock) { a.clientSeed = seed; }
        store.markDirty();
        say(id, cfg.messages.prefix + "Client seed для ID [orange]" + id + "[] установлен: [orange]" + seed + "[]");
        log.log(GameLog.EV_ADMIN, Json.obj("id", id, "nick", nick, "action", "set_client_seed", "value", seed));
    }

    // -------------------------------------------------------------- состояние

    public boolean isSpinning() {
        synchronized (lock) { return active != null; }
    }

    public int queueSize() {
        synchronized (lock) { return queue.size(); }
    }

    public Map<String, Object> stateMap() {
        synchronized (lock) {
            Map<String, Object> m = Json.obj();
            m.put("spinning", active != null);
            m.put("queue", queue.size());
            if (active != null) m.put("active", active.toMap());
            List<Object> q = new ArrayList<>();
            for (PendingSpin p : queue) q.add(p.toMap());
            m.put("queued", q);
            return m;
        }
    }

    /** Разовое начисление дохода (вызывается по таймеру из обвязки). */
    public void tickIncome(java.util.function.BiConsumer<String, String> onlineIds) {
        if (cfg.economy.incomeIntervalMinutes <= 0 || cfg.economy.incomeAmount <= 0) return;
        if (onlineIds == null) return;
        onlineIds.accept(null, null);
    }

    public void grantIncome(String id, String nick) {
        if (cfg.economy.incomeIntervalMinutes <= 0 || cfg.economy.incomeAmount <= 0) return;
        AccountStore.Account a = store.getOrCreate(id, cfg.economy.startingBalance, cfg.fair.defaultClientSeed);
        long intervalMs = cfg.economy.incomeIntervalMinutes * 60_000L;
        if (System.currentTimeMillis() - a.lastIncomeAt < intervalMs) return;
        a.lastIncomeAt = System.currentTimeMillis();
        store.deposit(id, cfg.economy.incomeAmount);
        log.log(GameLog.EV_INCOME, Json.obj("id", id, "nick", nick, "amount", cfg.economy.incomeAmount,
                "balanceAfter", store.balance(id)));
    }

    // ------------------------------------------------------------------ утилиты

    /** Парсит "500", "1.5k", "2m". */
    public static long parseAmount(String raw) {
        if (raw == null) return -1;
        String s = raw.trim().toLowerCase(Locale.US).replace(" ", "").replace("_", "");
        if (s.isEmpty()) return -1;
        double mult = 1;
        char last = s.charAt(s.length() - 1);
        if (last == 'k' || last == 'к') { mult = 1_000; s = s.substring(0, s.length() - 1); }
        else if (last == 'm' || last == 'м') { mult = 1_000_000; s = s.substring(0, s.length() - 1); }
        else if (!Character.isDigit(last) && last != '.') return -1;
        try {
            double v = Double.parseDouble(s);
            if (Double.isNaN(v) || v <= 0) return -1;
            long res = (long) Math.floor(v * mult);
            return res > 0 ? res : -1;
        } catch (Exception e) {
            return -1;
        }
    }

    public static String fill(String template, String... kv) {
        if (template == null) return "";
        String out = template;
        for (int i = 0; i + 1 < kv.length; i += 2) {
            out = out.replace("{" + kv[i] + "}", kv[i + 1] == null ? "" : kv[i + 1]);
        }
        return out;
    }

    private String displayName(String nick, String id) {
        if (cfg.animation.showNick && nick != null && !nick.trim().isEmpty()) return nick.trim();
        if (cfg.general.displayName != null && !cfg.general.displayName.trim().isEmpty()) {
            return cfg.general.displayName.trim();
        }
        return "ID " + id;
    }

    private void say(String id, String message) {
        try {
            messenger.toPlayer(id, message);
        } catch (Exception ignored) {
        }
    }

    private void broadcast(String message) {
        try {
            messenger.broadcast(message);
        } catch (Exception ignored) {
        }
    }

    private void announce(String id, String message, String fallbackId) {
        if (cfg.animation.privateOnly) say(id, message);
        else broadcast(message);
    }

    private void deny(String id, String nick, String reason, Object detail) {
        log.log(GameLog.EV_DENY, Json.obj("id", id, "nick", nick, "reason", reason, "detail", String.valueOf(detail)));
    }
}
