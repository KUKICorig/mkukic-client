package oneunit;

import arc.math.*;
import arc.math.geom.*;
import arc.struct.*;
import arc.util.*;
import mindustry.*;
import mindustry.game.*;
import mindustry.gen.*;
import mindustry.type.*;
import mindustry.world.*;
import mindustry.world.blocks.storage.*;

/**
 * Поиск точек спавна.
 * Приоритет: 1) settings.json -> maps -> spawns, 2) ядра команд на карте, 3) геометрия карты.
 * Дополнительно ищет безопасный тайл (земля не тонет, вода для флота, воздух для летающих).
 */
public class Spawns{
    /** Позиции ядер, снятые до удаления, по командам. */
    public static ObjectMap<Team, Seq<Vec2>> cores = new ObjectMap<>();

    public static void captureCores(){
        cores.clear();
        for(Tile tile : Vars.world.tiles){
            if(tile.block() instanceof CoreBlock && tile.build != null){
                Team t = tile.build.team;
                cores.get(t, Seq::new).add(new Vec2(tile.worldx(), tile.worldy()));
            }
        }
    }

    public static void removeCores(){
        for(Tile tile : Vars.world.tiles){
            if(tile.block() instanceof CoreBlock){
                tile.removeNet();
            }
        }
    }

    public static Settings.MapConfig configFor(String mapName){
        if(mapName == null) return null;
        Settings.MapConfig direct = OneUnit.settings.maps.get(mapName);
        if(direct != null) return direct;
        for(ObjectMap.Entry<String, Settings.MapConfig> e : OneUnit.settings.maps){
            if(e.key.equalsIgnoreCase(mapName) || norm(e.key).equals(norm(mapName))) return e.value;
        }
        return null;
    }

    private static String norm(String s){
        return s.toLowerCase().replace('_', ' ').replace(".msav", "").trim();
    }

    /** Мировые координаты спавна для игрока. */
    public static Vec2 find(ArenaPlayer ap){
        Settings s = OneUnit.settings;
        String mapName = Vars.state.map == null ? Match.inst.mapName : Vars.state.map.plainName();
        Settings.MapConfig cfg = configFor(mapName);
        Vec2 base = null;

        // 1. явные точки из конфига
        if(cfg != null){
            Seq<String> points = cfg.spawns.get(ap.team.name);
            if(points == null){
                for(ObjectMap.Entry<String, Seq<String>> e : cfg.spawns){
                    if(e.key.equalsIgnoreCase(ap.team.name)) points = e.value;
                }
            }
            if(points != null && points.size > 0){
                String raw = points.get(ap.spawnIndex % points.size);
                Vec2 parsed = parse(raw);
                if(parsed != null){
                    Tile tile = Vars.world.tile((int)parsed.x, (int)parsed.y);
                    base = tile == null ? new Vec2(parsed.x * Vars.tilesize, parsed.y * Vars.tilesize) : new Vec2(tile.worldx(), tile.worldy());
                }
            }
        }

        // 2. ядра
        if(base == null){
            Seq<Vec2> list = cores.get(ap.team);
            if(list != null && list.size > 0){
                base = list.get(ap.spawnIndex % list.size).cpy();
            }else if(ap.team.core() != null){
                Building c = ap.team.core();
                base = new Vec2(c.x, c.y);
            }
        }

        // 3. геометрия: команды по кругу вокруг центра карты
        if(base == null){
            int count = Math.max(2, Match.inst.teams.size);
            int index = Math.max(0, Match.inst.teams.indexOf(ap.team));
            float cx = Vars.world.unitWidth() / 2f, cy = Vars.world.unitHeight() / 2f;
            float radius = Math.min(Vars.world.unitWidth(), Vars.world.unitHeight()) * 0.34f;
            float angle = 360f / count * index + 90f;
            base = new Vec2(cx + Mathf.cosDeg(angle) * radius, cy + Mathf.sinDeg(angle) * radius);
        }

        // разброс, чтобы юниты не спавнились в одной точке
        float spread = s.tweaks.spawnSpread * Vars.tilesize;
        if(spread > 0){
            float angle = (ap.spawnIndex * 137.5f) % 360f;
            float len = spread * (0.4f + 0.6f * ((ap.spawnIndex % 3) / 2f));
            base.add(Mathf.cosDeg(angle) * len, Mathf.sinDeg(angle) * len);
        }

        ap.spawnIndex++;
        return safe(ap.pick == null ? null : ap.pick.type, base);
    }

    public static Vec2 parse(String raw){
        if(raw == null) return null;
        String[] parts = raw.split("[,; ]+");
        if(parts.length < 2) return null;
        try{
            return new Vec2(Float.parseFloat(parts[0].trim()), Float.parseFloat(parts[1].trim()));
        }catch(NumberFormatException e){
            return null;
        }
    }

    /** Подбирает ближайший пригодный тайл под тип юнита. */
    public static Vec2 safe(UnitType type, Vec2 pos){
        if(type == null || Vars.world.tiles == null) return pos;
        int tx = World.toTile(pos.x), ty = World.toTile(pos.y);
        boolean flying = type.flying;
        boolean naval = !type.flying && !type.canDrown;

        for(int radius = 0; radius <= 26; radius++){
            for(int dx = -radius; dx <= radius; dx++){
                for(int dy = -radius; dy <= radius; dy++){
                    if(Math.max(Math.abs(dx), Math.abs(dy)) != radius) continue;
                    Tile tile = Vars.world.tile(tx + dx, ty + dy);
                    if(tile == null || tile.solid()) continue;
                    boolean liquid = tile.floor().isLiquid || tile.floor().drownTime > 0;
                    if(flying) return new Vec2(tile.worldx(), tile.worldy());
                    if(naval && liquid) return new Vec2(tile.worldx(), tile.worldy());
                    if(!naval && !liquid) return new Vec2(tile.worldx(), tile.worldy());
                }
            }
        }
        return pos;
    }
}
