package oneunit;

import arc.files.*;
import arc.util.*;
import arc.util.serialization.*;

/** Чтение/создание/сохранение конфигов. Все файлы создаются автоматически при первом запуске. */
public class ConfigIO{
    public static Fi dir;

    private static Json json(){
        Json j = new Json();
        j.setIgnoreUnknownFields(true);
        j.setTypeName(null);
        j.setOutputType(JsonWriter.OutputType.json);
        return j;
    }

    public static void load(Fi folder){
        dir = folder;
        if(!dir.exists()) dir.mkdirs();

        // settings.json
        Fi sf = dir.child("settings.json");
        if(!sf.exists()){
            OneUnit.settings = new Settings();
            write(sf, OneUnit.settings, Settings.class);
            Log.info("[OneUnitArena] Создан @", sf.path());
        }else{
            try{
                OneUnit.settings = json().fromJson(Settings.class, sf.reader());
                if(OneUnit.settings == null) OneUnit.settings = new Settings();
            }catch(Throwable t){
                Log.err("[OneUnitArena] Ошибка чтения settings.json - беру значения по умолчанию.", t);
                OneUnit.settings = new Settings();
            }
        }
        sanitize(OneUnit.settings);

        // units.json
        Fi uf = dir.child("units.json");
        if(!uf.exists()){
            OneUnit.catalog = Catalog.generate();
            write(uf, OneUnit.catalog, Catalog.class);
            Log.info("[OneUnitArena] Создан @ (@ юнитов)", uf.path(), OneUnit.catalog.entries.size);
        }else{
            try{
                OneUnit.catalog = json().fromJson(Catalog.class, uf.reader());
                if(OneUnit.catalog == null || OneUnit.catalog.entries == null || OneUnit.catalog.entries.isEmpty()){
                    OneUnit.catalog = Catalog.generate();
                }
            }catch(Throwable t){
                Log.err("[OneUnitArena] Ошибка чтения units.json - генерирую каталог заново.", t);
                OneUnit.catalog = Catalog.generate();
            }
        }
        OneUnit.catalog.index();

        // messages.json
        Fi mf = dir.child("messages.json");
        if(!mf.exists()){
            OneUnit.msg = Messages.create();
            write(mf, OneUnit.msg, Messages.class);
        }else{
            try{
                OneUnit.msg = json().fromJson(Messages.class, mf.reader());
                if(OneUnit.msg == null) OneUnit.msg = Messages.create();
                if(OneUnit.msg.lines == null) OneUnit.msg.lines = Messages.defaults();
                OneUnit.msg.fillDefaults();
            }catch(Throwable t){
                Log.err("[OneUnitArena] Ошибка чтения messages.json.", t);
                OneUnit.msg = Messages.create();
            }
        }
    }

    /** Минимальная защита от невалидных значений. */
    private static void sanitize(Settings s){
        if(s.teams == null || s.teams.size < 2) s.teams = arc.struct.Seq.with("sharded", "crux");
        if(s.arenaMaps == null) s.arenaMaps = arc.struct.Seq.with("Arena");
        if(s.respawn == null) s.respawn = new Settings.Respawn();
        if(s.hud == null) s.hud = new Settings.Hud();
        if(s.tweaks == null) s.tweaks = new Settings.Tweaks();
        if(s.maps == null) s.maps = new arc.struct.ObjectMap<>();
        if(s.respawn.lives < 1) s.respawn.lives = 1;
        if(s.draftSeconds < 5) s.draftSeconds = 5;
        if(s.countdownSeconds < 0) s.countdownSeconds = 0;
        if(s.hud.interval < 0.1f) s.hud.interval = 0.1f;
        if(!s.defaultMode.equals("classic") && !s.defaultMode.equals("respawn")) s.defaultMode = "respawn";
    }

    public static void saveSettings(){
        write(dir.child("settings.json"), OneUnit.settings, Settings.class);
    }

    public static void saveUnits(){
        write(dir.child("units.json"), OneUnit.catalog, Catalog.class);
    }

    private static void write(Fi file, Object value, Class<?> type){
        try{
            file.writeString(pretty(json().toJson(value, type)));
        }catch(Throwable t){
            Log.err("[OneUnitArena] Не удалось записать @", file.path(), t);
        }
    }

    /** Простой форматировщик JSON с отступами - чтобы конфиги было удобно править руками. */
    public static String pretty(String src){
        StringBuilder out = new StringBuilder();
        int indent = 0;
        boolean inString = false, escape = false;
        for(int i = 0; i < src.length(); i++){
            char c = src.charAt(i);
            if(inString){
                out.append(c);
                if(escape) escape = false;
                else if(c == '\\') escape = true;
                else if(c == '"') inString = false;
                continue;
            }
            switch(c){
                case '"' -> {
                    inString = true;
                    out.append(c);
                }
                case '{', '[' -> {
                    // пустой объект/массив оставляем на одной строке
                    int next = nextNonSpace(src, i + 1);
                    if(next >= 0 && (src.charAt(next) == '}' || src.charAt(next) == ']')){
                        out.append(c).append(src.charAt(next));
                        i = next;
                    }else{
                        out.append(c);
                        indent++;
                        newline(out, indent);
                    }
                }
                case '}', ']' -> {
                    indent = Math.max(0, indent - 1);
                    newline(out, indent);
                    out.append(c);
                }
                case ',' -> {
                    out.append(c);
                    newline(out, indent);
                }
                case ':' -> out.append(": ");
                case ' ', '\n', '\r', '\t' -> { }
                default -> out.append(c);
            }
        }
        return out.append('\n').toString();
    }

    private static int nextNonSpace(String s, int from){
        for(int i = from; i < s.length(); i++){
            if(!Character.isWhitespace(s.charAt(i))) return i;
        }
        return -1;
    }

    private static void newline(StringBuilder out, int indent){
        out.append('\n');
        out.append("  ".repeat(Math.max(0, indent)));
    }
}
