package oneunit;

import arc.struct.*;
import mindustry.type.*;

/** Одна строка units.json: юнит + тир + цена + множители баланса. */
public class UnitEntry{
    /** Тир 1..7. Тиры 6-7 - это усиленные ванильные боссы (см. units.json). */
    public int tier = 1;
    /** Внутреннее имя UnitType (dagger, reign, conquer...). */
    public String unit = "dagger";
    /** Отображаемое имя. Пусто - берётся localizedName юнита. */
    public String name = "";
    /** Цена в очках. 0 - бесплатно (доступен всегда). */
    public int cost = 0;
    /** Множитель максимального здоровья. */
    public float hpMult = 1f;
    /** Множитель исходящего урона (применяется к урону пуль при создании). */
    public float damageMult = 1f;
    public boolean enabled = true;
    /** Категория для группировки в меню: mech/tank/air/leg/naval/support. */
    public String category = "mech";
    /** Ванильные статус-эффекты, которые постоянно освежаются на юните (overclock, shielded...). */
    public Seq<String> effects = new Seq<>();

    // runtime, в json не попадает
    public transient UnitType type;
    public transient Seq<StatusEffect> parsedEffects = new Seq<>();

    public String id(){
        return tier + ":" + unit;
    }

    public String display(){
        if(name != null && !name.isEmpty()) return name;
        if(type != null && type.localizedName != null && !type.localizedName.isEmpty()) return type.localizedName;
        return unit;
    }

    public float maxHp(){
        return type == null ? 0f : type.health * hpMult;
    }

    public boolean valid(){
        return type != null && enabled;
    }
}
