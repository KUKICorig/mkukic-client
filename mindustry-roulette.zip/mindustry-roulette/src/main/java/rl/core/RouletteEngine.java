package rl.core;

import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Движок рулетки: считает сектора, выбирает победителя и считает выплату.
 * Чистая логика без привязки к Mindustry — её можно прогнать в тесте/симуляторе.
 */
public class RouletteEngine {

    private final SecureRandom random = new SecureRandom();
    private final Object lock = new Object();

    private volatile String serverSeed;
    private volatile String serverSeedHash;
    private volatile long seedCreatedAt = System.currentTimeMillis();
    private volatile long spinsWithSeed = 0;

    public RouletteEngine(String serverSeed) {
        setServerSeed(serverSeed == null || serverSeed.isEmpty() ? ProvablyFair.newServerSeed() : serverSeed);
    }

    public void setServerSeed(String seed) {
        synchronized (lock) {
            this.serverSeed = seed;
            this.serverSeedHash = ProvablyFair.sha256Hex(seed);
            this.seedCreatedAt = System.currentTimeMillis();
            this.spinsWithSeed = 0;
        }
    }

    public String rotateSeed() {
        String s = ProvablyFair.newServerSeed();
        setServerSeed(s);
        return s;
    }

    public String serverSeed() { return serverSeed; }

    public String serverSeedHash() { return serverSeedHash; }

    public long seedCreatedAt() { return seedCreatedAt; }

    public long spinsWithSeed() { return spinsWithSeed; }

    // ------------------------------------------------------------------ спины

    /** Симуляция N спинов на «тестовом» сиде (для проверки RTP в админке). */
    public static SimResult simulate(Config cfg, long spins) {
        SimResult r = new SimResult();
        r.spins = spins;
        if (spins <= 0) return r;
        List<Segment> segs = cfg.effectiveSegments();
        double[] w = weights(segs);
        String seed = ProvablyFair.newServerSeed();
        String client = "sim";
        long bet = Math.max(1, cfg.betting.minBet);
        double wagered = 0, paid = 0;
        long bestWin = 0;
        int[] hits = new int[segs.size()];
        for (long i = 1; i <= spins; i++) {
            double roll = ProvablyFair.roll(seed, client, i);
            int idx = ProvablyFair.pickIndex(roll, w);
            hits[idx]++;
            Segment s = segs.get(idx);
            long gross = payout(bet, s.multiplier);
            long rake = (long) Math.floor(gross * clampPct(cfg.roulette.rakePercent) / 100.0);
            long pay = gross - rake;
            wagered += bet;
            paid += pay;
            if (s.isWin()) {
                r.wins++;
                r.wonAmount += pay;
                bestWin = Math.max(bestWin, pay);
            } else {
                r.losses++;
                r.lostAmount += bet;
            }
        }
        r.bestWin = bestWin;
        r.rtp = wagered > 0 ? Config.round2(paid / wagered * 100.0) : 0;
        r.winRate = Config.round2((double) r.wins / spins * 100.0);
        r.theoreticalRtp = cfg.theoreticalRtpPercent();
        r.segmentHits = new ArrayList<>();
        for (int i = 0; i < segs.size(); i++) {
            Segment s = segs.get(i);
            r.segmentHits.add(Json.obj(
                    "symbol", s.symbol,
                    "label", s.name(),
                    "multiplier", s.multiplier,
                    "weight", s.weight,
                    "expectedPercent", Config.round2(w[i] / total(w) * 100.0),
                    "hits", hits[i],
                    "actualPercent", Config.round2((double) hits[i] / spins * 100.0)));
        }
        return r;
    }

    public static class SimResult {
        public long spins;
        public long wins;
        public long losses;
        public long wonAmount;
        public long lostAmount;
        public long bestWin;
        public double rtp;
        public double winRate;
        public double theoreticalRtp;
        public List<Object> segmentHits = new ArrayList<>();

        public Map toMap() {
            return Json.obj(
                    "spins", spins,
                    "wins", wins,
                    "losses", losses,
                    "wonAmount", wonAmount,
                    "lostAmount", lostAmount,
                    "bestWin", bestWin,
                    "rtp", rtp,
                    "winRate", winRate,
                    "theoreticalRtp", theoreticalRtp,
                    "segments", segmentHits);
        }
    }

    // ---------------------------------------------------------------- расчёты

    public static double[] weights(List<Segment> segs) {
        double[] w = new double[segs.size()];
        for (int i = 0; i < segs.size(); i++) w[i] = Math.max(0, segs.get(i).weight);
        return w;
    }

    public static double total(double[] w) {
        double t = 0;
        for (double x : w) t += x;
        return t;
    }

    public static double clampPct(double v) {
        if (Double.isNaN(v)) return 0;
        return Math.max(0, Math.min(90, v));
    }

    /** Выплата до комиссии: ставка * множитель, округление вниз, не больше Long.MAX/2. */
    public static long payout(long bet, double multiplier) {
        if (multiplier <= 0 || bet <= 0) return 0;
        double v = bet * multiplier;
        if (v > Long.MAX_VALUE / 2) return Long.MAX_VALUE / 2;
        return (long) Math.floor(v);
    }

    /**
     * Полный расчёт спина: выбирает сектор и считает деньги. НИЧЕГО не меняет —
     * применяется к хранилищу отдельно (см. RouletteService).
     */
    public SpinResult spin(Config cfg, String playerId, String clientSeed, long nonce,
                           long bet, long balanceBefore, long houseBefore) {
        List<Segment> segs = cfg.effectiveSegments();
        double[] w = weights(segs);
        String cs = (clientSeed == null || clientSeed.isEmpty()) ? cfg.fair.defaultClientSeed : clientSeed;

        SpinResult r = new SpinResult();
        r.nonce = nonce;
        r.clientSeed = cs;
        r.bet = bet;
        r.balanceBefore = balanceBefore;
        r.houseBefore = houseBefore;

        double roll;
        int idx;
        if (cfg.fair.enabled) {
            synchronized (lock) {
                r.serverSeedHash = serverSeedHash;
                roll = ProvablyFair.roll(serverSeed, cs, nonce);
                r.resultHash = ProvablyFair.hmacSha256Hex(serverSeed, cs + ":" + nonce);
                spinsWithSeed++;
            }
        } else {
            roll = random.nextDouble();
            r.serverSeedHash = "";
            r.resultHash = "";
        }
        idx = ProvablyFair.pickIndex(roll, w);
        r.roll = roll;
        r.index = idx;
        r.segment = segs.get(idx);
        r.win = r.segment.isWin();
        r.multiplier = r.segment.multiplier;

        r.gross = payout(bet, r.multiplier);
        r.rake = (long) Math.floor(r.gross * clampPct(cfg.roulette.rakePercent) / 100.0);
        if (r.rake > r.gross) r.rake = r.gross;
        r.payout = r.gross - r.rake;

        // деньги: ставка уже ушла в дом, выплата возвращается игроку из дома
        r.balanceAfter = balanceBefore - bet + r.payout;
        r.houseAfter = houseBefore + bet - r.payout - r.rake;
        // комиссия казино — это часть дома, возвращаем её в дом
        r.houseAfter += r.rake;
        return r;
    }
}
