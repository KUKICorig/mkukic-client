package oneunit;

import arc.graphics.*;
import arc.util.*;
import mindustry.game.*;
import mindustry.gen.*;

/** Мелкие помощники вывода текста. */
public class Txt{
    public static String pre(){
        return OneUnit.msg.get("prefix");
    }

    public static void send(Player p, String key, Object... args){
        if(p == null) return;
        p.sendMessage(pre() + OneUnit.msg.f(key, args));
    }

    public static void raw(Player p, String text){
        if(p == null) return;
        p.sendMessage(pre() + text);
    }

    public static void all(String key, Object... args){
        String s = pre() + OneUnit.msg.f(key, args);
        Call.sendMessage(s);
        Log.info(Strings.stripColors(s));
    }

    public static String f(String key, Object... args){
        return OneUnit.msg.f(key, args);
    }

    public static String hex(Color c){
        return String.format("%02x%02x%02x", (int)(c.r * 255), (int)(c.g * 255), (int)(c.b * 255));
    }

    public static String col(Team team){
        return "[#" + hex(team.color) + "]";
    }

    public static String team(Team team){
        return col(team) + team.name.toUpperCase() + "[]";
    }

    public static String time(float seconds){
        int s = Math.max(0, (int)Math.ceil(seconds));
        return (s / 60) + ":" + String.format("%02d", s % 60);
    }

    public static String n(float value){
        return String.valueOf(Math.round(value));
    }

    /** Убирает цветовые теги и лишние символы для логов. */
    public static String plain(String s){
        return Strings.stripColors(s);
    }
}
