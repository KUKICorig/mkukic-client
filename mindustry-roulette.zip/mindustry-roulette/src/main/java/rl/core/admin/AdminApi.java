package rl.core.admin;

import rl.core.*;

import java.time.Instant;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Логика веб-админки, отделённая от HTTP-транспорта: на вход — метод/путь/заголовки/тело,
 * на выход — статус/тип/тело. Так её можно тестировать без поднятого сокета.
 */
public class AdminApi {

    public static class Req {
        public String method = "GET";
        public String path = "/";
        public Map<String, String> query = new LinkedHashMap<>();
        public Map<String, String> headers = new LinkedHashMap<>();
        public String body = "";
        public String ip = "";

        public String header(String name) {
            if (name == null) return null;
            String v = headers.get(name.toLowerCase());
            return v;
        }

        public String q(String name, String def) {
            String v = query.get(name);
            return (v == null || v.isEmpty()) ? def : v;
        }

        public int qi(String name, int def) {
            try {
                return Integer.parseInt(q(name, String.valueOf(def)));
            } catch (Exception e) {
                return def;
            }
        }
    }

    public static class Resp {
        public int status = 200;
        public String type = "application/json; charset=utf-8";
        public String body = "";
        public List<String> cookies = new ArrayList<>();

        public static Resp json(int status, Object o) {
            Resp r = new Resp();
            r.status = status;
            r.body = Json.write(o);
            return r;
        }

        public static Resp text(int status, String type, String body) {
            Resp r = new Resp();
            r.status = status;
            r.type = type;
            r.body = body == null ? "" : body;
            return r;
        }
    }

    /** Колбэки в игру (регистрация команд, перезапуск веб-сервера, сообщения). */
    public interface Hooks {
        default void onConfigChanged(Config cfg) {}
        default void onRequestWebRestart() {}
        default void broadcast(String message) {}
    }

    private final ConfigStore store;
    private final Config cfg;
    private final RouletteService service;
    private final RouletteEngine engine;
    private final AccountStore accounts;
    private final GameLog log;
    private final Hooks hooks;

    private final Map<String, long[]> loginFails = new LinkedHashMap<>();

    public AdminApi(ConfigStore store, Config cfg, RouletteService service, RouletteEngine engine,
                    AccountStore accounts, GameLog log, Hooks hooks) {
        this.store = store;
        this.cfg = cfg;
        this.service = service;
        this.engine = engine;
        this.accounts = accounts;
        this.log = log;
        this.hooks = hooks == null ? new Hooks() {} : hooks;
    }

    // ---------------------------------------------------------------- routing

    public Resp handle(Req req) {
        try {
            String path = req.path == null ? "/" : req.path;
            if (path.length() > 1 && path.endsWith("/")) path = path.substring(0, path.length() - 1);

            switch (path) {
                case "/":
                case "/index.html":
                    return staticResp("index.html", "text/html; charset=utf-8");
                case "/app.js":
                    return staticResp("app.js", "application/javascript; charset=utf-8");
                case "/style.css":
                    return staticResp("style.css", "text/css; charset=utf-8");
                case "/favicon.svg":
                    return staticResp("favicon.svg", "image/svg+xml");
                case "/api/health":
                    return Resp.json(200, health());
                case "/api/login":
                    return login(req);
                case "/api/logout":
                    return logout();
                default:
                    break;
            }

            if (!path.startsWith("/api/")) return Resp.text(404, "text/plain; charset=utf-8", "not found");
            if (!authorized(req)) {
                return Resp.json(401, Json.obj("ok", false, "error", "unauthorized"));
            }

            boolean post = "POST".equalsIgnoreCase(req.method);
            switch (path) {
                case "/api/config":
                    return post ? updateConfig(req) : Resp.json(200, Json.obj("ok", true, "config", cfg.toMap(),
                            "info", configInfo()));
                case "/api/stats":
                    return Resp.json(200, Json.obj("ok", true, "stats", stats()));
                case "/api/recent":
                    return Resp.json(200, Json.obj("ok", true, "spins", recentSpins(req.qi("limit", 60)),
                            "state", service.stateMap()));
                case "/api/logs/days":
                    return Resp.json(200, Json.obj("ok", true, "days", log.days()));
                case "/api/logs":
                    return logs(req);
                case "/api/logs/export":
                    return exportLog(req);
                case "/api/accounts":
                    return accountsList(req);
                case "/api/account":
                    return post ? accountAdjust(req) : accountGet(req);
                case "/api/seed/rotate":
                    return post ? seedRotate() : Resp.json(200, seedInfo());
                case "/api/simulate":
                    return post ? simulate(req) : Resp.json(405, Json.obj("ok", false, "error", "POST only"));
                case "/api/toggle":
                    return post ? toggle(req) : Resp.json(405, Json.obj("ok", false, "error", "POST only"));
                case "/api/lists":
                    return post ? updateList(req) : Resp.json(200, Json.obj("ok", true,
                            "bannedIds", cfg.limits.bannedIds, "adminIds", cfg.limits.adminIds));
                case "/api/files":
                    return Resp.json(200, Json.obj("ok", true, "files", store.dataFiles()));
                case "/api/file":
                    return fileGet(req);
                case "/api/announce":
                    return post ? announce(req) : Resp.json(405, Json.obj("ok", false, "error", "POST only"));
                case "/api/save":
                    return post ? saveNow() : Resp.json(405, Json.obj("ok", false, "error", "POST only"));
                case "/api/web/restart":
                    return post ? webRestart() : Resp.json(405, Json.obj("ok", false, "error", "POST only"));
                default:
                    return Resp.json(404, Json.obj("ok", false, "error", "unknown endpoint"));
            }
        } catch (Exception e) {
            log.log(GameLog.EV_ERROR, Json.obj("where", "admin-api", "error", String.valueOf(e)));
            return Resp.json(500, Json.obj("ok", false, "error", String.valueOf(e)));
        }
    }

    // ------------------------------------------------------------------ auth

    private boolean authorized(Req req) {
        String token = req.header("x-admin-token");
        if (token == null) {
            String cookie = req.header("cookie");
            token = cookieValue(cookie, "rladmin");
        }
        return constEquals(token, cfg.web.token);
    }

    private static boolean constEquals(String a, String b) {
        if (a == null || b == null) return false;
        byte[] x = a.getBytes(java.nio.charset.StandardCharsets.UTF_8);
        byte[] y = b.getBytes(java.nio.charset.StandardCharsets.UTF_8);
        return java.security.MessageDigest.isEqual(x, y);
    }

    static String cookieValue(String cookieHeader, String name) {
        if (cookieHeader == null) return null;
        for (String part : cookieHeader.split(";")) {
            String p = part.trim();
            if (p.startsWith(name + "=")) return p.substring(name.length() + 1);
        }
        return null;
    }

    private boolean ipAllowed(Req req) {
        if (cfg.web.allowIps == null || cfg.web.allowIps.isEmpty()) return true;
        String ip = req.ip == null ? "" : req.ip;
        for (String a : cfg.web.allowIps) {
            if (a == null || a.trim().isEmpty()) continue;
            a = a.trim();
            if (a.equals(ip) || a.equals("*")) return true;
            if (a.endsWith("*") && ip.startsWith(a.substring(0, a.length() - 1))) return true;
        }
        return false;
    }

    private boolean rateLimited(String ip) {
        synchronized (loginFails) {
            long[] rec = loginFails.get(ip);
            if (rec == null) return false;
            if (System.currentTimeMillis() - rec[1] > 15 * 60_000L) {
                loginFails.remove(ip);
                return false;
            }
            return rec[0] >= 10;
        }
    }

    private void noteFail(String ip) {
        synchronized (loginFails) {
            long[] rec = loginFails.computeIfAbsent(ip, k -> new long[2]);
            rec[0]++;
            rec[1] = System.currentTimeMillis();
        }
    }

    private void clearFails(String ip) {
        synchronized (loginFails) { loginFails.remove(ip); }
    }

    private Resp login(Req req) {
        if (!ipAllowed(req)) return Resp.json(403, Json.obj("ok", false, "error", "ip not allowed"));
        if (rateLimited(req.ip)) {
            return Resp.json(429, Json.obj("ok", false, "error", "Слишком много попыток. Подождите 15 минут."));
        }
        Map<String, Object> body = Json.parseObject(req.body);
        String token = String.valueOf(body.getOrDefault("token", req.q("token", "")));
        if (!constEquals(token, cfg.web.token)) {
            noteFail(req.ip);
            log.log(GameLog.EV_WEB, Json.obj("action", "login_failed", "ip", req.ip));
            return Resp.json(401, Json.obj("ok", false, "error", "Неверный токен"));
        }
        clearFails(req.ip);
        log.log(GameLog.EV_WEB, Json.obj("action", "login_ok", "ip", req.ip));
        Resp r = Resp.json(200, Json.obj("ok", true, "session", store.sessionToken()));
        r.cookies.add("rladmin=" + cfg.web.token + "; Path=/; HttpOnly; SameSite=Strict; Max-Age=43200");
        return r;
    }

    private Resp logout() {
        Resp r = Resp.json(200, Json.obj("ok", true));
        r.cookies.add("rladmin=; Path=/; HttpOnly; Max-Age=0");
        return r;
    }

    // --------------------------------------------------------------- данные

    private Map<String, Object> health() {
        Map<String, Object> m = Json.obj();
        m.put("ok", true);
        m.put("plugin", "RoulettePlugin");
        m.put("version", Version.VALUE);
        m.put("uptimeMs", System.currentTimeMillis() - store.startedAt());
        m.put("enabled", cfg.general.enabled);
        m.put("serverTime", Instant.now().toString());
        m.put("mindustry", System.getProperty("mindustry.version", ""));
        return m;
    }

    private Map<String, Object> configInfo() {
        Map<String, Object> m = Json.obj();
        m.put("theoreticalRtp", cfg.theoreticalRtpPercent());
        m.put("winChance", cfg.winChancePercent());
        m.put("segments", cfg.effectiveSegments().size());
        m.put("houseId", cfg.general.houseId);
        return m;
    }

    private Map<String, Object> stats() {
        Map<String, Object> m = new LinkedHashMap<>(accounts.totals());
        m.put("houseBalance", accounts.balance(cfg.general.houseId));
        m.put("houseId", cfg.general.houseId);
        m.put("nonce", accounts.nonce());
        m.put("seedHash", engine.serverSeedHash());
        m.put("seedCreatedAt", engine.seedCreatedAt());
        m.put("spinsWithSeed", engine.spinsWithSeed());
        m.put("theoreticalRtp", cfg.theoreticalRtpPercent());
        m.put("winChance", cfg.winChancePercent());
        m.put("mode", cfg.roulette.mode);
        m.put("minBet", cfg.betting.minBet);
        m.put("maxBet", cfg.betting.maxBet);
        m.put("rake", cfg.roulette.rakePercent);
        m.put("enabled", cfg.general.enabled);
        m.put("spinning", service.isSpinning());
        m.put("queue", service.queueSize());
        m.put("uptimeMs", System.currentTimeMillis() - store.startedAt());
        return m;
    }

    private Map<String, Object> seedInfo() {
        return Json.obj("ok", true,
                "serverSeedHash", engine.serverSeedHash(),
                "seedCreatedAt", engine.seedCreatedAt(),
                "spinsWithSeed", engine.spinsWithSeed(),
                "provablyFair", cfg.fair.enabled);
    }

    private Resp seedRotate() {
        String oldHash = engine.serverSeedHash();
        engine.rotateSeed();
        String seed = engine.serverSeed();
        log.log(GameLog.EV_SEED, Json.obj("action", "rotate", "oldSeedHash", oldHash,
                "newSeedHash", engine.serverSeedHash()));
        Map<String, Object> m = seedInfo();
        m.put("serverSeed", seed);
        m.put("oldSeedHash", oldHash);
        m.put("warning", "Старый seedHash опубликован — теперь его можно раскрыть игрокам для проверки.");
        return Resp.json(200, m);
    }

    private List<Map<String, Object>> recentSpins(int limit) {
        List<Map<String, Object>> out = new ArrayList<>();
        for (Map<String, Object> e : log.recent(Math.max(limit * 4, 200))) {
            if (!GameLog.EV_SPIN.equals(String.valueOf(e.get("event")))) continue;
            out.add(spinView(e));
            if (out.size() >= limit) break;
        }
        return out;
    }

    /** Вид спина для админки: ID + ник (ник здесь уместен — это закрытая панель). */
    private Map<String, Object> spinView(Map<String, Object> e) {
        Map<String, Object> m = new LinkedHashMap<>(e);
        return m;
    }

    private Resp logs(Req req) {
        String day = req.q("day", log.today());
        int limit = Math.min(req.qi("limit", 300), Math.max(10, cfg.web.maxLogLines));
        List<String> lines = log.tail(day, limit);
        List<Object> parsed = new ArrayList<>();
        for (String l : lines) {
            Object o = Json.parse(l);
            parsed.add(o == null ? l : o);
        }
        return Resp.json(200, Json.obj("ok", true, "day", day, "count", parsed.size(),
                "days", log.days(), "entries", parsed));
    }

    private Resp exportLog(Req req) {
        String day = req.q("day", log.today());
        String raw = log.raw(day);
        Resp r = Resp.text(200, "application/octet-stream; charset=utf-8", raw);
        return r;
    }

    private Resp accountsList(Req req) {
        String sort = req.q("sort", "won");
        int limit = Math.min(req.qi("limit", 50), 500);
        List<AccountStore.Account> top = accounts.top(sort, limit);
        List<Object> out = new ArrayList<>();
        for (AccountStore.Account a : top) out.add(a.toMap());
        return Resp.json(200, Json.obj("ok", true, "count", out.size(), "sort", sort,
                "accounts", out, "totals", accounts.totals()));
    }

    private Resp accountGet(Req req) {
        String id = req.q("id", "");
        if (id.isEmpty()) return Resp.json(400, Json.obj("ok", false, "error", "id required"));
        AccountStore.Account a = accounts.get(id);
        if (a == null) return Resp.json(404, Json.obj("ok", false, "error", "аккаунт не найден"));
        List<Object> spins = new ArrayList<>();
        for (Map<String, Object> e : log.recent(1000)) {
            if (!GameLog.EV_SPIN.equals(String.valueOf(e.get("event")))) continue;
            if (!id.equals(String.valueOf(e.get("id")))) continue;
            spins.add(e);
            if (spins.size() >= 50) break;
        }
        return Resp.json(200, Json.obj("ok", true, "account", a.toMap(), "spins", spins));
    }

    private Resp accountAdjust(Req req) {
        Map<String, Object> body = Json.parseObject(req.body);
        Json.Node n = Json.Node.of(body);
        String id = n.str("id", "").trim();
        if (id.isEmpty()) return Resp.json(400, Json.obj("ok", false, "error", "id required"));
        String mode = n.str("mode", "delta");
        long amount = n.lng("amount", 0);
        String reason = n.str("reason", "admin");
        long before = accounts.balance(id);
        long after;
        if ("set".equals(mode)) {
            accounts.setBalance(id, amount);
            after = amount;
        } else {
            if (amount < 0) {
                if (!accounts.withdraw(id, -amount)) {
                    return Resp.json(400, Json.obj("ok", false, "error", "недостаточно средств на ID " + id));
                }
            } else {
                accounts.deposit(id, amount);
            }
            after = accounts.balance(id);
        }
        accounts.save();
        log.log(GameLog.EV_ADMIN, Json.obj("id", id, "action", "adjust_balance", "mode", mode,
                "amount", amount, "before", before, "after", after, "reason", reason,
                "by", req.ip));
        return Resp.json(200, Json.obj("ok", true, "id", id, "before", before, "after", after));
    }

    private Resp updateConfig(Req req) {
        Map<String, Object> body = Json.parseObject(req.body);
        if (body.isEmpty()) return Resp.json(400, Json.obj("ok", false, "error", "пустое тело запроса"));
        Object cfgNode = body.get("config");
        @SuppressWarnings("unchecked")
        Map<String, Object> patch = cfgNode instanceof Map ? (Map<String, Object>) cfgNode : body;

        // валидация на копии
        Config test = Config.fromJson(Json.write(cfg.toMap()));
        test.fromMap(patch);
        test.sanitize();
        if (test.roulette.segments.isEmpty()) {
            return Resp.json(400, Json.obj("ok", false, "error", "список секторов не может быть пустым"));
        }
        if (test.theoreticalRtpPercent() > 100) {
            return Resp.json(400, Json.obj("ok", false, "error",
                    "RTP больше 100% (" + test.theoreticalRtpPercent() + "%) — казино будет в минусе. Не сохранено."));
        }

        String err = store.patchConfig(cfg, patch);
        if (err != null) return Resp.json(500, Json.obj("ok", false, "error", err));
        hooks.onConfigChanged(cfg);
        log.log(GameLog.EV_CONFIG, Json.obj("action", "update", "by", req.ip,
                "keys", new ArrayList<>(patch.keySet())));
        return Resp.json(200, Json.obj("ok", true, "config", cfg.toMap(), "info", configInfo()));
    }

    private Resp simulate(Req req) {
        Map<String, Object> body = Json.parseObject(req.body);
        Json.Node n = Json.Node.of(body);
        long spins = Math.min(n.lng("spins", 10_000), Math.max(100, cfg.web.maxSimSpins));
        Config target = cfg;
        if (n.has("config")) {
            target = Config.fromJson(Json.write(cfg.toMap()));
            @SuppressWarnings("unchecked")
            Map<String, Object> patch = (Map<String, Object>) n.map().get("config");
            target.fromMap(patch);
            target.sanitize();
        }
        RouletteEngine.SimResult r = RouletteEngine.simulate(target, spins);
        Map<String, Object> m = r.toMap();
        m.put("ok", true);
        m.put("config", target.toMap());
        m.put("note", "Симуляция на временном serverSeed: реальные спины используют текущий seed казино.");
        return Resp.json(200, m);
    }

    private Resp toggle(Req req) {
        Map<String, Object> body = Json.parseObject(req.body);
        Json.Node n = Json.Node.of(body);
        boolean enabled = n.bool("enabled", !cfg.general.enabled);
        cfg.general.enabled = enabled;
        store.saveConfig(cfg);
        hooks.onConfigChanged(cfg);
        log.log(GameLog.EV_CONFIG, Json.obj("action", "toggle", "enabled", enabled, "by", req.ip));
        if (!enabled) hooks.broadcast("[gold]🎰[scarlet] Рулетка временно выключена администратором.[]");
        return Resp.json(200, Json.obj("ok", true, "enabled", enabled));
    }

    private Resp updateList(Req req) {
        Map<String, Object> body = Json.parseObject(req.body);
        Json.Node n = Json.Node.of(body);
        String which = n.str("list", "banned");
        List<String> ids = new ArrayList<>();
        for (Object o : n.list("ids")) {
            String s = String.valueOf(o).trim();
            if (!s.isEmpty()) ids.add(s);
        }
        if ("admin".equals(which)) cfg.limits.adminIds = ids;
        else cfg.limits.bannedIds = ids;
        store.saveConfig(cfg);
        hooks.onConfigChanged(cfg);
        log.log(GameLog.EV_CONFIG, Json.obj("action", "update_list", "list", which, "ids", ids, "by", req.ip));
        return Resp.json(200, Json.obj("ok", true, "bannedIds", cfg.limits.bannedIds,
                "adminIds", cfg.limits.adminIds));
    }

    private Resp fileGet(Req req) {
        String name = req.q("name", "");
        if ("state.json".equals(name) && !cfg.web.token.isEmpty()) {
            // serverSeed выдаём только авторизованным (мы уже прошли auth) — это ок,
            // но в ответе помечаем как чувствительные данные
        }
        String content = store.readFileSafe(name);
        if (content == null) return Resp.json(404, Json.obj("ok", false, "error", "файл не найден"));
        return Resp.json(200, Json.obj("ok", true, "name", name, "content", content));
    }

    private Resp announce(Req req) {
        Map<String, Object> body = Json.parseObject(req.body);
        String text = String.valueOf(body.getOrDefault("text", "")).trim();
        if (text.isEmpty()) return Resp.json(400, Json.obj("ok", false, "error", "пустое сообщение"));
        if (text.length() > 500) text = text.substring(0, 500);
        hooks.broadcast("[gold]🎰[] " + text);
        log.log(GameLog.EV_ADMIN, Json.obj("action", "announce", "text", text, "by", req.ip));
        return Resp.json(200, Json.obj("ok", true));
    }

    private Resp saveNow() {
        accounts.save();
        String err = store.saveConfig(cfg);
        log.log(GameLog.EV_ADMIN, Json.obj("action", "manual_save"));
        return Resp.json(200, Json.obj("ok", err == null, "error", err == null ? "" : err));
    }

    private Resp webRestart() {
        hooks.onRequestWebRestart();
        log.log(GameLog.EV_WEB, Json.obj("action", "restart_requested"));
        return Resp.json(200, Json.obj("ok", true,
                "message", "Перезапуск веб-сервера запланирован; соединение может оборваться."));
    }

    private Resp staticResp(String resource, String type) {
        String content = ConfigStore.resource("/web/" + resource);
        if (content == null) return Resp.text(404, "text/plain; charset=utf-8", "asset missing: " + resource);
        Resp r = Resp.text(200, type, content);
        return r;
    }

    public boolean ipFilterEnabled() { return cfg.web.allowIps != null && !cfg.web.allowIps.isEmpty(); }

    public boolean isIpAllowed(Req req) { return ipAllowed(req); }

    public RouletteService service() { return service; }
}
